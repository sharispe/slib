/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package catproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import org.openrdf.model.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.indexer.IndexHash;
import slib.indexer.IndexedElement;
import slib.indexer.mesh.Indexer_MESH_XML;
import slib.sglib.algo.utils.RooterDAG;
import slib.sglib.algo.validator.dag.ValidatorDAG;
import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.loader.bio.mesh.GraphLoader_MESH_XML;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.E;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.graph.utils.Direction;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;
import slib.utils.impl.SetUtils;
import slib.utils.impl.UtilDebug;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class DataLoader {

    String dirCategories;
    String dirProjectAnnotations;
    Map<String, Category> categoriesMap;
    Map<Integer, Project> projectMap;
    DataFactory factory = DataFactoryMemory.getSingleton();
    Logger logger = LoggerFactory.getLogger(this.getClass());
    G meshGraph;
    IndexHash meshIndex;
    Map<String, Value> meshDescriptionIndex;
    String meshFile = "/data/mesh/desc2013.xml";
    String graphURIasString;

    private Set<String> loadCategoriesFiles() {
        File dir = new File(dirCategories);

        Set<String> catFiles = new HashSet<String>();

        File listFiles[] = dir.listFiles();
        for (int i = 0; i < listFiles.length; i++) {
            if (listFiles[i].isFile()) {
                catFiles.add(listFiles[i].getPath());
            }
        }
        return catFiles;
    }

    /**
     * @return a map key project id , value project file path
     */
    private Map<Integer, String> loadProjectFiles() {

        logger.info(dirProjectAnnotations);
        File dir = new File(dirProjectAnnotations);

        Map<Integer, String> projectFiles = new HashMap<Integer, String>();

        File[] listFiles = dir.listFiles();

        logger.info("Project Files Directory " + dirProjectAnnotations);

        for (int i = 0; i < listFiles.length; i++) {

            if (listFiles[i].isFile() && !listFiles[i].getName().equals("readme.txt")) {
                Integer id = Integer.parseInt(listFiles[i].getName());
                projectFiles.put(id, listFiles[i].getPath());
            }
        }
        return projectFiles;
    }

    private Map<Integer, Project> loadProjects(Map<Integer, String> projectFiles, boolean conceptsAsURI) throws Exception {




        Map<Integer, Project> pMap = new HashMap<Integer, Project>();

        for (Entry<Integer, String> e : projectFiles.entrySet()) {

            Integer id = e.getKey();
            String path = e.getValue();

            logger.info("Loading project " + id);

            Project p = new Project(id, path);
            Set<WeightedAnnot> weightedAnnots = loadAnnotations(path, conceptsAsURI);

            if (weightedAnnots.isEmpty()) {
                logger.info("[Skip project " + id + " empty annotation set]");
                continue;
            }

            p.setAnnotations(weightedAnnots);
            pMap.put(id, p);
        }

        return pMap;
    }

    private Set<WeightedAnnot> loadAnnotations(String filepath, boolean conceptsAsURI) throws Exception {

        Set<WeightedAnnot> annotations = new HashSet<WeightedAnnot>();

        int skipped = 0;

        FileInputStream fstream = new FileInputStream(filepath);
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;

        while ((line = br.readLine()) != null) {

            line = line.trim();

            if (!line.isEmpty()) {

                String[] data = line.split("\t");

                String d = data[0];
                double weight = Double.parseDouble(data[1]);


                URI uriConcept = null;

                if (!conceptsAsURI) {
                    uriConcept = getConceptURI_FromDescription(d);
                } else {
                    uriConcept = factory.createURI(graphURIasString + "" + d);
                }

                if (uriConcept == null) {
                    logger.info("\t[Skipped] Error cannot locate URI associated to description " + d);
                    skipped++;
                    continue;
                }
                WeightedAnnot annot = new WeightedAnnot(uriConcept, weight);

                annotations.add(annot);
            }
        }
        //Close the input stream
        in.close();

        if (skipped != 0) {
            logger.info("Skipped " + skipped);
        }
        return annotations;
    }

    /**
     * Here do the link between concept Description name and MeshURI
     *
     * @param descriptionName
     * @return the URI corresponding to the concept associated to the given
     * description
     */
    private URI getConceptURI_FromDescription(String descriptionName) {

        return (URI) meshDescriptionIndex.get(descriptionName);
    }

    private Map<String, Category> loadCategories(Set<String> catFiles) throws Exception {

        Map<String, Category> categoryMap = new HashMap<String, Category>();

        for (String fpath : catFiles) {
            File f = new File(fpath);
            FileInputStream fstream = new FileInputStream(fpath);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;

            Category c = new Category(f.getName());

            while ((line = br.readLine()) != null) {

                line = line.trim();

                if (!line.isEmpty()) {

                    String[] data = line.split("\t");

                    Integer projectID = Integer.parseInt(data[0]);

                    if (!projectMap.containsKey(projectID)) {
                        logger.info("Error loading category " + c.name + " cannot refer to unknow project " + projectID);
                    } else {
                        c.addProject(projectMap.get(projectID));
                    }
                }
            }
            //Close the input stream
            categoryMap.put(c.name, c);

            in.close();
        }
        return categoryMap;
    }

    private void loadDataConceptsAsDescription(String dirCategories, String dirProjectAnnotations, String graphURIasString) throws Exception {

        loadMeshGraph(graphURIasString);
        loadMeshIndex();

        this.dirCategories = dirCategories;
        this.dirProjectAnnotations = dirProjectAnnotations;

        Set<String> catFiles = loadCategoriesFiles();
        logger.info("Files referring to categories " + catFiles.size());

        Map<Integer, String> projectFiles = loadProjectFiles();
        projectMap = loadProjects(projectFiles, false);

        logger.info("Number of project loaded: " + projectMap.size());

        categoriesMap = loadCategories(catFiles);
        logger.info("Number of categories loaded: " + categoriesMap.size());
    }

    public void loadDataConceptsAsURI(String dirCategories, String dirProjectAnnotations, String graphURIasString) throws Exception {

        this.graphURIasString = graphURIasString;

        loadMeshGraph(graphURIasString);

        this.dirCategories = dirCategories;
        this.dirProjectAnnotations = dirProjectAnnotations;

        Set<String> catFiles = loadCategoriesFiles();
        logger.info("Files referring to categories " + catFiles.size());

        Map<Integer, String> projectFiles = loadProjectFiles();
        projectMap = loadProjects(projectFiles, true);

        logger.info("Number of project loaded: " + projectMap.size());

        categoriesMap = loadCategories(catFiles);
        logger.info("Number of categories loaded: " + categoriesMap.size());
    }

    public void loadMeshGraph(String graphURIasString) throws SLIB_Exception {

        logger.info("Loading MESH - Graph");
        this.graphURIasString = graphURIasString;

        URI guri = factory.createURI(this.graphURIasString);
        meshGraph = new GraphMemory(guri);

        GraphLoader_MESH_XML loader = new GraphLoader_MESH_XML();



        GDataConf meshXML = new GDataConf(GFormat.MESH_XML, meshFile);
        loader.populate(meshXML, meshGraph);

        logger.info("Reerooting the graph");
        ValidatorDAG validator = new ValidatorDAG();
        int countEdgeRemoved = 0;
        while (validator.isDag(meshGraph, SetUtils.buildSet(RDFS.SUBCLASSOF), Direction.OUT) == false) {
            countEdgeRemoved++;
            logger.info("Iteration " + countEdgeRemoved + " removing edge \t" + validator.getLastEdge());
            E cycle = validator.getLastEdge();

            meshGraph.removeE(cycle);

        }

        if (countEdgeRemoved != 0) {
            logger.info("[important]Remove " + countEdgeRemoved + " edge(s) in order to obtain acycli taxonomic graph");
        }
        URI mesh_root = factory.createURI(graphURIasString + "fictive_root");
        RooterDAG.rootUnderlyingTaxonomicDAG(meshGraph, mesh_root);
    }

    public void loadMeshIndex() throws SLIB_Exception {

        logger.info("Loading MESH - Index");
        Indexer_MESH_XML indexer = new Indexer_MESH_XML();
        meshIndex = indexer.buildIndex(factory, meshFile, meshGraph.getURI().stringValue());

        meshDescriptionIndex = loadMeshDescIndex();
    }

    private Map<String, Value> loadMeshDescIndex() throws SLIB_Ex_Critic {

        logger.info("Building index for Mesh");

        Map<String, Value> index = new HashMap<String, Value>();

        for (Entry<Value, IndexedElement> e : meshIndex.getMapping().entrySet()) {

            for (String s : e.getValue().getDescriptions()) {

                if (index.containsKey(s)) {
                    throw new SLIB_Ex_Critic("Key Collision... loading mesh index" + s);
                }
                index.put(s, e.getKey());
            }
        }
        return index;
    }

    /**
     * Flush the loaded data into disk considering the specified locations
     *
     * @param newDirCategories
     * @param newDirProjectAnnotations
     */
    private void flushData(String newDirCategories, String newDirProjectAnnotations) throws Exception {


        logger.info("Flushing categories to " + newDirCategories);

        for (Category c : categoriesMap.values()) {

            String fname = newDirCategories + "/" + c.name;
            logger.info("Category " + c.name + "\t" + fname);

            FileWriter fstream = new FileWriter(fname);
            BufferedWriter out = new BufferedWriter(fstream);

            for (Project p : c.getProjects()) {
                logger.info(p.id + "");
                out.write(p.id + "\n");
            }
            out.close();

        }
        logger.info("Flushing projects to " + newDirProjectAnnotations);

        for (Project p : projectMap.values()) {

            String fname = newDirProjectAnnotations + p.id;
            logger.info("Project " + p.id + "\t" + fname);

            FileWriter fstream = new FileWriter(fname);
            BufferedWriter out = new BufferedWriter(fstream);


            for (WeightedAnnot annot : p.annotations) {
                logger.info("\t" + annot.concept + "\t" + annot.weight);
                out.write(annot.concept.getLocalName() + "\t" + annot.weight + "\n");
            }
            out.close();
        }
    }

    public static void main(String[] a) throws Exception {

        String pathDirectory = "/data/project_categories/";
        String dirCategories = pathDirectory + "categories";
        String dirProjectAnnotations = pathDirectory + "Unified/separated/UnifiedNameBigramConceptsTruncated";

        String graphURIasString = "http://biograph/mesh/";

        DataLoader loader = new DataLoader();
        loader.loadDataConceptsAsDescription(dirCategories, dirProjectAnnotations, graphURIasString);

        String newPathDirectory = "/data/project_categories/cleaned_data/";
        String newDirCategories = newPathDirectory + "categories/";
        String newDirProjectAnnotations = newPathDirectory + "projects/";

        loader.flushData(newDirCategories, newDirProjectAnnotations);
        loader.loadDataConceptsAsURI(newDirCategories, newDirProjectAnnotations, graphURIasString);
    }
}
