/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package catproject;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.openrdf.model.URI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.sglib.model.graph.elements.V;
import slib.sml.sm.core.metrics.ic.utils.IC_Conf_Topo;
import slib.sml.sm.core.metrics.ic.utils.ICconf;
import slib.sml.sm.core.utils.SMConstants;
import slib.sml.sm.core.utils.SM_Engine;
import slib.sml.sm.core.utils.SMconf;
import slib.utils.ex.SLIB_Ex_Critic;

/**
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class StudyCategories {

    DataLoader dataLoader;
    Logger logger = LoggerFactory.getLogger(this.getClass());
    SM_Engine engineMesh;
    int MAX_CATEGORY_PER_PROJECT = 5;

    public StudyCategories(boolean cachePairwise) throws Exception {
        String newPathDirectory = "/data/project_categories/cleaned_data/";
        String newDirCategories = newPathDirectory + "categories/";
        String newDirProjectAnnotations = newPathDirectory + "projects/";

        String graphURIasString = "http://biograph/mesh/";
        dataLoader = new DataLoader();

        dataLoader.loadDataConceptsAsURI(newDirCategories, newDirProjectAnnotations, graphURIasString);
        engineMesh = new SM_Engine(dataLoader.meshGraph);
        engineMesh.setCachePairwiseResults(cachePairwise);
    }

    public void computeStat(String outfile) throws Exception {

        ICconf confIC = new IC_Conf_Topo(SMConstants.FLAG_ICI_SECO_2004);

        SMconf confPairwiseResnik = new SMconf("Resnik", SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_RESNIK_1995, confIC);
        SMconf confPairwiseLin = new SMconf("Lin", SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998, confIC);

        Set<SMconf> pairwiseConfs = new LinkedHashSet<SMconf>();

        pairwiseConfs.add(confPairwiseResnik);
        pairwiseConfs.add(confPairwiseLin);

        SMconf confGroupwiseMIN = new SMconf("MIN", SMConstants.FLAG_SIM_GROUPWISE_MIN);
        SMconf confGroupwiseMAX = new SMconf("MAX", SMConstants.FLAG_SIM_GROUPWISE_MAX);
        SMconf confGroupwiseBMA = new SMconf("BMA", SMConstants.FLAG_SIM_GROUPWISE_BMA);

        Set<SMconf> groupwiseConfs = new LinkedHashSet<SMconf>();
        groupwiseConfs.add(confGroupwiseMIN);
        groupwiseConfs.add(confGroupwiseMAX);
        groupwiseConfs.add(confGroupwiseBMA);



        engineMesh.computeIC(confIC);

        FileWriter fstream = new FileWriter(outfile);
        BufferedWriter filePrinter = new BufferedWriter(fstream);

        String header = "CATEGORY_NAME\tNB_PROJECTS\tAVERAGE_ANNOT_PROJECTS\tMIN_ANNOT_PROJECTS\tMAX_ANNOT_PROJECTS";

        for (SMconf gConf : groupwiseConfs) {

            for (SMconf pConf : pairwiseConfs) {
                header += "\tINTRA_SIM_" + gConf.label + "_" + pConf.label;
            }
        }

        filePrinter.write(header + "\n");

        for (Category c : dataLoader.categoriesMap.values()) {


            int min = Integer.MAX_VALUE;
            int max = -Integer.MAX_VALUE;
            double avg = 0;

            for (Project p : c.projects.values()) {

                int annot_size = p.annotations.size();

                avg += annot_size;

                if (annot_size < min) {
                    min = annot_size;
                }
                if (annot_size > max) {
                    max = annot_size;
                }
            }

            avg = avg / (double) c.projects.size();

            logger.info("------------------------");
            logger.info("Categories " + c.name);
            logger.info("------------------------");
            logger.info("Nb Projects\t" + c.projects.size());
            logger.info("\tAVG annots project\t" + avg);
            logger.info("\tMIN annot project\t" + min);
            logger.info("\tMAX annot project\t" + max);
            logger.info("------------------------");

            String outString = c.name + "\t" + c.projects.size() + "\t" + avg + "\t" + min + "\t" + max;

            for (SMconf gConf : groupwiseConfs) {

                for (SMconf pConf : pairwiseConfs) {

                    double intra_sim = computeIntraCategorySimilarity(c, gConf, pConf);
                    outString += "\t" + intra_sim;

                    logger.info("\tINTRA SIM_" + gConf.label + "_" + pConf.label + ": \t" + intra_sim);

                }
            }

            logger.info("------------------------");

            filePrinter.write(outString + "\n");
        }
        filePrinter.close();
    }

    private double computeIntraCategorySimilarity(Category c, SMconf confMeasureGroupwise, SMconf confMeasurePairwise) throws SLIB_Ex_Critic {
        List<Project> projectList = new ArrayList<Project>(c.getProjects());

        //int nbComp = projectList.size() * (projectList.size() - 1) / 2;
        int nbComp = projectList.size() * projectList.size();
        int nbCompCur = 0;

        double intraSim = 0;

        for (int i = 0; i < projectList.size(); i++) {

            Project pA = projectList.get(i);

            for (int j = 0; j < projectList.size(); j++) {

                nbCompCur++;

                Project pB = projectList.get(j);

                Set<URI> conceptsPaURI = pA.getAnnotationsAsURIs();
                Set<URI> conceptsPbURI = pB.getAnnotationsAsURIs();

                Set<V> conceptsPA = urisToConcepts(conceptsPaURI);
                Set<V> conceptsPB = urisToConcepts(conceptsPbURI);

                double sim = engineMesh.computeGroupwiseAddOnSim(confMeasureGroupwise, confMeasurePairwise, conceptsPA, conceptsPB);

                logger.info("\t" + nbCompCur + "/" + nbComp + " projects " + pA.id + " (" + conceptsPA.size() + ")\t" + pB.id + " (" + conceptsPB.size() + ")\t" + sim);

                if (Double.isNaN(sim) || Double.isInfinite(sim)) {
                    throw new SLIB_Ex_Critic("Error similarity value obtained ! " + sim);
                }

                intraSim += sim;

            }
        }

        intraSim = intraSim / (projectList.size() * projectList.size());

        return intraSim;

    }

    private Set<V> urisToConcepts(Set<URI> conceptsURIs) throws SLIB_Ex_Critic {

        Set<V> vertices = new HashSet<V>();

        for (URI u : conceptsURIs) {

            V v = dataLoader.meshGraph.getV(u);

            if (v == null) {
                throw new SLIB_Ex_Critic("Error cannot locate vertex associated to URI " + u);
            }
            vertices.add(v);
        }
        return vertices;
    }

    private Set<Category> getCategories(Project p) throws SLIB_Ex_Critic {

        Set<Category> categories = new HashSet<Category>();

        for (Category c : dataLoader.categoriesMap.values()) {
            if (c.projects.containsKey(p.id)) {
                categories.add(c);
            }
        }

        return categories;
    }

    /**
     * Leave-one-out cross-validation (LOOCV)
     *
     * @param categoryRepresentation
     * @return fitness score
     * @throws SLIB_Ex_Critic
     * @throws CloneNotSupportedException
     */
    public LoocvResult loocv(CategoryRepresentation categoryRepresentation, SMconf confPairwise, SMconf confGroupwise) throws SLIB_Ex_Critic, CloneNotSupportedException {

        logger.info("* Test One out");

        Set<Project> projectExcludedFromTest = new HashSet<Project>();

        double wellRankedBoolean = 0;
        double finalScore = 0;
        double discriminativePower = 0;

        for (Project p : dataLoader.projectMap.values()) {

            logger.info("------------------------------------------------------------------------");

            if (p.annotations.isEmpty()) {
                logger.info("Project " + p.id + " Skipped because project doesn't contains annotations ");
                projectExcludedFromTest.add(p);
                continue;
            }

            Set<Category> categories = getCategories(p);
            logger.info("Project " + p.id + " [" + p.annotations.size() + " annot(s)] is part of " + categories.size() + " categories");

            Set<Category> categoriesEval = new HashSet<Category>();

            for (Category c : categories) {

                logger.info("\tCategory " + c.name + " (" + c.projects.size() + " projects)");
                if (c.projects.size() - 1 == 0) {
                    logger.info("\t\tCannot perform test for category " + c.name + ", set of projects will be empty if tested project is removed");
                } else {
                    categoriesEval.add(c);
                }
            }

            logger.info("\tCategories composing the test " + categoriesEval.size());

            if (categoriesEval.isEmpty()) {
                logger.info("\t[Warning] Test cannot be performed for this project...");
                projectExcludedFromTest.add(p);
                continue;
            }

            logger.info("\t> Retrieving the best " + categoriesEval.size() + " categories exluding project " + p.id + " during evaluation");
            logger.info("\tBuilding categories removing project " + p.id);
            Set<Category> reducedCategories = new HashSet<Category>();
            for (Category c : dataLoader.categoriesMap.values()) {
                Category rCat = (Category) c.clone();
                rCat.removeProject(p);
                reducedCategories.add(rCat);
            }
            logger.info("\tComputed ranked categories (considering reduced ones) ");
            List<IRCatResult> results = computeSimProjectCategories(p, reducedCategories, confPairwise, confGroupwise, categoryRepresentation);

            Map<Double, Set<IRCatResult>> scoreValues = new HashMap<Double, Set<IRCatResult>>();
            for (IRCatResult r : results) {
                logger.info("\t\t" + r.category.name + "\t" + r.score);
                if (!scoreValues.containsKey(r.score)) {
                    scoreValues.put(r.score, new HashSet<IRCatResult>());
                }
                scoreValues.get(r.score).add(r);

            }

            double globalScore = 0;


            logger.info("\tExpected Categories ranking");
            TreeSet<Double> keys = new TreeSet<Double>(scoreValues.keySet());

            Set<Category> categoriesThreshold = new HashSet<Category>();

            for (Double score : keys.descendingSet()) {

                Set<IRCatResult> categoryOfscore = scoreValues.get(score);
                boolean b = false;
                for (IRCatResult r : categoryOfscore) {

                    categoriesThreshold.add(r.category);

                }
                if (categoriesThreshold.size() == MAX_CATEGORY_PER_PROJECT) {
                    b = true;
                    break;
                }
            }

            Set<Category> projectCategories = getCategories(p);

            logger.info("Categories [expected]: " + projectCategories);
            logger.info("Best " + MAX_CATEGORY_PER_PROJECT + ": " + categoriesThreshold);


            if (categoriesThreshold.containsAll(projectCategories)) {
                logger.info("-- Well Ranked");
                wellRankedBoolean++;
            } else {
                logger.info("-- Bad Ranked");
            }



            for (Category c : categoriesEval) {
                int rank = 0;
                IRCatResult catResult = null;
                // search rank
                for (Double score : keys.descendingSet()) {
                    Set<IRCatResult> categoryOfscore = scoreValues.get(score);
                    rank += categoryOfscore.size();
                    boolean f = false;

                    for (IRCatResult r : categoryOfscore) {
                        if (r.category.name.equals(c.name)) {
                            f = true;
                            catResult = r;
                            break;
                        }
                    }
                    if (f) {
                        break;
                    }
                }

                int optReeval = 0;
                String optString = "";
                if (scoreValues.get(catResult.score).size() - 1 != 0) {
                    optReeval = scoreValues.get(catResult.score).size() - 1;
                    optString = " [optimistic " + (rank - optReeval + "/" + results.size()) + " (-" + optReeval + ")] ";
                }
                logger.info("\t\t" + c.name + "\t" + rank + "/" + results.size() + optString + "\t" + catResult.score);
                globalScore = results.size() - (rank - 1);
            }
            //TODO remove something to global score to avoid lower down the score when multiple categories are expected
            globalScore = globalScore / (double) ((double) categoriesEval.size() * (double) results.size());
            double dp = (double) scoreValues.size() / (double) results.size();

            logger.info("\tDiscriminative power: " + dp);
            logger.info("\tGlobal Score: " + globalScore);

            finalScore += globalScore;
            discriminativePower += dp;
        }

        logger.info("Untested projects " + projectExcludedFromTest.size());
        for (Project p : projectExcludedFromTest) {
            logger.info("\t" + p.id);
        }
        double evaluatedProjectsNb = dataLoader.projectMap.values().size() - projectExcludedFromTest.size();
        finalScore = finalScore / evaluatedProjectsNb;
        discriminativePower = discriminativePower / evaluatedProjectsNb;
        logger.info("Final score :" + finalScore);
        logger.info("Discriminative Power :" + discriminativePower);
        double scoreBinary = (double) wellRankedBoolean / (double) dataLoader.projectMap.size();
        logger.info("Well Ranked (cutoff " + MAX_CATEGORY_PER_PROJECT + ") :" + scoreBinary);

        return new LoocvResult(finalScore, discriminativePower);
    }

    private List<IRCatResult> computeSimProjectCategories(Project p, Set<Category> categories, SMconf confPairwise, SMconf confGroupwise, CategoryRepresentation catRepresentation) throws SLIB_Ex_Critic {

        Set<V> conceptsProject = urisToConcepts(p.getAnnotationsAsURIs());

        List<IRCatResult> results = new LinkedList<IRCatResult>();

        for (Category category : categories) {

            double simCat = 0;

            if (catRepresentation == CategoryRepresentation.AS_SET_OF_PROJECTS) {

                for (Project categoryProject : category.getProjects()) {

                    Set<V> conceptsCatProject = urisToConcepts(categoryProject.getAnnotationsAsURIs());
                    double sim = engineMesh.computeGroupwiseAddOnSim(confGroupwise, confPairwise, conceptsProject, conceptsCatProject);
                    simCat += sim;
                }
                simCat = simCat / category.getProjects().size();
            } else if (catRepresentation == CategoryRepresentation.AS_SET_OF_CONCEPTS) {

                Set<V> categoryAsConcepts = getCategoryAsConcepts(category);
                simCat = engineMesh.computeGroupwiseAddOnSim(confGroupwise, confPairwise, conceptsProject, categoryAsConcepts);
            } else if (catRepresentation == CategoryRepresentation.AS_WEIGHTED_SET_OF_CONCEPTS) {

                Set<WeightedAnnot> categoryWeightedConcepts = getCategoryAsWeightedConcepts(category);
                // weighted cosine similarity http://en.wikipedia.org/wiki/Cosine_similarity
                // Normalize the projects annotations weight

                Set<WeightedAnnot> projectNormWeightedAnnots = normalizeProjectAnnotations(p);
                double num = 0;

            } else {
                throw new IllegalArgumentException("Unknown category reprensentation " + catRepresentation);
            }

            results.add(new IRCatResult(simCat, category));
        }

        // sort results
        Collections.sort(results, new Comparator<IRCatResult>() {
            @Override
            public int compare(IRCatResult o1, IRCatResult o2) {
                return (o1.score > o2.score ? -1 : (o1 == o2 ? 0 : 1));
            }
        });
        return results;
    }

    private Set<V> getCategoryAsConcepts(Category category) throws SLIB_Ex_Critic {
        Set<URI> categoryURIs = new HashSet<URI>();
        for (Project p : category.getProjects()) {
            categoryURIs.addAll(p.getAnnotationsAsURIs());
        }
        return urisToConcepts(categoryURIs);
    }

    private Set<WeightedAnnot> getCategoryAsWeightedConcepts(Category category) {

        //logger.info("Representing category "+category.name+" as weighted set of concepts");
        Map<URI, Integer> uriOccurences = new HashMap<URI, Integer>();
        int totalOccurences = 0;
        for (Project p : category.getProjects()) {
            for (WeightedAnnot annot : p.getAnnotations()) {
                if (!uriOccurences.containsKey(annot.concept)) {
                    uriOccurences.put(annot.concept, 0);
                }
                uriOccurences.put(annot.concept, uriOccurences.get(annot.concept) + 1);
                totalOccurences++;
            }
        }

        Set<WeightedAnnot> weightedAnnots = new HashSet<WeightedAnnot>();
        for (Map.Entry<URI, Integer> e : uriOccurences.entrySet()) {
            double p = (double) e.getValue() / (double) totalOccurences;
            WeightedAnnot a = new WeightedAnnot(e.getKey(), p);
            weightedAnnots.add(a);
            //logger.info("\t"+e.getKey()+"\t"+p);
        }

        return weightedAnnots;
    }

    private Set<WeightedAnnot> normalizeProjectAnnotations(Project p) {
        Set<WeightedAnnot> wAnnots = new HashSet<WeightedAnnot>();
        double totalCount = 0;
        for (WeightedAnnot a : p.getAnnotations()) {
            totalCount += a.weight;
        }
        for (WeightedAnnot a : p.getAnnotations()) {
            wAnnots.add(new WeightedAnnot(a.concept, a.weight / totalCount));
        }
        return wAnnots;

    }

    public static void main(String[] a) throws Exception {
        boolean cachePairwise = false;
        StudyCategories study = new StudyCategories(cachePairwise);
        String outfile = "/data/project_categories/cleaned_data/categories_statistics.csv";
        //study.computeStat(outfile);

        ICconf confIC = new IC_Conf_Topo(SMConstants.FLAG_ICI_SANCHEZ_2011_a);

        SMconf confPairwiseLin = new SMconf("Lin", SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998, confIC);
        SMconf confGroupwiseBMA = new SMconf("BMA", SMConstants.FLAG_SIM_GROUPWISE_BMA);

        study.loocv(CategoryRepresentation.AS_SET_OF_CONCEPTS, confPairwiseLin, confGroupwiseBMA);
    }
}
