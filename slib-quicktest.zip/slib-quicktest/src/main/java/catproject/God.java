/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package catproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.sml.sm.core.metrics.ic.utils.IC_Conf_Topo;
import slib.sml.sm.core.metrics.ic.utils.ICconf;
import slib.sml.sm.core.utils.SMConstants;
import slib.sml.sm.core.utils.SMconf;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.impl.Timer;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class God {

    Logger logger = LoggerFactory.getLogger(this.getClass());
    Map<Character, List> characterCollection;
    int attemptToGenerateRandomIndiv = 1000000;
    int mutatingPercent = 50;// percentage of mutation
    int iterationPopGeneration;
    int saveBest;
    Character[] individualsCharacters;
    Set<Individual> individuals;
    Map<LoocvResult, Individual> bestIndividuals;
    Double stopAtFitness;
    int generationCount;
    Integer stopAtGeneration;
    Set<Individual> individualsEvaluated;
    StudyCategories studyCategories;
    Map<Character, Integer> characterPosInChromo;

    public God(boolean cachePairwise) throws Exception {

        characterPosInChromo = new HashMap<Character, Integer>();
        characterPosInChromo.put(Character.PAIRWISE_MEASURE, 0);
        characterPosInChromo.put(Character.GROUPWISE_MEASURE, 1);
        characterPosInChromo.put(Character.IC_CONF, 2);

        studyCategories = new StudyCategories(cachePairwise);
        characterCollection = new HashMap<Character, List>();
        characterCollection.put(Character.PAIRWISE_MEASURE, new ArrayList<SMconf>());
        characterCollection.put(Character.GROUPWISE_MEASURE, new ArrayList<SMconf>());
        characterCollection.put(Character.IC_CONF, new ArrayList<ICconf>());

        individualsCharacters = Character.values();
        bestIndividuals = new HashMap<LoocvResult, Individual>();
        individualsEvaluated = new HashSet<Individual>();
    }

    public void createWorld(int initPopulation, int saveBest, int iterationPopGeneration, Double stopAtFitness, Integer stopAtGeneration) throws SLIB_Ex_Critic, CloneNotSupportedException {

        this.iterationPopGeneration = iterationPopGeneration;
        this.saveBest = saveBest;
        this.stopAtFitness = stopAtFitness;
        this.stopAtGeneration = stopAtGeneration;
        logger.info("Create initial population of size " + initPopulation);
        individuals = createInitPopulation(initPopulation);
        logger.info("Initial population created");

        nextGeneration();
    }

    public void addPairwiseConf(SMconf c) {
        characterCollection.get(Character.PAIRWISE_MEASURE).add(c);
    }

    public void addGroupwiseConf(SMconf c) {
        characterCollection.get(Character.GROUPWISE_MEASURE).add(c);
    }

    private void addICconf(ICconf c) {
        characterCollection.get(Character.IC_CONF).add(c);
    }

    private Set<Individual> createInitPopulation(int initPopulation) throws SLIB_Ex_Critic {
        individuals = new HashSet<Individual>();
        int c = 0;
        Random r = new Random();
        while (c < attemptToGenerateRandomIndiv && individuals.size() != initPopulation) {
            c++;
            int pairwiseID = r.nextInt(characterCollection.get(Character.PAIRWISE_MEASURE).size());
            int groupwiseID = r.nextInt(characterCollection.get(Character.GROUPWISE_MEASURE).size());
            int icID = r.nextInt(characterCollection.get(Character.IC_CONF).size());

            Individual i = new Individual(pairwiseID, groupwiseID, icID);

            if (!individuals.contains(i)
                    && isViableIndividual(i)) {

                individuals.add(i);
                logger.info("Adding individual " + i);
            }

        }

        if (c == attemptToGenerateRandomIndiv) {
            throw new SLIB_Ex_Critic("Error cannot generate the " + initPopulation + " individuals in " + attemptToGenerateRandomIndiv + " attempts");
        }


        individualsEvaluated.addAll(individuals);
        return individuals;
    }

    /**
     * Do not check if generated individual is viable
     *
     * @param indiv
     * @return
     */
    private Individual mutateIndividual(Individual indiv) {
        Individual indivCopy = indiv.copy();
        Random r = new Random();
        int i = r.nextInt(individualsCharacters.length);
        Character c = individualsCharacters[i];
        int j = r.nextInt(characterCollection.get(c).size());
        indivCopy.setCharacter(c, j);
        return indivCopy;
    }

    private boolean isViableIndividual(Individual i) {
        return true;
    }

    private void nextGeneration() throws SLIB_Ex_Critic, CloneNotSupportedException {
        generationCount++;
        logger.info("Starting generation " + generationCount);

        Map<LoocvResult, Individual> resultsFitness = new HashMap<LoocvResult, Individual>();

        for (Individual i : individuals) {
            LoocvResult r = computeFitness(i);
            resultsFitness.put(r, i);
            logger.info("\tFitness\t" + r.result + "\t" + i);
        }

        // Select best Results
        logger.info("Selecting best " + iterationPopGeneration + " individuals");
        Map<LoocvResult, Individual> bestIndivsIteration = new HashMap<LoocvResult, Individual>();

        TreeSet<LoocvResult> keys = new TreeSet<LoocvResult>(resultsFitness.keySet());

        for (LoocvResult score : keys.descendingSet()) {

            if (bestIndivsIteration.size() <= iterationPopGeneration) {
                logger.info("\t" + resultsFitness.get(score) + "\t" + score.result);
                bestIndivsIteration.put(score, resultsFitness.get(score));
            }
        }

        logger.info("Best  " + bestIndivsIteration.size() + " results selected");
        saveBestEver(bestIndivsIteration);

        if (!endOfWorld()) {

            evolve(new HashSet(bestIndividuals.values()));
            nextGeneration();
        } else {
            logger.info("End of Process");
            logger.info("Best results");
            TreeSet<LoocvResult> k = new TreeSet<LoocvResult>(bestIndividuals.keySet());

            for (LoocvResult score : k.descendingSet()) {
                logger.info("\t" + bestIndividuals.get(score) + "\t" + score.getResult());
            }
        }
    }

    private void saveBestEver(Map<LoocvResult, Individual> indivs) {
        bestIndividuals.putAll(indivs);

        TreeSet<LoocvResult> keys = new TreeSet<LoocvResult>(bestIndividuals.keySet());
        Map<LoocvResult, Individual> bestEver = new HashMap<LoocvResult, Individual>();
        for (LoocvResult score : keys.descendingSet()) {
            bestEver.put(score, bestIndividuals.get(score));
            if (bestEver.size() == saveBest) {
                break;
            }
        }
        bestIndividuals.clear();
        bestIndividuals.putAll(bestEver);

    }

    private void evolve(Set<Individual> indivs) throws SLIB_Ex_Critic {

        individuals.clear();
        ArrayList<Individual> indivList = new ArrayList<Individual>(indivs);
        Random chance = new Random();

        for (Individual i : indivs) {

            logger.info("Life striking " + i);

            Individual newIndiv = null;
            int c = 0;

            if (chance.nextInt(100) < mutatingPercent) {
                logger.info("\tmutating");

                newIndiv = mutateProcess(i);



            } else {

                int idMate = chance.nextInt(indivs.size());
                logger.info("\tcross over");

                while (newIndiv == null && c < attemptToGenerateRandomIndiv) {

                    c++;
                    while (indivList.get(idMate).equals(i)) {
                        idMate = chance.nextInt(indivs.size());
                    }

                    Individual mate = indivList.get(idMate);
                    newIndiv = crossOver(i, mate);

                    if (individualsEvaluated.contains(newIndiv) || !isViableIndividual(newIndiv)) {
                        newIndiv = null;
                    }
                }

                // we try to generate a mutation to avoid to be stuck on local optima
                // if cross over faild
                if (newIndiv == null) {
                    logger.info("Cross Over fails try to mutate the individual");
                    newIndiv = mutateProcess(i);
                }
            }



            logger.info("\t\tresult: " + newIndiv);
            individuals.add(newIndiv);
        }

        // to remove when cross over generated individuals are added
        individualsEvaluated.addAll(individuals);

        logger.info("" + individuals);
    }

    private Individual mutateProcess(Individual i) throws SLIB_Ex_Critic {
        Individual newIndiv = null;
        int c = 0;
        while (newIndiv == null && c < attemptToGenerateRandomIndiv) {

            c++;
            newIndiv = mutateIndividual(i);

            if (individualsEvaluated.contains(newIndiv) || !isViableIndividual(newIndiv)) {
                newIndiv = null;
            }

        }

        if (c == attemptToGenerateRandomIndiv) {
            throw new SLIB_Ex_Critic("Cannot generate new indidividual based on mutation" + attemptToGenerateRandomIndiv);
        }

        return newIndiv;
    }

    private LoocvResult computeFitness(Individual i) throws SLIB_Ex_Critic, CloneNotSupportedException {

        logger.info("Computing Fitness results for individual " + i);

        ICconf icConf = (ICconf) characterCollection.get(Character.IC_CONF).get(i.getCharacter(Character.IC_CONF));
        SMconf confPairwise = (SMconf) characterCollection.get(Character.PAIRWISE_MEASURE).get(i.getCharacter(Character.PAIRWISE_MEASURE));
        confPairwise.setICconf(icConf);

        SMconf confGroupwise = (SMconf) characterCollection.get(Character.GROUPWISE_MEASURE).get(i.getCharacter(Character.GROUPWISE_MEASURE));

        logger.info("IC  measure  " + icConf.className);
        logger.info("Pairwise  measure  " + confPairwise.className);
        logger.info("Groupwise measure  " + confGroupwise.className);
        return studyCategories.loocv(CategoryRepresentation.AS_SET_OF_PROJECTS, confPairwise, confGroupwise);

    }

    private boolean endOfWorld() {


        if (stopAtFitness != null) {

            for (LoocvResult r : bestIndividuals.keySet()) {
                if (r.result >= stopAtFitness) {
                    logger.info("Fitness restriction reached at generation " + generationCount);
                    return true;
                }
            }
        }
        if (stopAtGeneration != null && generationCount >= stopAtGeneration) {
            logger.info("Generation limit reached at generation " + generationCount);
            return true;
        }
        return false;
    }

    public Map<LoocvResult, Individual> getBestIndividuals() {
        return bestIndividuals;
    }

    public Set<Individual> getTestedIndividuals() {
        return individualsEvaluated;
    }

    private Individual crossOver(Individual i, Individual j) {

        Random r = new Random();

        String male = r.nextInt(2) == 0 ? i.toString() : j.toString();
        String female = male.equals(i.toString()) ? j.toString() : i.toString();

        int split = new Random().nextInt(male.length() - 1) + 1;

        String newIndivCharacters = male.substring(0, split) + female.substring(split);

        int[] characterIds = new int[newIndivCharacters.length()];

        for (int k = 0; k < characterIds.length; k++) {
            characterIds[k] = Integer.parseInt(newIndivCharacters.charAt(k) + "");
        }
        int idPairwise = characterPosInChromo.get(Character.PAIRWISE_MEASURE);
        int idGroupwise = characterPosInChromo.get(Character.GROUPWISE_MEASURE);
        int idIC = characterPosInChromo.get(Character.IC_CONF);
        Individual breed = new Individual(characterIds[idPairwise], characterIds[idGroupwise], characterIds[idIC]);

        return breed;
    }

    public static void main(String[] a) throws SLIB_Ex_Critic, Exception {

        ICconf confIC_Seco = new IC_Conf_Topo(SMConstants.FLAG_ICI_SECO_2004);
//        ICconf confIC_prob = new IC_Conf_Topo(SMConstants.FLAG_ICI_PROB_OCCURENCE);
//        ICconf confIC_prob_prob = new IC_Conf_Topo(SMConstants.FLAG_ICI_PROB_OCCURENCE_PROPAGATED);
//        ICconf confIC_depthMin = new IC_Conf_Topo(SMConstants.FLAG_ICI_DEPTH_MIN_NONLINEAR);
//        ICconf confIC_depthMax = new IC_Conf_Topo(SMConstants.FLAG_ICI_DEPTH_MAX_NONLINEAR);
//        ICconf confIC_resnik = new IC_Conf_Topo(SMConstants.FLAG_ICI_RESNIK_1995);
//        ICconf confIC_sanchez = new IC_Conf_Topo(SMConstants.FLAG_ICI_SANCHEZ_2011_a);

        SMconf confPairwiseLin = new SMconf("Lin", SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998, (ICconf) null);
        SMconf confPairwiseResnik = new SMconf("Resnik", SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_RESNIK_1995, (ICconf) null);
        SMconf confPairwiseJC = new SMconf("JC", SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_JIANG_CONRATH_1997_NORM, (ICconf) null);



        SMconf confGroupwiseBMA = new SMconf("BMA", SMConstants.FLAG_SIM_GROUPWISE_BMA);
        SMconf confGroupwiseAVERAGE = new SMconf("AVERAGE", SMConstants.FLAG_SIM_GROUPWISE_AVERAGE);
        SMconf confGroupwiseMIN = new SMconf("MIN", SMConstants.FLAG_SIM_GROUPWISE_MIN);
        SMconf confGroupwiseMAX = new SMconf("MAX", SMConstants.FLAG_SIM_GROUPWISE_MAX);

        boolean cachePairwise = false;

        God god = new God(cachePairwise);

        god.addICconf(confIC_Seco);
//        god.addICconf(confIC_prob);
//        god.addICconf(confIC_prob_prob);
//        god.addICconf(confIC_depthMin);
//        god.addICconf(confIC_depthMax);
//        god.addICconf(confIC_resnik);
//        god.addICconf(confIC_sanchez);


        god.addPairwiseConf(confPairwiseLin);
        god.addPairwiseConf(confPairwiseResnik);
        god.addPairwiseConf(confPairwiseJC);

        god.addGroupwiseConf(confGroupwiseBMA);
        god.addGroupwiseConf(confGroupwiseMIN);
        god.addGroupwiseConf(confGroupwiseMAX);
        god.addGroupwiseConf(confGroupwiseAVERAGE);


        int initPopulation = 6;
        int saveBest = 10;
        int iterationPopGeneration = 1000000000;
        Double stopAtFitness = 0.7;
        Integer stopAtGeneration = 10;

        Timer t = new Timer();
        t.start();

        try {
            god.createWorld(initPopulation, saveBest, iterationPopGeneration, stopAtFitness, stopAtGeneration);


        } catch (Exception e) {

            e.printStackTrace();
            System.out.println("End due to " + e.getMessage());
        } finally {
            System.out.println("End of process " + god.getTestedIndividuals().size() + " individuals tested");
            TreeSet<LoocvResult> keys = new TreeSet<LoocvResult>(god.getBestIndividuals().keySet());

            for (LoocvResult score : keys.descendingSet()) {
                System.out.println("\t" + god.getBestIndividuals().get(score) + "\t" + score.result);
            }
            t.elapsedTime();
        }

    }
}
