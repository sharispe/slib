/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package catproject;

import catproject.Character;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class Individual {

    private Map<Character, Integer> charactersMap;
    private String stringVal;

    public Individual(int pairwiseSim, int groupwiseSim, int icID) {

        charactersMap = new HashMap();
        charactersMap.put(Character.PAIRWISE_MEASURE, pairwiseSim);
        charactersMap.put(Character.GROUPWISE_MEASURE, groupwiseSim);
        charactersMap.put(Character.IC_CONF, icID);
        computeStringVal();
    }

    private void computeStringVal() {
        
        // !!! The order is critical see characterPosInChromo in God
        stringVal = getCharacter(Character.PAIRWISE_MEASURE) + ""
                + getCharacter(Character.GROUPWISE_MEASURE) + ""
                + getCharacter(Character.IC_CONF) + "";
    }

    public Integer getCharacter(Character i) {
        return charactersMap.get(i);
    }

    @Override
    public String toString() {
        return stringVal;
    }

    /**
     * ******************************************************
     * !!! ADD Other parameters to equal / hashcode
     *
     */
    void setCharacter(Character c, int val) {
        charactersMap.put(c, val);
        computeStringVal();
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + (this.stringVal != null ? this.stringVal.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Individual other = (Individual) obj;
        if ((this.stringVal == null) ? (other.stringVal != null) : !this.stringVal.equals(other.stringVal)) {
            return false;
        }
        return true;
    }

    public Individual copy() {
        return new Individual(getCharacter(Character.PAIRWISE_MEASURE), getCharacter(Character.GROUPWISE_MEASURE), getCharacter(Character.IC_CONF));
    }
}
