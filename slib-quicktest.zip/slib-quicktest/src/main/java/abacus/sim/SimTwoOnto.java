/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;

import abacus.sim.benchmarkBuilder.Pair;
import abacus.sim.results.ResultLoader;
import abacus.sim.utils.CoupleOfConcepts;
import abacus.sim.utils.CoupleOfConceptsScored;
import abacus.sim.utils.QueryBinaryOnto;
import fr.lgi2p.kid.quicktest.mapping.Mapping;
import fr.lgi2p.kid.quicktest.mapping.MappingsCollectionSymmetric;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.openrdf.model.URI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.indexer.IndexHash;
import slib.indexer.IndexedElement;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.V;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.sml.sm.core.measures.graph.pairwise.dag.node_based.Sim_pairwise_DAG_node_Jiang_Conrath_1997;
import slib.sml.sm.core.measures.graph.pairwise.dag.node_based.Sim_pairwise_DAG_node_Lin_1998;
import slib.sml.sm.core.metrics.ic.utils.IC_Conf_Topo;
import slib.sml.sm.core.metrics.ic.utils.ICconf;
import slib.sml.sm.core.utils.SMConstants;
import slib.sml.sm.core.utils.SM_Engine;
import slib.sml.sm.core.utils.SMconf;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;
import slib.utils.impl.ResultStack;
import slib.utils.impl.SetUtils;
import slib.utils.impl.Timer;

/**
 * Class used to test the similarities.
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class SimTwoOnto {

    Logger logger = LoggerFactory.getLogger(this.getClass());
    DataFactory factory;
    long ontoUnionSize;
    MappingsCollectionSymmetric mappings;
    Map<URI, SM_Engine> engineCollection;
    private Double CONSTANT_NORM_IC = 0.9;
    private double CUTOFF_NPMI = -1; // set cut off to negative value to avoid cutting off

    public SimTwoOnto(G ontoA, G ontoB, MappingsCollectionSymmetric mappings, LinkedHashSet<QueryBinaryOnto> queries) throws Exception {

        factory = DataFactoryMemory.getSingleton();
        this.mappings = mappings;


        engineCollection = new HashMap<URI, SM_Engine>();
        engineCollection.put(ontoA.getURI(), new SM_Engine(ontoA));
        engineCollection.put(ontoB.getURI(), new SM_Engine(ontoB));

        logger.info("Information about compared Graphs...");

        logger.info("Loading Graphs' concepts Union ");
        ontoUnionSize = SetUtils.union(ontoA.getV(), ontoB.getV()).size();
        logger.info("Union : " + ontoUnionSize);

        logger.info("Loading Graphs' concepts Intersection ");
        // correct intersection considering mapping.
        long intersection = 0;
        for (URI uri : mappings.getMappings().keySet()) {
            if (ontoA.containsVertex(uri)) {
                intersection++;
            }
        }
        ontoUnionSize -= intersection;
    }

    public HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> computeBestMappingsNPMI(LinkedHashSet<QueryBinaryOnto> queries, boolean useRestrictions) throws SLIB_Ex_Critic, SLIB_Exception {

        HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI = new HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored>();

        for (QueryBinaryOnto query : queries) {

            logger.info(query.getCA_Desc() + "\t" + query.getCB_Desc());


            for (URI uriAinOnto1 : query.getA_onto1()) {

                for (URI uriBinOnto2 : query.getB_onto2()) {

                    Set<CoupleOfConceptsScored> coupleOfConcepts;

                    if (useRestrictions) {
                        coupleOfConcepts = computeBestLCS_NPMI_REDUCED_TO_BEST_MAPPING(uriAinOnto1, uriBinOnto2, query.getOnto1().getURI(), query.getOnto2().getURI());
                    } else {
                        coupleOfConcepts = computeBestLCS_NPMI(uriAinOnto1, uriBinOnto2, query.getOnto1().getURI(), query.getOnto2().getURI());
                    }

                    CoupleOfConceptsScored coupleLCS = getBestNPMI(coupleOfConcepts);

                    KEY_BEST_MAPPING keyC1_C2 = new KEY_BEST_MAPPING(uriAinOnto1, uriBinOnto2);
                    KEY_BEST_MAPPING keyC2_C1 = new KEY_BEST_MAPPING(uriBinOnto2, uriAinOnto1);

                    bestMappingsNPMI.put(keyC1_C2, coupleLCS);
                    bestMappingsNPMI.put(keyC2_C1, coupleLCS);
                }
            }

            for (URI uriAinOnto2 : query.getA_onto2()) {

                for (URI uriBinOnto1 : query.getB_onto1()) {

                    Set<CoupleOfConceptsScored> coupleOfConcepts;

                    if (useRestrictions) {
                        coupleOfConcepts = computeBestLCS_NPMI_REDUCED_TO_BEST_MAPPING(uriAinOnto2, uriBinOnto1, query.getOnto2().getURI(), query.getOnto1().getURI());
                    } else {
                        coupleOfConcepts = computeBestLCS_NPMI(uriAinOnto2, uriBinOnto1, query.getOnto2().getURI(), query.getOnto1().getURI());
                    }

                    CoupleOfConceptsScored coupleLCS = getBestNPMI(coupleOfConcepts);

                    KEY_BEST_MAPPING keyC1_C2 = new KEY_BEST_MAPPING(uriBinOnto1, uriAinOnto2);
                    KEY_BEST_MAPPING keyC2_C1 = new KEY_BEST_MAPPING(uriAinOnto2, uriBinOnto1);

                    bestMappingsNPMI.put(keyC1_C2, coupleLCS);
                    bestMappingsNPMI.put(keyC2_C1, coupleLCS);
                }
            }
        }

        return bestMappingsNPMI;
    }

    private double computePairwiseSim(MEASURE_FLAG pairwiseMeasure, double icA, double icB, double IC_LCS_VA_VB) throws SLIB_Exception {

        double sim = 0;

        if (pairwiseMeasure == MEASURE_FLAG.LIN) {

            Sim_pairwise_DAG_node_Lin_1998 lin = new Sim_pairwise_DAG_node_Lin_1998();
            lin.setPreventIncoherency(false);
            sim = lin.sim(icA, icB, IC_LCS_VA_VB);

        } else if (pairwiseMeasure == MEASURE_FLAG.JC) {

            Sim_pairwise_DAG_node_Jiang_Conrath_1997 jc = new Sim_pairwise_DAG_node_Jiang_Conrath_1997();
            sim = jc.sim(icA, icB, IC_LCS_VA_VB);

        } else if (pairwiseMeasure == MEASURE_FLAG.RESNIK) {

            sim = IC_LCS_VA_VB;

        }


        return sim;
    }

    private Set<V> getAncestors(URI conceptURI, G graph) {

        SM_Engine engine = engineCollection.get(graph.getURI());
        return engine.getAncestorsInc(graph.getV(conceptURI));
    }

    private Set<V> getDescendants(URI conceptURI, G graph) {

        SM_Engine engine = engineCollection.get(graph.getURI());
        return engine.getDescendantsInc(graph.getV(conceptURI));
    }

    /**
     * Compute the NPMI score for a given couple of concepts
     *
     * @param couple the couple of concepts to compute the NPMI for
     * @param unionOntoSize the size of the union between the two ontologies
     * @return the NPMI score for the given couple of concepts
     * @throws SLIB_Exception
     */
    public double computeNMPI(CoupleOfConcepts couple, double unionOntoSize) throws SLIB_Exception {

        logger.debug("\tComputing NMPI");


        G gA = factory.getGraph(couple.getGraph_A());
        G gB = factory.getGraph(couple.getGraph_B());

        URI uriAncA = couple.getA();
        URI uriAncB = couple.getB();

        logger.debug("\tAnc A: " + uriAncA + " [" + gA.getURI() + "]");
        logger.debug("\tAnc B: " + uriAncB + " [" + gB.getURI() + "]");

        Set<V> descAncA = getDescendants(uriAncA, gA);
        Set<V> descAncB = getDescendants(uriAncB, gB);

        Set<Mapping> commonDescs = getMappingsAmongDescendants(descAncA, descAncB, couple);

        double descA_nb = descAncA.size();
        double descB_nb = descAncB.size();
        double descCommonNb = commonDescs.size();

        logger.debug("\tCommon Descendants considering mapping : " + descCommonNb);
        logger.debug("\tDesc Anc A " + descA_nb);
        logger.debug("\tDesc Anc B " + descB_nb);
        logger.debug("\tUnion Onto Size " + unionOntoSize);

        double nom = unionOntoSize * (descCommonNb / (descA_nb * descB_nb));
        double den = descCommonNb / unionOntoSize;

        if (unionOntoSize == 0) {
            throw new SLIB_Ex_Critic("Exception cannot be set to 0");
        }

        logger.debug("\tNominator   : " + nom);
        logger.debug("\tDenominator : " + den);

        logger.debug("\tNominator   [log] : " + -Math.log(nom));
        logger.debug("\tDenominator [log] : " + Math.log(den));

        double npmi = 0;

        if (descCommonNb != 0) {
            npmi = -Math.log(nom) / Math.log(den);
        } else {
            logger.debug("NPMI set to 0 because no mapping found in desc(X) x desc(Y)");
        }
        logger.debug("*** NPMI   " + npmi);
        return npmi;
    }

    private Set<Mapping> getMappingsAmongDescendants(Set<V> descX, Set<V> descY, CoupleOfConcepts couple) {

        logger.debug("\tSearching Common Descendants for " + couple.getA() + " vs " + couple.getB());

        G gA = factory.getGraph(couple.getGraph_A());
        G gB = factory.getGraph(couple.getGraph_B());

        logger.debug("\tConcept X     : " + couple.getA() + " [" + gA.getURI() + "]");
        logger.debug("\tDescendants X : " + descX.size());

        logger.debug("\tConcept Y     : " + couple.getB() + " [" + gB.getURI() + "]");
        logger.debug("\tDescendants Y : " + descY.size());



        logger.debug("\tSearch mapping between couples of Descendants");

        return getMappings(descX, descY, gB);
    }

    public static MappingsCollectionSymmetric loadMapping(String mappingFile, G graph_mesh, G graph_snomed) throws Exception {


        Logger logger = LoggerFactory.getLogger(SimTwoOnto.class.getClass());

        MappingsCollectionSymmetric mapCol = new MappingsCollectionSymmetric();


        FileInputStream fstream = new FileInputStream(mappingFile);
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;

        while ((line = br.readLine()) != null) {


            String[] data = line.trim().split("\t");

            URI uri_a = DataFactoryMemory.getSingleton().createURI(data[0]);
            URI uri_b = DataFactoryMemory.getSingleton().createURI(data[1]);

            G g_a = null;
            G g_b = null;

            if (graph_mesh.containsVertex(uri_a)) {
                g_a = graph_mesh;
            } else if (graph_snomed.containsVertex(uri_a)) {
                g_a = graph_snomed;
            }

            if (graph_mesh.containsVertex(uri_b)) {
                g_b = graph_mesh;
            } else if (graph_snomed.containsVertex(uri_b)) {
                g_b = graph_snomed;
            }

            if (g_a == null) {
                logger.warn("Cannot locate graph vertex for URI " + uri_a + "\n" + line);
                continue;
            }
            if (g_b == null) {
                logger.warn("Cannot locate graph vertex for URI " + uri_b + "\n" + line);
                continue;
            }

            if (g_a == g_b) {
                logger.warn("Intra mapping not allowed in graph " + g_a.getURI() + "\n" + line);
                continue;
            }

            Mapping map = new Mapping(uri_a, uri_b, g_a.getURI(), g_b.getURI());
            mapCol.addMapping(map);
        }

        in.close();

        return mapCol;
    }

    private double computeSimOneOnto(MeasureConfig mConfig, URI uriA, URI uriB, G onto) throws SLIB_Ex_Critic {

        V vA = onto.getV(uriA);
        V vB = onto.getV(uriB);

        if (vA == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriA + " in graph " + onto.getURI());
        }
        if (vB == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriB + " in graph " + onto.getURI());
        }

        SM_Engine engine = engineCollection.get(onto.getURI());

        SMconf pairwiseConf;

        if (mConfig.pairwiseMeasure == MEASURE_FLAG.LIN) {
            pairwiseConf = new SMconf("Lin_" + mConfig.icConf.id, SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998, mConfig.icConf);

        } else if (mConfig.pairwiseMeasure == MEASURE_FLAG.JC) {
            pairwiseConf = new SMconf("JC_" + mConfig.icConf.id, SMConstants.FLAG_DIST_PAIRWISE_DAG_NODE_JIANG_CONRATH_1997, mConfig.icConf);

        } else if (mConfig.pairwiseMeasure == MEASURE_FLAG.RESNIK) {
            pairwiseConf = new SMconf("Resnik_" + mConfig.icConf.id, SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_RESNIK_1995, mConfig.icConf);

        } else {
            throw new SLIB_Ex_Critic(" Measure " + mConfig.pairwiseMeasure + " not supported in this context");
        }

        double score = engine.computePairwiseSim(pairwiseConf, vA, vB);

        logger.info(uriA + "\t" + uriB + "\t" + score);
        logger.info("#############################################################################");

        return score;

    }

    private Set<CoupleOfConceptsScored> computeBestLCS_NPMI(URI uriA_Onto1, URI uriB_onto2, URI uriOnto1, URI uriOnto2) throws SLIB_Ex_Critic, SLIB_Exception {

        if (uriOnto1.equals(uriOnto2)) {
            throw new SLIB_Ex_Critic("Error compared concepts are expressed in the same ontology");
        }

        logger.info("Retrieving best mapping considering NPMI and restrictions defined by the mappings defined in A(c1) x A(c2)");

        G onto1 = factory.getGraph(uriOnto1);
        G onto2 = factory.getGraph(uriOnto2);

        V vA = onto1.getV(uriA_Onto1);
        V vB = onto2.getV(uriB_onto2);

        if (vA == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriA_Onto1 + " in graph " + onto1.getURI());
        }
        if (vB == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriB_onto2 + " in graph " + onto2.getURI());
        }

        logger.info("Expressed in different ontologies");

        logger.info("Computing A & B ancestors");
        Set<V> ancestors_A = getAncestors(uriA_Onto1, onto1);
        Set<V> ancestors_B = getAncestors(uriB_onto2, onto2);

        long totalCount = ancestors_A.size() * ancestors_B.size();

        logger.info("Search Best NPMI Comparison, to do (no restrictions): " + ((ancestors_A.size() * ancestors_B.size())));
        logger.info("Search space contains " + totalCount + " couples ");

        logger.info("Search terminological mapping(s) defined in A(c1) x A(c2)");

        Set<Mapping> mappingAncestors = getMappings(ancestors_A, ancestors_B, onto2);
        logger.info("Found " + mappingAncestors.size() + " mapping(s)");

        /*
         * We first compute the couples builds from A(c1) * A(c2)
         * in order to define the search space in which the reduction must 
         * be applied
         */
        Set<CoupleOfConceptsScored> largeSearchSpace = new HashSet<CoupleOfConceptsScored>();

        for (V anc_A : ancestors_A) {

            for (V anc_B : ancestors_B) {

                CoupleOfConceptsScored c = new CoupleOfConceptsScored((URI) anc_A.getValue(), (URI) anc_B.getValue(), onto1.getURI(), onto2.getURI(), null);
                CoupleOfConceptsScored c_inverse = new CoupleOfConceptsScored((URI) anc_B.getValue(), (URI) anc_A.getValue(), onto2.getURI(), onto1.getURI(), null);


                boolean isTerminologicalMapping = false;

                // Search if the couple of Concepts is defined as a terminological mapping
                for (Mapping map : mappingAncestors) {

                    // dirty
                    Mapping cm = new Mapping(c);
                    Mapping cm_inverse = new Mapping(c_inverse);


                    if (map.equals(cm) || map.equals(cm_inverse)) {
                        isTerminologicalMapping = true;
                    }
                }

                c.setIsTerminologicalMapping(isTerminologicalMapping);
                c.setExistTerminologicalMappingAmongAncestors(!mappingAncestors.isEmpty());

                largeSearchSpace.add(c);
            }
        }

        logger.info("Non reduced Search space contains " + largeSearchSpace.size() + " couple(s)");



        return largeSearchSpace;
    }

    private Set<CoupleOfConceptsScored> computeBestLCS_NPMI_REDUCED_TO_BEST_MAPPING(URI uriA_Onto1, URI uriB_onto2, URI uriOnto1, URI uriOnto2) throws SLIB_Ex_Critic, SLIB_Exception {

        if (uriOnto1.equals(uriOnto2)) {
            throw new SLIB_Ex_Critic("Error compared concepts are expressed in the same ontology");
        }

        logger.info("Retrieving best mapping considering NPMI and restrictions defined by the mappings defined in A(c1) x A(c2)");

        G onto1 = factory.getGraph(uriOnto1);
        G onto2 = factory.getGraph(uriOnto2);

        V vA = onto1.getV(uriA_Onto1);
        V vB = onto2.getV(uriB_onto2);

        if (vA == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriA_Onto1 + " in graph " + onto1.getURI());
        }
        if (vB == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriB_onto2 + " in graph " + onto2.getURI());
        }

        logger.info("Expressed in different ontologies");

        logger.info("Computing A & B ancestors");
        Set<V> ancestors_A = getAncestors(uriA_Onto1, onto1);
        Set<V> ancestors_B = getAncestors(uriB_onto2, onto2);

        long totalCount = ancestors_A.size() * ancestors_B.size();

        logger.info("Search Best NPMI Comparison, to do (no restrictions): " + ((ancestors_A.size() * ancestors_B.size())));
        logger.info("Search space contains " + totalCount + " couples ");

        logger.info("Search terminological mapping(s) defined in A(c1) x A(c2)");

        Set<Mapping> mappingAncestors = getMappings(ancestors_A, ancestors_B, onto2);
        logger.info("Found " + mappingAncestors.size() + " mapping(s)");

        /*
         * We first compute the couples builds from A(c1) * A(c2)
         * in order to define the search space in which the reduction must 
         * be applied
         */
        Set<CoupleOfConceptsScored> largeSearchSpace = new HashSet<CoupleOfConceptsScored>();

        for (V anc_A : ancestors_A) {

            for (V anc_B : ancestors_B) {

                CoupleOfConceptsScored couple = new CoupleOfConceptsScored((URI) anc_A.getValue(), (URI) anc_B.getValue(), onto1.getURI(), onto2.getURI(), null);
                largeSearchSpace.add(couple);
            }
        }

        logger.info("Non reduced Search space contains " + largeSearchSpace.size() + " couple(s)");

        Set<CoupleOfConceptsScored> couplesOfConceptsToEvaluate = new HashSet<CoupleOfConceptsScored>();

        if (mappingAncestors.isEmpty()) {

            couplesOfConceptsToEvaluate = largeSearchSpace;

        } else { // We apply the restrictions defined by the terminological mappings

            logger.info("Reducing the search space taking into consideration the terminological mappings");
            /*
             * For each terminological mappings <c1,c2> we consider the couples 
             * found in D(c1) x D(c2) defined in the complete search space as eligible couples
             */
            for (Mapping m : mappingAncestors) {

                logger.info("--------------------------------------------------------------------------------");
                logger.info("Mapping " + m);
                logger.info("--------------------------------------------------------------------------------");

                G ontoA = engineCollection.get(m.getGraph_A()).getGraph();
                G ontoB = engineCollection.get(m.getGraph_B()).getGraph();
                Set<V> descA = getDescendants(m.getA(), ontoA);
                Set<V> descB = getDescendants(m.getB(), ontoB);

                for (V vDescA : descA) {
                    for (V vDescB : descB) {
                        CoupleOfConceptsScored c = new CoupleOfConceptsScored((URI) vDescA.getValue(), (URI) vDescB.getValue(), ontoA.getURI(), ontoB.getURI(), null);
                        CoupleOfConceptsScored c_inverse = new CoupleOfConceptsScored((URI) vDescB.getValue(), (URI) vDescA.getValue(), ontoB.getURI(), ontoA.getURI(), null);

                        /* the couple of concepts or its inverse is:
                         * - defined in the large search space
                         * - not already in the set of couples to evaluate
                         */
                        if ((largeSearchSpace.contains(c) || largeSearchSpace.contains(c_inverse))
                                && (!couplesOfConceptsToEvaluate.contains(c) && !couplesOfConceptsToEvaluate.contains(c_inverse))) {

                            boolean isTerminologicalMapping = false;

                            // Search if the couple of Concepts is defined as a terminological mapping
                            for (Mapping map : mappingAncestors) {

                                // dirty
                                Mapping cm = new Mapping(c);
                                Mapping cm_inverse = new Mapping(c_inverse);


                                if (map.equals(cm) || map.equals(cm_inverse)) {
                                    isTerminologicalMapping = true;
                                }
                            }

                            c.setIsTerminologicalMapping(isTerminologicalMapping);
                            c.setExistTerminologicalMappingAmongAncestors(true);
                            couplesOfConceptsToEvaluate.add(c);

                            logger.info("Add Couple of concepts : " + c);
                            logger.info("Terminological Mapping  : " + c.isIsTerminologicalMapping());
                            logger.info("Exist terminological mapping among ancestors  : " + c.existTerminologicalMappingAmongAncestors());
                        }
                    }
                }
            }
            logger.info("Reduces Search space contains " + couplesOfConceptsToEvaluate.size() + " couples to evaluate");
        }

        return couplesOfConceptsToEvaluate;
    }

    /**
     * Do not support multiple couples having the same NPMI If multiple couples
     * have the same best NPMI the first one will be retrieve
     *
     * @param couplesOfConceptsToEvaluate
     * @return
     * @throws SLIB_Exception
     */
    public CoupleOfConceptsScored getBestNPMI(Set<CoupleOfConceptsScored> couplesOfConceptsToEvaluate) throws SLIB_Exception {

        logger.info("Computing best NPMI couples among " + couplesOfConceptsToEvaluate.size() + " couples");


        Double bestNPMI = null;


        long done = 0;
        CoupleOfConceptsScored coupleLCS = null;

        for (CoupleOfConceptsScored c : couplesOfConceptsToEvaluate) {

            done++;
            logger.debug("--------------------------------------");
            logger.debug("Processing " + done + "/" + couplesOfConceptsToEvaluate.size());
            logger.debug("--------------------------------------");

            double npmi = computeNMPI(c, ontoUnionSize);

            c.setScore(npmi);

            if (bestNPMI == null || npmi > bestNPMI) {
                bestNPMI = npmi;
                coupleLCS = c;
            }
        }


        logger.info("-----------------------------------------------");
        logger.info("LCS Couple selected ");
        logger.info("[NPMI] " + coupleLCS.getScore());
        logger.info("" + coupleLCS);


        return coupleLCS;
    }

    private CoupleOfConcepts getBestMappingAmongAncestors(ICconf icConf, URI uriA_Onto1, URI uriB_Onto2, G onto1, G onto2) throws SLIB_Ex_Critic, SLIB_Exception {

        V vA = onto1.getV(uriA_Onto1);
        V vB = onto2.getV(uriB_Onto2);

        if (vA == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriA_Onto1 + " in graph " + onto1.getURI());
        }
        if (vB == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriB_Onto2 + " in graph " + onto2.getURI());
        }

        if (onto1.getURI().equals(onto2.getURI())) { // SAME Ontology
            throw new SLIB_Ex_Critic("Error compared concepts are expressed in the same ontology");
        }

        logger.info("Expressed in different ontologies");

        logger.info("Computing A & B ancestors");
        Set<V> ancestors_A = getAncestors(uriA_Onto1, onto1);
        Set<V> ancestors_B = getAncestors(uriB_Onto2, onto2);

        logger.info("Search Mapping among ancestors");
        Set<Mapping> mappingAncestors = getMappings(ancestors_A, ancestors_B, onto2);
        logger.info("Found " + mappingAncestors.size() + " mapping");
        Mapping bestMapping_LCS = null;

        if (!mappingAncestors.isEmpty()) {

            logger.info("Searching Best Mapping");
            double bestMapping_LCS_IC = -Double.MAX_VALUE;

            for (Mapping m : mappingAncestors) {

                G gmA = factory.getGraph(m.getGraph_A());
                G gmB = factory.getGraph(m.getGraph_B());

                V a = gmA.getV(m.getA());
                V b = gmB.getV(m.getB());

                double ic_a = engineCollection.get(gmA.getURI()).getIC(icConf, a);
                double ic_b = engineCollection.get(gmB.getURI()).getIC(icConf, b);

                double bestIC = (ic_a > ic_b) ? ic_a : ic_b;

                if (bestIC > bestMapping_LCS_IC) {
                    bestMapping_LCS_IC = bestIC;
                    bestMapping_LCS = m;
                }
            }
            logger.info("Best Mapping among ancestors search space");
            logger.info("Mapping  : " + bestMapping_LCS);
            logger.info("IC value : " + bestMapping_LCS_IC);
        }

        return bestMapping_LCS;
    }

    private Set<Mapping> getMappings(Set<V> setA, Set<V> setB, G graphVerticesSetB) {

        logger.debug("Looking for mappings");
        // for each pairs of concepts in setA * setB

        // Retrieve all mappings involving the setA (unidirectional)
        Set<Mapping> mapFromSetA = new HashSet<Mapping>();
        for (V v : setA) {
            Set<Mapping> tmp = mappings.get((URI) v.getValue());
            if (tmp != null) {
                mapFromSetA.addAll(tmp);
            }
        }

        // Convert setB to URI to boost the lookup
        Set<URI> setB_uris = new HashSet<URI>();
        for (V v : setB) {
            setB_uris.add((URI) v.getValue());
        }
        Set<Mapping> mappingsReduction = new HashSet<Mapping>();
        URI ontoVerticesSetB = graphVerticesSetB.getURI();

        /* 
         * Only the mappings established with
         * a vertex which is both part of setB
         * and graphVerticesSetB
         */

        URI mappedConcept;
        G ontoOfMappedConcept;
        for (Mapping m : mapFromSetA) {

            mappedConcept = m.getB();
            ontoOfMappedConcept = factory.getGraph(m.getGraph_B());

            if (setB_uris.contains(mappedConcept) && ontoOfMappedConcept.getURI().equals(ontoVerticesSetB)) {
                mappingsReduction.add(m);
            }
        }
        return mappingsReduction;
    }

    private static LinkedHashSet<QueryBinaryOnto> loadQueries(String queryFile, G onto1, G onto2, String prefixOnto1, String prefixOnto2) throws SLIB_Ex_Critic {

        LinkedHashSet<QueryBinaryOnto> queries = new LinkedHashSet<QueryBinaryOnto>();
        try {
            FileInputStream fstream = new FileInputStream(queryFile);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;

            int CONCEPT_A_DESC = 0;
            int CONCEPT_B_DESC = 1;

            int URIS_A_ONTO_1 = 2;
            int URIS_B_ONTO_1 = 3;

            int URIS_A_ONTO_2 = 4;
            int URIS_B_ONTO_2 = 5;

            boolean isHeader = true;

            while ((line = br.readLine()) != null) {

                if (isHeader) {
                    isHeader = false;
                    continue;
                }

                line = line.trim();

                if (line.isEmpty()) {
                    continue;
                }

                String[] data = line.trim().split("\t");

                String descA = data[CONCEPT_A_DESC];
                String descB = data[CONCEPT_B_DESC];

                String[] urisA_ONTO1string = data[URIS_A_ONTO_1].trim().split(";");
                String[] urisB_ONTO1string = data[URIS_B_ONTO_1].trim().split(";");
                String[] urisA_ONTO2string = data[URIS_A_ONTO_2].trim().split(";");
                String[] urisB_ONTO2string = data[URIS_B_ONTO_2].trim().split(";");


                QueryBinaryOnto query = new QueryBinaryOnto(descA, descB, onto1, onto2);

                DataFactory factory = DataFactoryMemory.getSingleton();
                //Create and uris (dirty)

                // URI A ONTO 1
                for (String s : urisA_ONTO1string) {
                    s = s.trim();

                    if (!s.isEmpty()) {
                        query.addUriA_onto1(factory.createURI(prefixOnto1 + s));
                    }
                }
                // URI B ONTO 1
                for (String s : urisB_ONTO1string) {
                    s = s.trim();

                    if (!s.isEmpty()) {
                        query.addUriB_onto1(factory.createURI(prefixOnto1 + s));
                    }
                }

                // URI A ONTO 2
                for (String s : urisA_ONTO2string) {
                    s = s.trim();

                    if (!s.isEmpty()) {
                        query.addUriA_onto2(factory.createURI(prefixOnto2 + s));
                    }
                }

                // URI B ONTO 2
                for (String s : urisB_ONTO2string) {
                    s = s.trim();

                    if (!s.isEmpty()) {
                        query.addUriB_onto2(factory.createURI(prefixOnto2 + s));
                    }
                }

                queries.add(query);
            }

            in.close();
        } catch (Exception e) {
            throw new SLIB_Ex_Critic(e.getMessage());
        }
        return queries;
    }

    private double computeBestIC(ICconf icConf, CoupleOfConcepts coupleLCS) throws SLIB_Exception {
        logger.info("Retrieving best IC");

        URI ancA = coupleLCS.getA();
        G graphA = factory.getGraph(coupleLCS.getGraph_A());
        V ancA_v = graphA.getV(ancA);
        SM_Engine graphA_engine = engineCollection.get(graphA.getURI());

        URI ancB = coupleLCS.getB();
        G graphB = factory.getGraph(coupleLCS.getGraph_B());
        V ancB_v = graphB.getV(ancB);
        SM_Engine graphB_engine = engineCollection.get(graphB.getURI());


        double icAnc_A = graphA_engine.getIC(icConf, ancA_v);
        double icAnc_B = graphB_engine.getIC(icConf, ancB_v);

        logger.info(ancA + " in graph " + graphA.getURI() + " : " + icAnc_A);
        logger.info(ancB + " in graph " + graphB.getURI() + " : " + icAnc_B);

        double maxIC_LCS = icAnc_A > icAnc_B ? icAnc_A : icAnc_B;
        return maxIC_LCS;
    }

    private double[] getLeaves_Ancestors_count(G onto, V v) throws SLIB_Ex_Critic {

        double[] data = new double[2];
        SM_Engine engine = engineCollection.get(onto.getURI());

        double leave = engine.getAllNbReachableLeaves().get(v);
        double ancestors = engine.getAncestorsInc(v).size();

//        if (engine.getLeaves().contains(v)) {
//            leave -= 1;
//        }

        data[0] = leave;
        data[1] = ancestors;

        return data;

    }

    private StorageICs normalizeIC_MethodSpecific(MEASURE_FLAG measureFlag, ICconf icConf, URI uriVA, URI uriVB, G ontoA, G ontoB, CoupleOfConcepts bestLCSs_NPMI) throws SLIB_Exception {

        // Retrieve best LCS IC and associated graph

        V vA = ontoA.getV(uriVA);
        V vB = ontoB.getV(uriVB);

        double icVA = engineCollection.get(ontoA.getURI()).getIC(icConf, vA);
        double icVB = engineCollection.get(ontoB.getURI()).getIC(icConf, vB);

        G graphTest = factory.getGraph(bestLCSs_NPMI.getGraph_A());

        /**
         * We ensure that graph A of bestLCSs_NPMI is equals to ontoA to
         * facilitate the process i.e. if its not the case we switch the order
         * in bestLCSs_NPMI. This doesn't affect the process as the mapping is
         * considered assymetric
         */
        if (!graphTest.getURI().equals(ontoA.getURI())) {
            return normalizeIC_MethodSpecific(measureFlag, icConf, uriVA, uriVB, ontoA, ontoB, new CoupleOfConcepts(bestLCSs_NPMI.getB(), bestLCSs_NPMI.getA(), bestLCSs_NPMI.getGraph_B(), bestLCSs_NPMI.getGraph_A()));
        }

        URI uriAncA = bestLCSs_NPMI.getA();
        V VancA = ontoA.getV(uriAncA);
        SM_Engine ontoAEngine = engineCollection.get(ontoA.getURI());

        URI uriAncB = bestLCSs_NPMI.getB();
        V VancB = ontoB.getV(uriAncB);
        SM_Engine ontoBengine = engineCollection.get(ontoB.getURI());


        double icVancA = ontoAEngine.getIC(icConf, VancA);
        double icVancB = ontoBengine.getIC(icConf, VancB);

        logger.info("VA " + uriVA);
        logger.info("VB " + uriVB);
        logger.info("IC A " + icVA);
        logger.info("IC B " + icVB);
        logger.info("VancA " + uriAncA);
        logger.info("VancB " + uriAncB);
        logger.info("IC VancA " + icVancA);
        logger.info("IC VancB " + icVancB);

        double bestIC_LCS;


        double icVA_norm, icVB_norm;


        if (icVancA > icVancB) {
            icVA_norm = icVA;
            bestIC_LCS = icVancA;

            if (measureFlag == MEASURE_FLAG.LIN) {
                icVB_norm = normalizeIcSanchez_inner(vA, vB, ontoA, ontoB, VancA, VancB);
            } else {
                throw new SLIB_Ex_Critic("Normalized function is not implemented for " + measureFlag);
            }

            logger.info("Best IC LCS selected from " + ontoA.getURI());
            logger.info("[A] LCS " + VancA.getValue());
        } else {
            icVB_norm = icVB;
            bestIC_LCS = icVancB;

            if (measureFlag == MEASURE_FLAG.LIN) {
                icVA_norm = normalizeIcSanchez_inner(vB, vA, ontoB, ontoA, VancB, VancA);
            } else {
                throw new SLIB_Ex_Critic("Normalized function is not implemented for " + measureFlag);
            }

            logger.info("Best IC LCS selected from " + ontoB.getURI());
            logger.info("[B] LCS " + VancB.getValue());
        }

        logger.info("IC LCS: " + bestIC_LCS);
        return new StorageICs(icVA_norm, icVB_norm, bestIC_LCS);
    }

    private StorageICs normalizeICsGeneric(ICconf icConf, URI uriVA, URI uriVB, G ontoA, G ontoB, CoupleOfConcepts bestLCSs_NPMI) throws SLIB_Exception {

        // Retrieve best LCS IC and associated graph

        V vA = ontoA.getV(uriVA);
        V vB = ontoB.getV(uriVB);

        double icVA = engineCollection.get(ontoA.getURI()).getIC(icConf, vA);
        double icVB = engineCollection.get(ontoB.getURI()).getIC(icConf, vB);

        G graphTest = factory.getGraph(bestLCSs_NPMI.getGraph_A());

        /**
         * We ensure that graph A of bestLCSs_NPMI is equals to ontoA to
         * facilitate the process i.e. if its not the case we switch the order
         * in bestLCSs_NPMI. This doesn't affect the process as the mapping is
         * considered assymetric
         */
        if (!graphTest.getURI().equals(ontoA.getURI())) {
            return normalizeICsGeneric(icConf, uriVA, uriVB, ontoA, ontoB, new CoupleOfConcepts(bestLCSs_NPMI.getB(), bestLCSs_NPMI.getA(), bestLCSs_NPMI.getGraph_B(), bestLCSs_NPMI.getGraph_A()));
        }

        URI uriAncA = bestLCSs_NPMI.getA();
        V VancA = ontoA.getV(uriAncA);
        SM_Engine ontoAEngine = engineCollection.get(ontoA.getURI());

        URI uriAncB = bestLCSs_NPMI.getB();
        V VancB = ontoB.getV(uriAncB);
        SM_Engine ontoBengine = engineCollection.get(ontoB.getURI());


        double icVancA = ontoAEngine.getIC(icConf, VancA);
        double icVancB = ontoBengine.getIC(icConf, VancB);

        logger.info("VA " + uriVA);
        logger.info("VB " + uriVB);
        logger.info("IC A " + icVA);
        logger.info("IC B " + icVB);
        logger.info("VancA " + uriAncA);
        logger.info("VancB " + uriAncB);
        logger.info("IC VancA " + icVancA);
        logger.info("IC VancB " + icVancB);

        logger.info("Rescale IC if required i.e. ic == 0 ");

        icVA = rescaleIC(icVA, ontoA, icConf);
        icVB = rescaleIC(icVB, ontoB, icConf);
        icVancA = rescaleIC(icVancA, ontoA, icConf);
        icVancB = rescaleIC(icVancB, ontoB, icConf);


        logger.info("IC A " + icVA);
        logger.info("IC B " + icVB);
        logger.info("IC VancA " + icVancA);
        logger.info("IC VancB " + icVancB);

        double bestIC_LCS;


        double icVA_norm, icVB_norm;


        if (icVancA > icVancB) {
            icVA_norm = icVA;
            bestIC_LCS = icVancA;

            icVB_norm = icVB * bestIC_LCS / icVancB;

            logger.info("Best IC LCS selected from " + ontoA.getURI());
            logger.info("[A] LCS " + VancA.getValue());
        } else {
            icVB_norm = icVB;
            bestIC_LCS = icVancB;

            icVA_norm = icVA * bestIC_LCS / icVancA;

            logger.info("Best IC LCS selected from " + ontoB.getURI());
            logger.info("[B] LCS " + VancB.getValue());
        }

        logger.info("IC LCS: " + bestIC_LCS);
        return new StorageICs(icVA_norm, icVB_norm, bestIC_LCS);
    }

    private double rescaleIC(double icV, G onto, ICconf icConf) throws SLIB_Ex_Critic {
        if (icV == 0) {
            icV = engineCollection.get(onto.getURI()).computeIC(icConf).getMinSupNil() * CONSTANT_NORM_IC;
        }
        return icV;
    }

    /**
     * Normalize IC(V2) according to IC(V2), IC(ancV1), IC(ancV2)
     *
     * @param v1
     * @param v2
     * @param onto1
     * @param onto2
     * @param ancV1
     * @param ancV2
     * @return the normalize IC
     * @throws SLIB_Ex_Critic
     */
    private double normalizeIcSanchez_inner(V v1, V v2, G onto1, G onto2, V ancV1, V ancV2) throws SLIB_Ex_Critic {

        logger.info("V1\t" + v1);
        logger.info("V2\t" + v2);
        logger.info("Vanc1\t" + ancV1);
        logger.info("Vanc2\t" + ancV2);

        logger.info("Normalizing IC V2");

        // [0] leaves, [1] ancestors
        double[] dataV1 = getLeaves_Ancestors_count(onto1, v1);
        double[] dataV2 = getLeaves_Ancestors_count(onto2, v2);

        double[] dataANC_V1 = getLeaves_Ancestors_count(onto1, ancV1);
        double[] dataANC_V2 = getLeaves_Ancestors_count(onto2, ancV2);

        logger.info("Count Leaves/Ancestors");
        logger.info("V1 Leaves : " + dataV1[0] + "\tAncestors : " + dataV1[1]);
        logger.info("V2 Leaves : " + dataV2[0] + "\tAncestors : " + dataV2[1]);
        logger.info("ancV1 Leaves : " + dataANC_V1[0] + "\tAncestors : " + dataANC_V1[1]);
        logger.info("ancV2 Leaves : " + dataANC_V2[0] + "\tAncestors : " + dataANC_V2[1]);


        double leave2_Norm = dataV2[0] * dataANC_V1[0] / dataANC_V2[0];
        double anc2_Norm = dataV2[1] * dataANC_V1[1] / dataANC_V2[1];

        logger.info("Normalize Leaves/Ancestors V2");
        logger.info("Leaves: " + leave2_Norm);
        logger.info("Ancestors: " + anc2_Norm);

        double maxLeaves = engineCollection.get(onto1.getURI()).getAllNbReachableLeaves().getMax();

        logger.info("MAX_LEAVES: " + maxLeaves);






        // v2 is a leaves | remove something
//        if(engineCollection.get(onto2.getURI()).getLeaves().contains(v2)){
//            logger.info("V2 is a leaf, leaves and ancestors are corrected");
//            leave2_Norm = leave2_Norm - 1 * dataANC_V1[0] / dataANC_V2[0];
//        }

        //double ic2_norm = new ICi_sanchez_2011_a().compute(leave2_Norm, anc2_Norm, maxleaves);

        double x = leave2_Norm / anc2_Norm;
        logger.info("Sanchez x " + x);

        double ic2_Norm = -Math.log(x / (maxLeaves));

        logger.info("Normalized IC(V2) " + v2.getValue() + " -> " + ic2_Norm);

        return ic2_Norm;
    }

    private void flushBestMappingsNPMI(HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI, String bestMappingsNMPI_file, IndexHash indexA, IndexHash indexB) throws Exception {

        logger.info("Flushing best mapping NPMI");

        FileWriter fstream = new FileWriter(bestMappingsNMPI_file);
        BufferedWriter out = new BufferedWriter(fstream);

        out.write("URI_A\tURI_B\tBEST_MAPPING_A\tBEST_MAPPING_B\tGRAPH_BEST_MAPPING_A\tGRAPH_BEST_MAPPING_B\tDESCRIPTION_URI_A\tDESCRIPTION_URI_B\tBEST_MAPPING_DESCRIPTION_A\tBEST_MAPPING_DESCRIPTION_B\tSCORE\tIS_TERMINOLOGICAL_MAPPING\tEXIST_TERMINOLOGICAL_MAPPING_AMONG ANCESTORS_URIA_URIB\n");

        for (Entry<KEY_BEST_MAPPING, CoupleOfConceptsScored> e : bestMappingsNPMI.entrySet()) {
            KEY_BEST_MAPPING key = e.getKey();
            CoupleOfConceptsScored bestMapping = e.getValue();


            // Retrieve the description associated to concept A and B
            String descA = "";
            String descB = "";
            String bestMappingDescA = "";
            String bestMappingDescB = "";

            if (indexA.containsIndexFor(key.uA)) {
                descA = indexA.getMapping().get(key.uA).getPreferredDescription();
            } else if (indexB.containsIndexFor(key.uA)) {
                descA = indexB.getMapping().get(key.uA).getPreferredDescription();
            }

            if (indexA.containsIndexFor(key.uB)) {
                descB = indexA.getMapping().get(key.uB).getPreferredDescription();
            } else if (indexB.containsIndexFor(key.uB)) {
                descB = indexB.getMapping().get(key.uB).getPreferredDescription();
            }

            // Mapping description

            if (indexA.containsIndexFor(bestMapping.getA())) {
                bestMappingDescA = indexA.getMapping().get(bestMapping.getA()).getPreferredDescription();
            } else if (indexB.containsIndexFor(bestMapping.getA())) {
                bestMappingDescA = indexB.getMapping().get(bestMapping.getA()).getPreferredDescription();
            }

            if (indexA.containsIndexFor(bestMapping.getB())) {
                bestMappingDescB = indexA.getMapping().get(bestMapping.getB()).getPreferredDescription();
            } else if (indexB.containsIndexFor(bestMapping.getB())) {
                bestMappingDescB = indexB.getMapping().get(bestMapping.getB()).getPreferredDescription();
            }

            String outs = key.uA.stringValue() + "\t" + key.uB.stringValue() + "\t" + bestMapping.getA() + "\t" + bestMapping.getB() + "\t" + bestMapping.getGraph_A().stringValue() + "\t" + bestMapping.getGraph_B().stringValue() + "\t" + descA + "\t" + descB + "\t" + bestMappingDescA + "\t" + bestMappingDescB + "\t" + bestMapping.getScore() + "\t" + bestMapping.isIsTerminologicalMapping() + "\t" + bestMapping.existTerminologicalMappingAmongAncestors() + "\n";
            String outs2 = key.uB.stringValue() + "\t" + key.uA.stringValue() + "\t" + bestMapping.getA() + "\t" + bestMapping.getB() + "\t" + bestMapping.getGraph_A().stringValue() + "\t" + bestMapping.getGraph_B().stringValue() + "\t" + descA + "\t" + descB + "\t" + bestMappingDescA + "\t" + bestMappingDescB + "\t" + bestMapping.getScore() + "\t" + bestMapping.isIsTerminologicalMapping() + "\t" + bestMapping.existTerminologicalMappingAmongAncestors() + "\n";

            out.write(outs);
            out.write(outs2);

        }
        out.close();
    }

    private HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> loadBestMappingsNPMI(String bestMappingsNMPI_file) throws Exception {

        HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI = new HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored>();

        FileInputStream fstream = new FileInputStream(bestMappingsNMPI_file);
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;

        int URI_A = 0;
        int URI_B = 1;

        int URI_BEST_MAPPING_A = 2;
        int URI_BEST_MAPPING_B = 3;

        int URI_GRAPH_BEST_MAPPING_A = 4;
        int URI_GRAPH_BEST_MAPPING_B = 5;

        int DESCRIPTION_URI_A = 6;
        int DESCRIPTION_URI_B = 7;

        int DESCRIPTION_BEST_MAPPING_A = 8;
        int DESCRIPTION_BEST_MAPPING_B = 9;

        int SCORE = 10;

        int IS_BEST_MAPPING_TERMINOLOGICAL_MAPPING = 11;
        int EXIST_TERMINOLOGICAL_MAPPING_AMONG_ANCESTORS_URIA_URIB = 12;

        boolean isHeader = true;

        while ((line = br.readLine()) != null) {
            if (isHeader) {
                isHeader = false;
                continue;
            }
            line = line.trim();
            String[] data = line.split("\t");

            URI uriA = factory.createURI(data[URI_A]);
            URI uriB = factory.createURI(data[URI_B]);

            URI uriBestMappingA = factory.createURI(data[URI_BEST_MAPPING_A]);
            URI uriBestMappingB = factory.createURI(data[URI_BEST_MAPPING_B]);

            URI uriGraphBestMappingA = factory.createURI(data[URI_GRAPH_BEST_MAPPING_A]);
            URI uriGraphBestMappingB = factory.createURI(data[URI_GRAPH_BEST_MAPPING_B]);



            double score = Double.parseDouble(data[SCORE]);
            boolean isTerminologicalMapping = Boolean.parseBoolean(data[IS_BEST_MAPPING_TERMINOLOGICAL_MAPPING]);
            boolean existsTerminologicalMappingAmongAncestors = Boolean.parseBoolean(data[EXIST_TERMINOLOGICAL_MAPPING_AMONG_ANCESTORS_URIA_URIB]);

            CoupleOfConceptsScored c = new CoupleOfConceptsScored(uriBestMappingA, uriBestMappingB, uriGraphBestMappingA, uriGraphBestMappingB, score);
            c.setIsTerminologicalMapping(isTerminologicalMapping);
            c.setExistTerminologicalMappingAmongAncestors(existsTerminologicalMappingAmongAncestors);


            KEY_BEST_MAPPING keyAB = new KEY_BEST_MAPPING(uriA, uriB);
            KEY_BEST_MAPPING keyBA = new KEY_BEST_MAPPING(uriB, uriA);

            bestMappingsNPMI.put(keyAB, c);
            bestMappingsNPMI.put(keyBA, c);

        }
        br.close();

        return bestMappingsNPMI;
    }

    private StorageICs retrieveICValues(MEASURE_FLAG measureFlag, ICconf icConf, URI uriVA, URI uriVB, G ontoA, G ontoB, CoupleOfConcepts bestMappingAncestors) throws SLIB_Exception {

        // Retrieve best LCS IC and associated graph

        V vA = ontoA.getV(uriVA);
        V vB = ontoB.getV(uriVB);

        double icVA = engineCollection.get(ontoA.getURI()).getIC(icConf, vA);
        double icVB = engineCollection.get(ontoB.getURI()).getIC(icConf, vB);

        G graphTest = factory.getGraph(bestMappingAncestors.getGraph_A());

        /**
         * We ensure that graph A of bestLCSs_NPMI is equals to ontoA to
         * facilitate the process i.e. if its not the case we switch the order
         * in bestLCSs_NPMI. This doesn't affect the process as the mapping is
         * considered assymetric
         */
        if (!graphTest.getURI().equals(ontoA.getURI())) {
            return retrieveICValues(measureFlag, icConf, uriVA, uriVB, ontoA, ontoB, new CoupleOfConcepts(bestMappingAncestors.getB(), bestMappingAncestors.getA(), bestMappingAncestors.getGraph_B(), bestMappingAncestors.getGraph_A()));
        }

        URI uriAncA = bestMappingAncestors.getA();
        V VancA = ontoA.getV(uriAncA);
        SM_Engine ontoAEngine = engineCollection.get(ontoA.getURI());

        URI uriAncB = bestMappingAncestors.getB();
        V VancB = ontoB.getV(uriAncB);
        SM_Engine ontoBengine = engineCollection.get(ontoB.getURI());


        double icVancA = ontoAEngine.getIC(icConf, VancA);
        double icVancB = ontoBengine.getIC(icConf, VancB);

        logger.debug("VA " + uriVA);
        logger.debug("VB " + uriVB);
        logger.debug("IC A " + icVA);
        logger.debug("IC B " + icVB);
        logger.debug("VancA " + uriAncA);
        logger.debug("VancB " + uriAncB);
        logger.debug("IC VancA " + icVancA);
        logger.debug("IC VancB " + icVancB);

        double bestIC_LCS = icVancA > icVancB ? icVancA : icVancB;


        logger.info("IC LCS: " + bestIC_LCS);
        return new StorageICs(icVA, icVB, bestIC_LCS);
    }

    private double computeSimMultiOnto(MeasureConfig mConfig, URI uriA_Onto1, URI uriB_Onto2, G onto1, G onto2, CoupleOfConcepts bestMappingAncestors, double scoreMapping) throws SLIB_Exception {


        logger.info("Best Mapping " + bestMappingAncestors.getA() + "\t" + bestMappingAncestors.getB());
        logger.info("Score " + scoreMapping);


        double sim;


        if (scoreMapping <= CUTOFF_NPMI) {
            logger.info("Best Mapping NPMI rejected cut off " + CUTOFF_NPMI);
            sim = 0;
        } else {

            StorageICs ics = null;

            if (mConfig.normStrategy == NORMALIZE_STRATEGY.NONE) {

                ics = retrieveICValues(mConfig.pairwiseMeasure, mConfig.icConf, uriA_Onto1, uriB_Onto2, onto1, onto2, bestMappingAncestors);

            } else if (mConfig.normStrategy == NORMALIZE_STRATEGY.MEASURE_SPECIFIC) {

                ics = normalizeIC_MethodSpecific(mConfig.pairwiseMeasure, mConfig.icConf, uriA_Onto1, uriB_Onto2, onto1, onto2, bestMappingAncestors);

            } else if (mConfig.normStrategy == NORMALIZE_STRATEGY.GENERIC) {

                ics = normalizeICsGeneric(mConfig.icConf, uriA_Onto1, uriB_Onto2, onto1, onto2, bestMappingAncestors);

            } else {
                throw new SLIB_Ex_Critic("Normalization method " + mConfig.normStrategy + " not supported yet");
            }

            logger.info("--------------------");
            logger.info("IC A " + ics.icA);
            logger.info("IC B " + ics.icB);
            logger.info("IC LCS " + ics.icLCS);

            sim = computePairwiseSim(mConfig.pairwiseMeasure, ics.icA, ics.icB, ics.icLCS);

        }

        logger.info("SIM " + mConfig.pairwiseMeasure + "\t" + sim);


        return sim;
    }

    private void plotICsCorrespondance(ICconf icConf, G ontoA, G ontoB) throws SLIB_Ex_Critic {

        SM_Engine ontoAengine = engineCollection.get(ontoA.getURI());
        SM_Engine ontoBengine = engineCollection.get(ontoB.getURI());

        ResultStack<V, Double> icOntoA = ontoAengine.computeIC(icConf);
        ResultStack<V, Double> icOntoB = ontoBengine.computeIC(icConf);

        System.out.println(ontoA + "\t" + ontoB);

        for (Set<Mapping> mSet : mappings.getMappings().values()) {

            for (Mapping m : mSet) {

                V vA = ontoA.getV(m.getA());
                V vB = ontoB.getV(m.getB());

                if (vA == null || vB == null) {
                    continue;
                }

                double icA = icOntoA.get(vA);
                double icB = icOntoB.get(vB);

                System.out.println(m.getA() + "\t" + m.getB() + "\t" + icA + "\t" + icB);

            }

        }


    }

    private double normalizeLeastSquare(double ic, G graph) {
        double normIC = 0;

        if (graph.getURI().stringValue().equals("http://biograph/mesh/")) {
            normIC = 0.7344053 * ic + 2.177152;
        } else if (graph.getURI().stringValue().equals("http://biograph/snomed-ct/")) {
            normIC = 0.3585253 * ic + 2.282165;
        }

        return normIC;
    }

    private ResultStack<V, Double> computeIC(G onto1, ICconf icConf) throws SLIB_Ex_Critic {
        return engineCollection.get(onto1.getURI()).computeIC(icConf);
    }

    private void flustoFile(ResultStack<V, Double> rStack, String file) throws SLIB_Ex_Critic {

        try {

            BufferedWriter out = new BufferedWriter(new FileWriter(file));

            for (V v : rStack.keySet()) {
                out.write(v.getValue().stringValue() + "\t" + rStack.get(v) + "\n");
            }

            out.close();
        } catch (Exception e) {
            throw new SLIB_Ex_Critic(e.getMessage());
        }
    }

    private void loadICResults(G g, ICconf icConf, String file) throws SLIB_Ex_Critic {

        ResultStack<V, Double> ics = new ResultStack<V, Double>();

        try {
            DataInputStream in = new DataInputStream(new FileInputStream(file));
            BufferedReader br = new BufferedReader(new InputStreamReader(in));

            String line;
            String[] data;

            while ((line = br.readLine()) != null) {

                line = line.trim();

                if (!line.isEmpty()) {

                    data = line.split("\t");

                    URI uri = factory.createURI(data[0]);
                    V v = g.getV(uri);
                    Double d = Double.parseDouble(data[1]);
                    ics.add(v, d);
                }
            }
        } catch (Exception e) {
            throw new SLIB_Ex_Critic(e.getMessage());
        }
        engineCollection.get(g.getURI()).setICSvalues(icConf, ics);
    }

    private StringBuffer loadVsetAsString(Set<V> set, IndexHash index, String sep) {

        StringBuffer buffer = new StringBuffer();

        for (V v : set) {

            IndexedElement ie = index.getMapping().get(v.getValue());
            String desc = "";

            if (ie != null) {
                desc = ie.getPreferredDescription();
            }
            buffer.append(sep).append(" - ").append(((URI) v.getValue()).getLocalName()).append("\t").append(desc).append("\n");
        }

        return buffer;
    }

    private double processMultiOntoContext(
            MeasureConfig mConfig,
            URI uriA,
            URI uriB,
            G ontoUriA,
            G ontoUriB,
            Map<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI,
            BufferedWriter log) throws SLIB_Ex_Critic {

        double sim = 0;

        try {

            if (mConfig.multiStrategy == MEASURE_FLAG.BEST_NPMI_BRIDGE) {

                KEY_BEST_MAPPING keyC1_C2 = new KEY_BEST_MAPPING(uriA, uriB);
                CoupleOfConceptsScored bestMapping_NPMI = bestMappingsNPMI.get(keyC1_C2);

                if (bestMapping_NPMI == null) {
                    throw new SLIB_Ex_Critic("Please compute or load best mapping considering NPMI Cannot find best mapping for " + uriA + "\t" + uriB);
                }

                sim = computeSimMultiOnto(mConfig, uriA, uriB, ontoUriA, ontoUriB, bestMapping_NPMI, bestMapping_NPMI.getScore());
                log.write("\t\t\t[NPMI]\t" + uriA + "\t" + uriB + "\t" + sim + "\n");

            } else if (mConfig.multiStrategy == MEASURE_FLAG.BEST_ANCESTOR_MAPPING) {

                CoupleOfConcepts bestMapping_Anc = getBestMappingAmongAncestors(mConfig.icConf, uriA, uriB, ontoUriA, ontoUriB);


                if (bestMapping_Anc != null) {

                    sim = computeSimMultiOnto(mConfig, uriA, uriB, ontoUriA, ontoUriB, bestMapping_Anc, CUTOFF_NPMI + 1); // CUTOFF_NPMI+1 ensure that the mapping will be considered
                }

                log.write("\t\t\t[MAPPING_ANCESTORS]\t" + uriA + "\t" + uriB + "\t" + sim + "\n");
            } else {
                throw new SLIB_Ex_Critic("Unknow Multi-Ontology context " + mConfig.multiStrategy + ", supported " + MEASURE_FLAG.BEST_ANCESTOR_MAPPING + "," + MEASURE_FLAG.BEST_NPMI_BRIDGE);
            }
            logger.info("#############################################################################");

        } catch (Exception e) {
            throw new SLIB_Ex_Critic(e.getMessage());
        }

        return sim;
    }

    private final class StorageICs {

        public double icA;
        public double icB;
        public double icLCS;

        public StorageICs(double icA, double icB, double icLCS) {
            this.icA = icA;
            this.icB = icB;
            this.icLCS = icLCS;
        }
    }

    public void compute(Set<QueryBinaryOnto> queries, Map<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI, MeasureConfig mConfig, String outputFile_Results, String logFile) throws SLIB_Exception, Exception {


        logger.info("Retrieving ICs considering " + mConfig.icConf.className);

        for (SM_Engine engine : engineCollection.values()) {
            engine.computeIC(mConfig.icConf);
        }



        BufferedWriter out = new BufferedWriter(new FileWriter(outputFile_Results));
        BufferedWriter log = new BufferedWriter(new FileWriter(logFile));

        String header = "Term_A|Term_B|Concept_A|ConceptB|Onto_CA|Onto_CB|Sim\n";
        out.write(header);

        Timer globalTimer = new Timer();

        globalTimer.start();
        int skippedComparison = 0;

        for (QueryBinaryOnto query : queries) {

            logger.info("#############################################################################");
            logger.info(" " + query.getCA_Desc() + " / " + query.getCB_Desc());
            logger.info("#############################################################################");

            logger.info("URI A Onto 1: " + query.A_onto1.size());
            logger.info("URI B Onto 1: " + query.B_onto1.size());
            logger.info("URI A Onto 2: " + query.A_onto2.size());
            logger.info("URI B Onto 2: " + query.B_onto2.size());

            logger.info(query.toString());

            log.write("\n>" + query.getCA_Desc() + "\t" + query.getCB_Desc() + "\n");

            Set<URI> setUriA_Onto1 = query.getA_onto1();
            Set<URI> setUriA_Onto2 = query.getA_onto2();

            Set<URI> setUriB_Onto1 = query.getB_onto1();
            Set<URI> setUriB_Onto2 = query.getB_onto2();

            G onto1 = query.getOnto1();
            G onto2 = query.getOnto2();


            // Perform the treatment for each configured context


            for (Pair<URI, URI> context : mConfig.getOntoContexts()) {

                URI ontoUriA = context.getKey();
                URI ontoUriB = context.getValue();

                // --------------------
                // Mono Ontolgy Context 
                // --------------------

                if (ontoUriA.equals(onto1.getURI()) && ontoUriB.equals(onto1.getURI())) {

                    // compute C1 onto1 / c2 onto 1
                    logger.info("-----------------------------------------------------------------------------------");
                    logger.info("[MONO] ONTO: " + onto1.getURI());
                    logger.info("-----------------------------------------------------------------------------------");

                    for (URI uriA_Onto1 : setUriA_Onto1) {
                        for (URI uriB_Onto1 : setUriB_Onto1) {

                            double simMonoOnto1 = computeSimOneOnto(mConfig, uriA_Onto1, uriB_Onto1, onto1);

                            String l = query.getCA_Desc() + "|" + query.getCB_Desc() + "|" + uriA_Onto1 + "|" + uriB_Onto1 + "|" + onto1.getURI() + "|" + onto1.getURI() + "|" + simMonoOnto1 + "\n";
                            out.write(l);
                        }
                    }

                } else if (ontoUriA.equals(onto2.getURI()) && ontoUriB.equals(onto2.getURI())) {

                    // compute C1 onto2 / c2 onto 2

                    logger.info("-----------------------------------------------------------------------------------");
                    logger.info("[MONO] ONTO: " + onto2.getURI());
                    logger.info("-----------------------------------------------------------------------------------");

                    for (URI uriA_Onto2 : setUriA_Onto2) {
                        for (URI uriB_Onto2 : setUriB_Onto2) {

                            double simMonoOnto2 = computeSimOneOnto(mConfig, uriA_Onto2, uriB_Onto2, onto2);

                            String l = query.getCA_Desc() + "|" + query.getCB_Desc() + "|" + uriA_Onto2 + "|" + uriB_Onto2 + "|" + onto2.getURI() + "|" + onto2.getURI() + "|" + simMonoOnto2 + "\n";
                            out.write(l);
                        }
                    }
                } // --------------------
                // Multi Ontolgy Context 
                // --------------------
                else if (ontoUriA.equals(onto1.getURI()) && ontoUriB.equals(onto2.getURI())) {

                    // compute C1 onto1 / c2 onto 2

                    logger.info("-----------------------------------------------------------------------------------");
                    logger.info("[MULTI] A in " + onto1.getURI() + " / B in " + onto2.getURI() + " ");
                    logger.info("-----------------------------------------------------------------------------------");

                    for (URI uriA_Onto1 : setUriA_Onto1) {
                        for (URI uriB_Onto2 : setUriB_Onto2) {

                            double sim = processMultiOntoContext(mConfig, uriA_Onto1, uriB_Onto2, onto1, onto2, bestMappingsNPMI, log);

                            String l = query.getCA_Desc() + "|" + query.getCB_Desc() + "|" + uriA_Onto1 + "|" + uriB_Onto2 + "|" + onto1.getURI() + "|" + onto2.getURI() + "|" + sim + "\n";
                            out.write(l);
                        }
                    }

                } else if (ontoUriA.equals(onto2.getURI()) && ontoUriB.equals(onto1.getURI())) {

                    // compute C1 onto2 / c2 onto 1

                    logger.info("-----------------------------------------------------------------------------------");
                    logger.info("[MULTI] A in " + onto2.getURI() + " / B in " + onto1.getURI() + " ");
                    logger.info("-----------------------------------------------------------------------------------");

                    for (URI uriA_Onto2 : setUriA_Onto2) {
                        for (URI uriB_Onto1 : setUriB_Onto1) {

                            double sim = processMultiOntoContext(mConfig, uriA_Onto2, uriB_Onto1, onto2, onto1, bestMappingsNPMI, log);
                            String l = query.getCA_Desc() + "|" + query.getCB_Desc() + "|" + uriA_Onto2 + "|" + uriB_Onto1 + "|" + onto2.getURI() + "|" + onto1.getURI() + "|" + sim + "\n";
                            out.write(l);
                        }
                    }

                } else {
                    throw new SLIB_Ex_Critic("Incoherent context considering given parameters (e.g. graph not found...)");
                }

            }

            logger.info(
                    "--------------------------------------------------------------------------------");
            logger.info(" Ending " + query.getCA_Desc() + " / " + query.getCB_Desc());

            logger.info("#############################################################################");
            logger.info("#############################################################################");
        }

        log.close();

        out.close();

        logger.info(
                "Global Timer (without KB loading)");
        globalTimer.elapsedTime();

        logger.info(
                "Skipped comparison " + skippedComparison);


    }

//    @Deprecated
//    public void logInformationPairwise(LinkedHashSet<QueryBinaryOnto> queries, G graph, IndexHash index, MEASURE_FLAG[] pairwiseMeasures, ICconf[] icConfs, String logfile) throws Exception {
//
//
//        SM_Engine engine = engineCollection.get(graph.getURI());
//
//        for (ICconf icConf : icConfs) {
//            engine.computeIC(icConf);
//        }
//
//        // Compute the number of leaves
//        long nbLeaves = 0;
//
//        for (V v : graph.getV()) {
//            if (graph.getE(v, new WalkConstraintTax(RDFS.SUBCLASSOF, Direction.IN)).isEmpty()) {
//                nbLeaves++;
//            }
//        }
//
//
//        BufferedWriter logInfo = new BufferedWriter(new FileWriter(logfile));
//
//        logInfo.write(graph.toString());
//
//        String sep = "--------------------------------------------";
//
//
//        for (QueryBinaryOnto query : queries) {
//
//            logger.info("#############################################################################");
//            logger.info(" " + query.getCA_Desc() + " / " + query.getCB_Desc());
//            logger.info("#############################################################################");
//
//            URI uriA;
//            URI uriB;
//
//            if (graph.getURI().equals(query.onto1.getURI())) {
//                uriA = query.getA_onto1();
//                uriB = query.getB_onto1();
//            } else {
//                uriA = query.getA_onto2();
//                uriB = query.getB_onto2();
//            }
//
//            logInfo.write("\n" + sep + "\n" + query.getCA_Desc() + "\t" + query.getCB_Desc() + "\n" + sep + "\n");
//
//            if (uriA == null || uriB == null) {
//
//                logInfo.write("\tSKIPPED because a concept was not found in the ontology");
//                logInfo.write("\t\tc1: " + uriA);
//                logInfo.write("\t\tc2: " + uriB);
//
//            } else {
//
//                logInfo.write(
//                        "\t" + sep + "\n"
//                        + "\tCONTEXT: c1 in " + graph.getURI() + "\t c2 in" + graph.getURI()
//                        + "\n\t" + sep + "\n");
//
//                logInfo.write("\t\t\t" + uriA.getLocalName() + "\t" + uriB.getLocalName() + "\n");
//
//
//
//
//
//                StringBuffer b;
//
//
//
//                logInfo.write("\n\t\t\t\t c1: " + query.conceptA_Desc + " [" + uriA.getLocalName() + "]\n");
//                V c1 = graph.getV(uriA);
//
//                Set<V> ancestorsC1 = engine.getAncestorsInc(c1);
//                b = loadVsetAsString(ancestorsC1, index, "\t\t\t\t\t\t");
//                logInfo.write("\t\t\t\t\t ancestors : " + ancestorsC1.size() + "\n" + b.toString());
//
//
//                Set<V> leavesC1 = engine.getReachableLeaves().get(c1);
//                b = loadVsetAsString(leavesC1, index, "\t\t\t\t\t\t");
//                logInfo.write("\t\t\t\t\t leaves : " + leavesC1.size() + "\n" + b.toString());
//
//
//                logInfo.write("\n\t\t\t\t c2: " + query.conceptB_Desc + " [" + uriB.getLocalName() + "]\n");
//                V c2 = graph.getV(uriB);
//                Set<V> ancestorsC2 = engine.getAncestorsInc(c2);
//                b = loadVsetAsString(ancestorsC2, index, "\t\t\t\t\t\t");
//                logInfo.write("\t\t\t\t\t ancestors : " + ancestorsC2.size() + "\n" + b.toString());
//
//
//                Set<V> leavesC2 = engine.getReachableLeaves().get(c2);
//                b = loadVsetAsString(leavesC2, index, "\t\t\t\t\t\t");
//                logInfo.write("\t\t\t\t\t leaves : " + leavesC2.size() + "\n" + b.toString());
//
//
//                logInfo.write("\n\t\t\t\t\tNumber of concepts: " + graph.getV().size() + "\n");
//                logInfo.write("\t\t\t\t\tNumber of leaves  : " + nbLeaves + "\n");
//
//                for (ICconf icConf : icConfs) {
//
//                    double icC1 = engine.getIC(icConf, c1);
//                    double icC2 = engine.getIC(icConf, c2);
//                    logInfo.write("\n\t\t\t\t\tIC      : " + icConf.className + "\n");
//                    logInfo.write("\t\t\t\t\t\tIC c1   : " + icC1 + "\n");
//                    logInfo.write("\t\t\t\t\t\tIC c2   : " + icC2 + "\n");
//
//                    V mica = IcUtils.searchMICA(engine.getAncestorsInc(c1), engine.getAncestorsInc(c2), engine.getIC_results(icConf));
//                    logInfo.write("\t\t\t\t\t\tMICA    : " + ((URI) mica.getValue()).getLocalName() + "\n");
//                    logInfo.write("\t\t\t\t\t\tMICA IC : " + engine.getIC(icConf, mica) + "\n");
//
//                    logInfo.write("\t\t\t\t\tPairwise measures scores : \n");
//                    for (MEASURE_FLAG flagMeasure : pairwiseMeasures) {
//
//                        MeasureConfig mConf = new MeasureConfig(flagMeasure, icConf, null);
//
//                        double sim = computeSimOneOnto(mConf, uriA, uriB, graph);
//                        logInfo.write("\t\t\t\t\t\t" + flagMeasure + "    : " + sim + "\n");
//                    }
//                    logInfo.write("\n");
//                }
//
//                logger.info("#############################################################################");
//            }
//
//        }
//        logInfo.close();
//    }
//    public void logInformationPairwise_old(LinkedHashSet<QueryBinaryOnto> queries, MEASURE_FLAG pairwiseMeasure, ICconf icConf, String logfile) throws SLIB_Exception, Exception {
//
//        Indexer_MESH_XML indexer = new Indexer_MESH_XML();
//        IndexHash indexMesh = indexer.buildIndex(factory, "/data/mesh/desc2013.xml", "http://biograph/mesh/");
//
//
//        for (SM_Engine engine : engineCollection.values()) {
//            engine.computeIC(icConf);
//        }
//
//
//
//
//        FileWriter fstream = new FileWriter(logfile);
//        BufferedWriter logInfo = new BufferedWriter(fstream);
//
//        String sep = "--------------------------------------------";
//
//
//        for (QueryBinaryOnto query : queries) {
//
//            logger.info("#############################################################################");
//            logger.info(" " + query.getCA_Desc() + " / " + query.getCB_Desc());
//            logger.info("#############################################################################");
//
//
//            URI uriA_Onto1 = query.getA_onto1();
//            URI uriB_Onto1 = query.getB_onto1();
//
//            logInfo.write("\n" + sep + "\n" + query.getCA_Desc() + "\t" + query.getCB_Desc() + "\n" + sep + "\n");
//
//
//            Double simMonoOnto1 = null;
//
//            G onto1 = query.getOnto1();
//
//            if (uriA_Onto1 != null && uriB_Onto1 != null) {
//
//                logger.info("-----------------------------------------------------------------------------------");
//                logger.info("[MONO] ONTO: " + onto1.getURI());
//                logger.info("-----------------------------------------------------------------------------------");
//
//                logInfo.write(
//                        "\t" + sep + "\n"
//                        + "\tCONTEXT: c1 in " + query.onto1.getURI() + "\t c2 in" + query.onto1.getURI()
//                        + "\n\t" + sep + "\n");
//
//
//
//
//                logInfo.write("\t\t\t" + uriA_Onto1.getLocalName() + "\t" + uriB_Onto1.getLocalName() + "\n");
//                logInfo.write("\t\t\t\t c1: " + query.conceptA_Desc + " [" + uriA_Onto1.getLocalName() + "]\n");
//
//
//
//                SM_Engine engine = engineCollection.get(onto1.getURI());
//
//                V c1 = onto1.getV(uriA_Onto1);
//                Set<V> ancestorsC1 = engine.getAncestorsInc(c1);
//
//                logInfo.write("\t\t\t\t\t ancestors : " + ancestorsC1.size() + "\n");
//                for (V anc : ancestorsC1) {
//
//                    IndexedElement ie = indexMesh.getMapping().get(anc.getValue());
//                    String desc = "";
//
//                    if (ie != null) {
//                        desc = ie.getPreferredDescription();
//                    }
//                    logInfo.write("\t\t\t\t\t\t - " + ((URI) anc.getValue()).getLocalName() + "\t" + desc + "\n");
//                }
//
//                Set<V> leavesC1 = engine.getDescGetter().getTerminalVertices().get(c1);
//
//                logInfo.write("\t\t\t\t\t leaves : " + leavesC1.size() + "\n");
//                for (V leaf : leavesC1) {
//
//                    IndexedElement ie = indexMesh.getMapping().get(leaf.getValue());
//                    String desc = "";
//
//                    if (ie != null) {
//                        desc = ie.getPreferredDescription();
//                    }
//
//                    logInfo.write("\t\t\t\t\t\t - " + ((URI) leaf.getValue()).getLocalName() + "\t" + desc + "\n");
//                }
//
//
//
//                logInfo.write("\t\t\t\t c2: " + query.conceptB_Desc + " [" + uriB_Onto1.getLocalName() + "]\n");
//                V c2 = onto1.getV(uriB_Onto1);
//                Set<V> ancestorsC2 = engine.getAncestorsInc(c2);
//                logInfo.write("\t\t\t\t\t ancestors : " + ancestorsC2.size() + "\n");
//                for (V anc : ancestorsC2) {
//
//                    IndexedElement ie = indexMesh.getMapping().get(anc.getValue());
//                    String desc = "";
//
//                    if (ie != null) {
//                        desc = ie.getPreferredDescription();
//                    }
//
//
//                    logInfo.write("\t\t\t\t\t\t - : " + ((URI) anc.getValue()).getLocalName() + "\t" + desc + "\n");
//                }
//
//                Set<V> leavesC2 = engine.getDescGetter().getTerminalVertices().get(c2);
//
//                logInfo.write("\t\t\t\t\t leaves : " + leavesC2.size() + "\n");
//                for (V leaf : leavesC2) {
//
//                    IndexedElement ie = indexMesh.getMapping().get(leaf.getValue());
//                    String desc = "";
//
//                    if (ie != null) {
//                        desc = ie.getPreferredDescription();
//                    }
//
//
//                    logInfo.write("\t\t\t\t\t\t - : " + ((URI) leaf.getValue()).getLocalName() + "\t" + desc + "\n");
//                }
//
//
//
//                long nbLeaves = 0;
//
//                for (V v : onto1.getV()) {
//                    if (onto1.getE(v, new WalkConstraintTax(RDFS.SUBCLASSOF, Direction.IN)).isEmpty()) {
//                        nbLeaves++;
//                    }
//                }
//                logInfo.write("\t\t\t\t\tNumber of concepts: " + onto1.getV().size() + "\n");
//                logInfo.write("\t\t\t\t\tNumber of leaves  : " + nbLeaves + "\n");
//
//                double icC1 = engine.getIC(icConf, c1);
//                double icC2 = engine.getIC(icConf, c2);
//                logInfo.write("\t\t\t\t\tIC      : " + icConf.className + "\n");
//                logInfo.write("\t\t\t\t\t\tIC c1   : " + icC1 + "\n");
//                logInfo.write("\t\t\t\t\t\tIC c2   : " + icC2 + "\n");
//
//                V mica = IcUtils.searchMICA(engine.getAncestorsInc(c1), engine.getAncestorsInc(c2), engine.getIC_results(icConf));
//                logInfo.write("\t\t\t\t\t\tMICA    : " + ((URI) mica.getValue()).getLocalName() + "\n");
//                logInfo.write("\t\t\t\t\t\tMICA IC : " + engine.getIC(icConf, mica) + "\n");
//
//                logInfo.write("\t\t\t\t\tPairwise measures scores : \n");
//                double sim_lin = computeSimOneOnto(new MeasureConfig(MEASURE_FLAG.LIN, icConf, null), uriA_Onto1, uriB_Onto1, onto1);
//                double sim_resnik = computeSimOneOnto(new MeasureConfig(MEASURE_FLAG.RESNIK, icConf, null), uriA_Onto1, uriB_Onto1, onto1);
//                double sim_jc = computeSimOneOnto(new MeasureConfig(MEASURE_FLAG.JC, icConf, null), uriA_Onto1, uriB_Onto1, onto1);
//
//                logInfo.write("\t\t\t\t\t\tResnik    : " + sim_resnik + "\n");
//                logInfo.write("\t\t\t\t\t\tLin       : " + sim_lin + "\n");
//                logInfo.write("\t\t\t\t\t\tJC        : " + sim_jc + "\n");
//
//                logger.info(uriA_Onto1 + "\t" + uriB_Onto1 + "\t" + simMonoOnto1);
//                logger.info("#############################################################################");
//            }
//
//        }
//        logInfo.close();
//
//
//
//
//    }
    private class KEY_BEST_MAPPING {

        public URI uA;
        public URI uB;

        public KEY_BEST_MAPPING(URI uA, URI uB) {
            this.uA = uA;
            this.uB = uB;
        }

        @Override
        public int hashCode() {
            int hash = 3;
            hash = 67 * hash + (this.uA != null ? this.uA.hashCode() : 0);
            hash = 67 * hash + (this.uB != null ? this.uB.hashCode() : 0);
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final KEY_BEST_MAPPING other = (KEY_BEST_MAPPING) obj;
            if (this.uA != other.uA && (this.uA == null || !this.uA.equals(other.uA))) {
                return false;
            }
            if (this.uB != other.uB && (this.uB == null || !this.uB.equals(other.uB))) {
                return false;
            }
            return true;
        }
    }

    public static void main(String[] a) throws SLIB_Exception, Exception {

        Logger logger = LoggerFactory.getLogger(SimTwoOnto.class);

        boolean COMPUTE_ICS = false;
        boolean COMPUTE_NPMI_MAPPING = false;



        DataFactory factory = DataFactoryMemory.getSingleton();
        G mesh = DataLoader_SnomedMesh.loadMesh_FromSLIB();
        G snomedct = DataLoader_SnomedMesh.loadSNOMEDCT_FromSLIB();

        // Optional just for checking
        CleanMeshAndSnomedCT.cleanGraph(factory, mesh);
        CleanMeshAndSnomedCT.cleanGraph(factory, snomedct);

        logger.info("Loading Mappings");

        MappingsCollectionSymmetric mappings = SimTwoOnto.loadMapping(DataLoader_SnomedMesh.mappingFile, mesh, snomedct);
        // Loading queries --------------------------------------------------------
        LinkedHashSet<QueryBinaryOnto> queries = SimTwoOnto.loadQueries(DataLoader_SnomedMesh.queryFile, mesh, snomedct, mesh.getURI().stringValue(), snomedct.getURI().stringValue());
        SimTwoOnto abacus = new SimTwoOnto(mesh, snomedct, mappings, queries);

        if (COMPUTE_NPMI_MAPPING) {

            // Compute NPMI without restrictions
            HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI = abacus.computeBestMappingsNPMI(queries, false); // compute the best mapping considering the associative function

            // Compute NPMI with restriction on the terminological mappings found in A(c1) x A(c2)
            HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI_REDUCE_SPACE = abacus.computeBestMappingsNPMI(queries, true);

            // Load the indexers
            IndexHash indexMesh = DataLoader_SnomedMesh.loadMesh_Index(mesh);
            IndexHash indexSnomed = DataLoader_SnomedMesh.loadSnomedCT_Index(snomedct);

            // Flush the results
            abacus.flushBestMappingsNPMI(bestMappingsNPMI, DataLoader_SnomedMesh.bestMappingsNMPI_file, indexMesh, indexSnomed); // save the best mappings 
            abacus.flushBestMappingsNPMI(bestMappingsNPMI_REDUCE_SPACE, DataLoader_SnomedMesh.bestMappingsNMPI_ReduceSpace_file, indexMesh, indexSnomed); // save the best mappings 

        }


        // Load best Mappings
        HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI = abacus.loadBestMappingsNPMI(DataLoader_SnomedMesh.bestMappingsNMPI_file);
        HashMap<KEY_BEST_MAPPING, CoupleOfConceptsScored> bestMappingsNPMI_REDUCE_SPACE = abacus.loadBestMappingsNPMI(DataLoader_SnomedMesh.bestMappingsNMPI_ReduceSpace_file);


        // compute ICs and flush them in files 
        ICconf icSanchez = new IC_Conf_Topo("Sanchez", SMConstants.FLAG_ICI_SANCHEZ_2011_a);
        ICconf icSeco = new IC_Conf_Topo("Seco", SMConstants.FLAG_ICI_SECO_2004);
        String meshICS_iciSanchez = "/data/ics/mesh_iciSanchez.csv";
        String snomedICS_iciSanchez = "/data/ics/snomedCT_iciSanchez.csv";
        String meshICS_iciSeco = "/data/ics/mesh_iciSeco.csv";
        String snomedICS_iciSeco = "/data/ics/snomedCT_iciSeco.csv";

        if (COMPUTE_ICS) {

            // Compute respective ICs
            ResultStack<V, Double> mesh_iciSanchez = abacus.computeIC(mesh, icSanchez);
            ResultStack<V, Double> snomedCT_iciSanchez = abacus.computeIC(snomedct, icSanchez);
            ResultStack<V, Double> mesh_iciSeco = abacus.computeIC(mesh, icSeco);
            ResultStack<V, Double> snomedCT_iciSeco = abacus.computeIC(snomedct, icSeco);

            // Save ICs into files
            abacus.flustoFile(mesh_iciSanchez, meshICS_iciSanchez);
            abacus.flustoFile(snomedCT_iciSanchez, snomedICS_iciSanchez);
            abacus.flustoFile(mesh_iciSeco, meshICS_iciSeco);
            abacus.flustoFile(snomedCT_iciSeco, snomedICS_iciSeco);
        }

        // Load ICs resutls
        abacus.loadICResults(mesh, icSanchez, meshICS_iciSanchez);
        abacus.loadICResults(snomedct, icSanchez, snomedICS_iciSanchez);
        abacus.loadICResults(mesh, icSeco, meshICS_iciSeco);
        abacus.loadICResults(snomedct, icSeco, snomedICS_iciSeco);

        ICconf[] icConfs = {icSanchez, icSeco};
        MEASURE_FLAG[] mflags = {MEASURE_FLAG.RESNIK, MEASURE_FLAG.LIN, MEASURE_FLAG.JC};

        //NORMALIZE_STRATEGY[] normStrategies = {NORMALIZE_STRATEGY.MEASURE_SPECIFIC, NORMALIZE_STRATEGY.GENERIC, NORMALIZE_STRATEGY.NONE};
        NORMALIZE_STRATEGY[] normStrategies = {NORMALIZE_STRATEGY.GENERIC, NORMALIZE_STRATEGY.NONE};

//        abacus.logInformationPairwise(mesh, indexMesh, mflags, icConfs, "/tmp/MESH_INFO.log");
//        abacus.logInformationPairwise(snomedct, indexSnomed, mflags, icConfs, "/tmp/SNOMED_INFO.log");
        String context, file, outfile, logfile;

        // Defines the various contexts which can be used:
        // C1,C2 from MESH 
        // C1,C2 from SNOMEDCT
        // C1 from MESH, C2 from SNOMEDCT
        // C1 from SNOMEDCT, C2 from MESH

        Pair<URI, URI> context_MESH_MESH = new Pair<URI, URI>(mesh.getURI(), mesh.getURI());
        Pair<URI, URI> context_SNOMEDCT_SNOMEDCT = new Pair<URI, URI>(snomedct.getURI(), snomedct.getURI());
        Pair<URI, URI> context_SNOMEDCT_MESH = new Pair<URI, URI>(snomedct.getURI(), mesh.getURI());
        Pair<URI, URI> context_MESH_SNOMEDCT = new Pair<URI, URI>(mesh.getURI(), snomedct.getURI());


        File dir = new File("/tmp/pedersen2007");
        File dirLog = new File("/tmp/pedersen2007/log/");

        dir.mkdirs();
        dirLog.mkdirs();


        for (NORMALIZE_STRATEGY normStrategy : normStrategies) {

            for (ICconf icConf : icConfs) {

                for (MEASURE_FLAG pairwiseMeasureFlag : mflags) {


                    //abacus.logInformation(pairwiseMeasureFlag, icConf, outfile + ".verbose.log");

                    // --------------------------------------------------------
                    // MONO-ONTOLOGY 
                    // --------------------------------------------------------

                    // MESH - MESH --------------------------------------------
                    context = "MESH_MESH";
                    file = "/pedersen2007_" + context + "__" + pairwiseMeasureFlag + "_" + icConf.id + ".csv";

                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    MeasureConfig mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, null);
                    mConfig.addContext(context_MESH_MESH);

                    abacus.compute(queries, null, mConfig, outfile, logfile);

                    // SNOMEDCT - SNOMEDCT ------------------------------------
                    context = "SNOMEDCT_SNOMEDCT";
                    file = "/pedersen2007_" + context + "__" + pairwiseMeasureFlag + "_" + icConf.id + ".csv";

                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, null);
                    mConfig.addContext(context_SNOMEDCT_SNOMEDCT);

                    abacus.compute(queries, null, mConfig, outfile, logfile);

                    // --------------------------------------------------------
                    // MULTI-ONTOLOGY 
                    // --------------------------------------------------------

                    // MESH - SNOMEDCT ----------------------------------------------------------------------------------------------------------

                    context = "MESH_SNOMEDCT";

                    // BEST ANCESTORS

                    mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, MEASURE_FLAG.BEST_ANCESTOR_MAPPING);
                    mConfig.addContext(context_MESH_SNOMEDCT);

                    file = "/pedersen2007_" + context + "__BEST_ANCESTOR__" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";
                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";
                    abacus.compute(queries, null, mConfig, outfile, logfile);


                    // NPMI

                    mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, MEASURE_FLAG.BEST_NPMI_BRIDGE);
                    mConfig.addContext(context_MESH_SNOMEDCT);


                    file = "/pedersen2007_" + context + "__NPMI__FULL_SEARCH_SPACE_" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";

                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    abacus.compute(queries, bestMappingsNPMI, mConfig, outfile, logfile);

                    file = "/pedersen2007_" + context + "__NPMI__REDUCED_SEARCH_SPACE_" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";

                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    abacus.compute(queries, bestMappingsNPMI_REDUCE_SPACE, mConfig, outfile, logfile);

                    // SNOMEDCT - MESH ----------------------------------------------------------------------------------------------------

                    context = "SNOMEDCT_MESH";

                    // BEST ANCESTORS

                    mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, MEASURE_FLAG.BEST_ANCESTOR_MAPPING);
                    mConfig.addContext(context_SNOMEDCT_MESH);

                    file = "/pedersen2007_" + context + "__BEST_ANCESTOR__" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";
                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";
                    abacus.compute(queries, null, mConfig, outfile, logfile);

                    // NPMI

                    mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, MEASURE_FLAG.BEST_NPMI_BRIDGE);
                    mConfig.addContext(context_SNOMEDCT_MESH);


                    file = "/pedersen2007_" + context + "__NPMI__FULL_SEARCH_SPACE_" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";

                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    abacus.compute(queries, bestMappingsNPMI, mConfig, outfile, logfile);

                    file = "/pedersen2007_" + context + "__NPMI__REDUCED_SEARCH_SPACE_" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";

                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    abacus.compute(queries, bestMappingsNPMI_REDUCE_SPACE, mConfig, outfile, logfile);

                    // MULTI_ONTOLOGY TWO SIDES -----------------------------------------------------------------------------------------

                    context = "SNOMEDCT_MESH__MESH_SNOMEDCT";;

                    // BEST ANCESTORS

                    mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, MEASURE_FLAG.BEST_ANCESTOR_MAPPING);
                    mConfig.addContext(context_SNOMEDCT_MESH);
                    mConfig.addContext(context_MESH_SNOMEDCT);

                    file = "/pedersen2007_" + context + "__BEST_ANCESTOR__" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";
                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";
                    abacus.compute(queries, null, mConfig, outfile, logfile);


                    // NPMI

                    mConfig = new MeasureConfig(pairwiseMeasureFlag, icConf, normStrategy, MEASURE_FLAG.BEST_NPMI_BRIDGE);
                    mConfig.addContext(context_SNOMEDCT_MESH);
                    mConfig.addContext(context_MESH_SNOMEDCT);

                    file = "/pedersen2007_" + context + "__NPMI__FULL_SEARCH_SPACE_" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";
                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    abacus.compute(queries, bestMappingsNPMI, mConfig, outfile, logfile);

                    file = "/pedersen2007_" + context + "__NPMI__REDUCED_SEARCH_SPACE_" + pairwiseMeasureFlag + "_" + icConf.id + "_" + normStrategy + ".csv";
                    outfile = dir.getPath() + file;
                    logfile = dirLog.getPath() + file + ".log";

                    abacus.compute(queries, bestMappingsNPMI_REDUCE_SPACE, mConfig, outfile, logfile);
                }
            }
        }
        
        // generate the cleaned results 
        
        ResultLoader.generatePedersen2007();
    }
}
