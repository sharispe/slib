/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim.biolemmatize;

import edu.ucdenver.ccp.nlp.biolemmatizer.BioLemmatizer;
import edu.ucdenver.ccp.nlp.biolemmatizer.LemmataEntry;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import slib.indexer.IndexHash;
import slib.indexer.IndexedElement;
import slib.indexer.mesh.Indexer_MESH_XML;
import slib.indexer.snomed_ct.IndexerSNOMEDCT_RF2;
import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.loader.bio.mesh.GraphLoader_MESH_XML;
import slib.sglib.io.loader.bio.snomedct.GraphLoaderSnomedCT_RF2;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.utils.ex.SLIB_Exception;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class MeshSnomedConceptsDescriptionsLoader {

    IndexHash indexMesh;
    IndexHash indexSnomed;
    Map<String, Set<Value>> hashMeshIndex;
    public static String INDEXED_FIELD = "DESCRIPTION";
    public static String URI_FIELD = "URI";
    int hitsPerPage = 20;
    G meshGraph;
    G snomedGraph;
    BioLemmatizer bioLemmatizer = new BioLemmatizer();

    public MeshSnomedConceptsDescriptionsLoader(boolean lematized) throws Exception {



        loadMesh();
        if (lematized) {
            reIndexMesh();
        }

        System.out.println("Building HashMeshIndex");
        long collision = 0;
        hashMeshIndex = new HashMap<String, Set<Value>>();

        Set<String> collidedKeys = new HashSet<String>();

        for (Entry<Value, IndexedElement> e : indexMesh.getMapping().entrySet()) {

            for (String s : e.getValue().getDescriptions()) {

                if (hashMeshIndex.containsKey(s)) {
                    hashMeshIndex.get(s).add(e.getKey());
                    collision++;
                    collidedKeys.add(s);
                } else {
                    Set<Value> v = new HashSet<Value>();
                    v.add(e.getKey());
                    hashMeshIndex.put(s, v);
                }
            }
        }
        System.out.println(collision + " collisions registred " + collidedKeys.size() + " keys implicated");
        for (String s : collidedKeys) {
            System.out.println("\t" + s + "\t" + hashMeshIndex.get(s).size() + "\t" + hashMeshIndex.get(s));
        }

        loadSNomedCT();

        if (lematized) {
            reIndexSnomedCT();
        }


    }

    private void loadSNomedCT() throws SLIB_Exception, Exception {



        System.out.println("Loading SNOMED_CT");

        DataFactory factory = DataFactoryMemory.getSingleton();

        String concept_file = "/data/SnomedCT_Release_INT_20120731/RF2Release/Full/Terminology/sct2_Concept_Full_INT_20120731.txt";
        String relationship_file = "/data/SnomedCT_Release_INT_20120731/RF2Release/Full/Terminology/sct2_Relationship_Full_INT_20120731.txt";

        GDataConf conf = new GDataConf(GFormat.SNOMED_CT_RF2);
        conf.addParameter(GraphLoaderSnomedCT_RF2.ARG_CONCEPT_FILE, concept_file);
        conf.addParameter(GraphLoaderSnomedCT_RF2.ARG_RELATIONSHIP_FILE, relationship_file);

        snomedGraph = new GraphMemory(factory.createURI("http://biograph/snomed-ct/"));
        GraphLoaderSnomedCT_RF2 loader = new GraphLoaderSnomedCT_RF2();
        loader.populate(conf, snomedGraph);

        String description_file = "/data/SnomedCT_Release_INT_20120731/RF2Release/Full/Terminology/sct2_Description_Full-en_INT_20120731.txt";

        IndexerSNOMEDCT_RF2 indexer = new IndexerSNOMEDCT_RF2();
        indexSnomed = indexer.buildIndex(factory, description_file, "http://biograph/snomed-ct/", snomedGraph);
    }

    private void loadMesh() throws SLIB_Exception {

        System.out.println("Loading MESH");

        DataFactory factory = DataFactoryMemory.getSingleton();
        URI guri = factory.createURI("http://biograph/mesh/");
        meshGraph = new GraphMemory(guri);

        GraphLoader_MESH_XML loader = new GraphLoader_MESH_XML();

        String meshFile = "/data/mesh/desc2013.xml";

        GDataConf meshXML = new GDataConf(GFormat.MESH_XML, meshFile);
        loader.populate(meshXML, meshGraph);

        Indexer_MESH_XML indexer = new Indexer_MESH_XML();
        indexMesh = indexer.buildIndex(factory, meshFile, meshGraph.getURI().stringValue());
    }

    public List<String> lematize(String s) throws Exception {

        //System.out.println(s);
        ArrayList<String> lemmatizedVersions = new ArrayList<String>();

        s = s.trim().toLowerCase();
        boolean first = true;

        for (String ss : s.split("\\s+")) {


            LemmataEntry lemmata = bioLemmatizer.lemmatizeByLexiconAndRules(ss, null);
            ArrayList<String> tmpVersions = new ArrayList<String>();
            Set<String> lemmataDone = new HashSet<String>();

            for (Map.Entry<String, String> e : lemmata.lemmasAndCategories.entrySet()) {

                if (first && !lemmataDone.contains(e.getValue())) {
                    lemmataDone.add(e.getValue());
                    tmpVersions.add(e.getValue());
                } else if (!lemmataDone.contains(e.getValue())) {
                    lemmataDone.add(e.getValue());
                    for (String lemVersion : lemmatizedVersions) {
                        tmpVersions.add(lemVersion + " " + e.getValue());
                    }
                }
            }
            first = false;
            lemmatizedVersions = tmpVersions;
        }

        lemmatizedVersions.add(s);
        return lemmatizedVersions;
    }

    private void reIndexMesh() throws Exception {
        System.out.println("Computing all descriptions for Mesh (lemmatizing)");
        long c = 0;

        for (Entry<Value, IndexedElement> e : indexMesh.getMapping().entrySet()) {
            Set<String> out = new HashSet<String>();
            c++;

            for (String s : e.getValue().getDescriptions()) {
                out.addAll(lematize(s));
            }
            e.getValue().addDescriptions(out);
        }
    }

    private void reIndexSnomedCT() throws Exception {

        System.out.println("Computing all descriptions for Snomed_CT (lemmatizing)");
        long finalCount = indexSnomed.getMapping().entrySet().size();
        long c = 0;

        for (Entry<Value, IndexedElement> e : indexSnomed.getMapping().entrySet()) {
            Set<String> out = new HashSet<String>();
            c++;

            for (String s : e.getValue().getDescriptions()) {
                out.addAll(lematize(s));
            }
            e.getValue().addDescriptions(out);
        }
    }

    private void detectMappings() {

        long total = indexSnomed.getMapping().entrySet().size();
        long c = 0;
        long mappings = 0;

        try {
            // Create file 
            FileWriter fstream = new FileWriter("/tmp/snomed_mesh_mapping.csv");

            BufferedWriter out = new BufferedWriter(fstream);


            for (Entry<Value, IndexedElement> e : indexSnomed.getMapping().entrySet()) {

                URI uri = (URI) e.getKey();

                c++;

                HashSet<Value> valueMapped = new HashSet<Value>();
                for (String s : e.getValue().getDescriptions()) {
                    if (hashMeshIndex.containsKey(s)) {
                        valueMapped.addAll(hashMeshIndex.get(s));
                    }
                }

                if (valueMapped.size() > 0) {
                    System.out.println(c + "/" + total + " " + valueMapped.size() + " mapping(s) found for " + uri + " -> " + valueMapped);
                    mappings += valueMapped.size();

                    for (Value vmapped : valueMapped) {
                        URI vmappedURI = (URI) vmapped;
                        String map = uri + "\t" + vmappedURI;
                        String map_reverse = vmappedURI + "\t" + uri;

                        System.out.println(map);
                        System.out.println(map_reverse);

                        out.write(map + "\n");
                        out.write(map_reverse + "\n");

                    }
                }
            }
            System.out.println("Found " + mappings + " terminological mappings");

            out.close();

        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {

        MeshSnomedConceptsDescriptionsLoader lemmatizer = new MeshSnomedConceptsDescriptionsLoader(true);
        lemmatizer.detectMappings();
    }
}
