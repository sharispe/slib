/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abacus.sim.biolemmatize;

import abacus.sim.MappingComputer_MeshSnomed;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import slib.indexer.IndexedElement;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class LuceneMeshSnomedCT_Test {

    Analyzer analyzer;
    Directory index;
    public static String INDEXED_FIELD = "DESCRIPTION";
    public static String URI_FIELD = "URI";
    int hitsPerPage = 20;
    MappingComputer_MeshSnomed dataRepo;

    public LuceneMeshSnomedCT_Test() throws Exception {

        dataRepo = new MappingComputer_MeshSnomed(false);

        // 0. Specify the analyzer for tokenizing text.
        //    The same analyzer should be used for indexing and searching
        analyzer = new StandardAnalyzer(Version.LUCENE_35);

        System.out.println("Building Lucene Index");
        // 1. create the index
        index = new RAMDirectory();

        IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_35, analyzer);

        IndexWriter w = new IndexWriter(index, config);

        //Index Mesh
        System.out.println("Indexing Mesh");
        for (Map.Entry<Value, IndexedElement> e : dataRepo.indexMesh.getMapping().entrySet()) {

            for (String s : e.getValue().getDescriptions()) {
                Document doc = new Document();
                doc.add(new Field(INDEXED_FIELD, s, Field.Store.YES, Field.Index.ANALYZED));
                doc.add(new Field(URI_FIELD, e.getKey().stringValue(), Field.Store.YES, Field.Index.NO));
                w.addDocument(doc);
            }
        }


        System.out.println("Indexing SnomedCT");
        for (Map.Entry<Value, IndexedElement> e : dataRepo.indexSnomed.getMapping().entrySet()) {

            for (String s : e.getValue().getDescriptions()) {
                Document doc = new Document();
                doc.add(new Field(INDEXED_FIELD, s, Field.Store.YES, Field.Index.ANALYZED));
                doc.add(new Field(URI_FIELD, e.getKey().stringValue(), Field.Store.YES, Field.Index.NO));
                w.addDocument(doc);
            }
        }
        w.close();

        dataRepo.indexMesh = null;
        dataRepo.indexSnomed = null;
    }

    public void query(String querystr) throws IOException, ParseException {

        if (querystr.startsWith("?")) {
            printDescription(querystr);
            return;
        }
        // the "title" arg specifies the default field to use
        // when no field is explicitly specified in the query.
        Query q = new QueryParser(Version.LUCENE_35, INDEXED_FIELD, analyzer).parse(querystr);

        // 3. search

        IndexReader reader = IndexReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopScoreDocCollector collector = TopScoreDocCollector.create(hitsPerPage, true);
        searcher.search(q, collector);
        ScoreDoc[] hits = collector.topDocs().scoreDocs;

        DataFactory f = DataFactoryMemory.getSingleton();

        // 4. display results
        System.out.println("Found " + hits.length + " hits.");

        for (int i = 0; i < hits.length; ++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            String uriAsString = d.get(URI_FIELD);
            URI u = f.createURI(uriAsString);
            String id = null;
            if (dataRepo.meshGraph.containsVertex(u)) {
                id = ((URI) dataRepo.meshGraph.getV(u).getValue()).getLocalName();
            } else if (dataRepo.snomedGraph.containsVertex(u)) {
                id = ((URI) dataRepo.snomedGraph.getV(u).getValue()).getLocalName();
            }
            System.out.println((i + 1) + ". " + d.get(INDEXED_FIELD) + "\t" + "[" + id + "] " + uriAsString);
        }

        // searcher can only be closed when there
        // is no need to access the documents any more.
        searcher.close();
    }

    private void printDescription(String querystr) {
        querystr = querystr.substring(1);

        URI uriMesh = DataFactoryMemory.getSingleton().createURI(dataRepo.meshGraph.getURI().getNamespace() + querystr);
        URI uriSnomed = DataFactoryMemory.getSingleton().createURI(dataRepo.snomedGraph.getURI().getNamespace() + querystr);

        if (dataRepo.snomedGraph.containsVertex(uriSnomed)) {
            for (String s : dataRepo.indexSnomed.getMapping().get(uriSnomed).getDescriptions()) {
                System.out.println("\t" + s);
            }
        } else if (dataRepo.meshGraph.containsVertex(uriMesh)) {
            for (String s : dataRepo.indexMesh.getMapping().get(uriMesh).getDescriptions()) {
                System.out.println("\t" + s);
            }
        }

    }

    public static void main(String[] args) {

        try {
            System.out.println("Indexing...");
            LuceneMeshSnomedCT_Test test = new LuceneMeshSnomedCT_Test();

            System.out.println("Enter an empty query to stop exec");
            boolean stop = false;

            while (!stop) {

                System.out.println("--------------------------------------------");
                System.out.print("Query: ");
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                String q = null;
                try {
                    q = br.readLine();
                    if (q.isEmpty()) {
                        stop = true;
                        continue;
                    }

                } catch (Exception e) {
                    System.out.println("Error!" + e.getMessage());
                    System.exit(1);
                }
                System.out.println("> " + q);
                test.query(q);
            }

            System.out.println("Exiting");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
}
