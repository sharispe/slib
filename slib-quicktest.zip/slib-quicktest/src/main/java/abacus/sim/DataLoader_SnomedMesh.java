/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;

import org.openrdf.model.URI;
import slib.indexer.IndexHash;
import slib.indexer.mesh.Indexer_MESH_XML;
import slib.indexer.snomed_ct.IndexerSNOMEDCT_RF2;
import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.loader.bio.mesh.GraphLoader_MESH_XML;
import slib.sglib.io.loader.bio.snomedct.GraphLoaderSnomedCT_RF2;
import slib.sglib.io.loader.slibformat.GraphLoader_SLIB;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.utils.ex.SLIB_Exception;

/**
 * Class used to load the data associated to the experiment
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class DataLoader_SnomedMesh {

    public static final String SNOMEDCT_URI = "http://biograph/snomed-ct/";
    public static final String MESH_URI = "http://biograph/mesh/";
    public static final String DATA_DIR = "/data";
    public static final String SNOMEDCT_VERSION = "20120731";
    public static final String SNOMEDCT_DIR = DATA_DIR + "/SnomedCT_Release_INT_" + SNOMEDCT_VERSION + "/RF2Release/Full/Terminology";
    public static final String SNOMEDCT_CONCEPT = SNOMEDCT_DIR + "/sct2_Concept_Full_INT_" + SNOMEDCT_VERSION + ".txt";
    public static final String SNOMEDCT_RELATIONSHIPS = SNOMEDCT_DIR + "/sct2_Relationship_Full_INT_" + SNOMEDCT_VERSION + ".txt";
    public static final String SNOMEDCT_DESCRIPTIONS = SNOMEDCT_DIR + "/sct2_Description_Full-en_INT_" + SNOMEDCT_VERSION + ".txt";
    public static final String MESH_XML_FILE = DATA_DIR + "/mesh/desc2013.xml";
    public static final String MESH_SLIB = DATA_DIR + "/mesh/mesh_DAG.slib";
    public static final String SNOMEDCT_SLIB = DATA_DIR+"/SnomedCT_Release_INT_20120731/snomed-ct-DAG-20120731.slib";

    
    public static final String projectRoot = "/home/seb/docs/thesis/experiments/snomed-ct_mesh/";
    public static final String mappingFile  = projectRoot+"mappings/snomed_mesh_mapping.csv";
    public static final String queryFile    = projectRoot+"benchmarks/pedersen_2007/pedersen_2007.csv";
    public static final String bestMappingsNMPI_file             = projectRoot+"mappings/bestMappingsNPMI.csv";
    public static final String bestMappingsNMPI_ReduceSpace_file = projectRoot+"mappings/bestMappingsNPMI_reduce_space.csv";
        
   
    public static final boolean SNOMEDINDEX_EXCLUDE_INACTIVE_DESCRIPTIONS = false;
    public static final boolean SNOMEDINDEX_EXCLUDE_OLD_DESCRIPTIONS      = false;
    
    public static final String PAKHOMOV_BENCHMARK = projectRoot+"benchmarks/pakhomov_2010/UMNSRS_similarity.csv";
    
    public static final String mappingMESH_2_UMLS     = projectRoot+"mappings/UMLS/mappingsMeSHtoUMLS.csv";
    public static final String mappingSNOMEDCT_2_UMLS = projectRoot+"mappings/UMLS/mappingsSNOMEDCTtoUMLS.csv";
    
    public static final String mappingUMLS_2_MESH     = projectRoot+"mappings/UMLS/mappingsUMLStoMeSH.csv";
    public static final String mappingUMLS_2_SNOMEDCT = projectRoot+"mappings/UMLS/mappingsUMLStoSNOMEDCT.csv";
    public static String UMLS_CONCEPTS_A = "/data/UMLS/MRCONSO.RRF.aa";
    public static String UMLS_CONCEPTS_B = "/data/UMLS/MRCONSO.RRF.ab";
    
    
    public static G loadMesh_FromOriginalSpec() throws SLIB_Exception {

        GraphLoader_MESH_XML loader = new GraphLoader_MESH_XML();
        URI uri = DataFactoryMemory.getSingleton().createURI(MESH_URI);
        G g = new GraphMemory(uri);

        DataFactoryMemory.getSingleton().addGraph(g);
        GDataConf conf = new GDataConf(GFormat.MESH_XML, MESH_XML_FILE);
        conf.addParameter(GraphLoader_MESH_XML.ARG_PREFIX, MESH_URI);

        loader.populate(conf, g);

        return g;
    }

    public static G loadSnomedCT_FromOriginalSpec() throws SLIB_Exception {

        GraphLoaderSnomedCT_RF2 loader = new GraphLoaderSnomedCT_RF2();
        URI uri = DataFactoryMemory.getSingleton().createURI(SNOMEDCT_URI);
        G g = new GraphMemory(uri);

        DataFactoryMemory.getSingleton().addGraph(g);
        GDataConf conf = new GDataConf(GFormat.SNOMED_CT_RF2);
        conf.addParameter(GraphLoaderSnomedCT_RF2.ARG_CONCEPT_FILE, SNOMEDCT_CONCEPT);
        conf.addParameter(GraphLoaderSnomedCT_RF2.ARG_RELATIONSHIP_FILE, SNOMEDCT_RELATIONSHIPS);

        loader.populate(conf, g);

        return g;
    }

    static IndexHash loadSnomedCT_Index(G snomedGraph) throws SLIB_Exception {
        DataFactory factory = DataFactoryMemory.getSingleton();
        IndexerSNOMEDCT_RF2 indexer = new IndexerSNOMEDCT_RF2();
        IndexHash indexSnomed = indexer.buildIndex(factory, SNOMEDCT_DESCRIPTIONS, SNOMEDCT_URI, snomedGraph, SNOMEDINDEX_EXCLUDE_INACTIVE_DESCRIPTIONS, SNOMEDINDEX_EXCLUDE_OLD_DESCRIPTIONS);
        return indexSnomed;
    }

    static IndexHash loadMesh_Index(G meshGraph) throws SLIB_Exception {
        DataFactory factory = DataFactoryMemory.getSingleton();
        Indexer_MESH_XML indexer = new Indexer_MESH_XML();
        IndexHash indexMesh = indexer.buildIndex(factory, MESH_XML_FILE, meshGraph.getURI().stringValue());
        return indexMesh;
    }

    static G loadMesh_FromSLIB() throws SLIB_Exception {
        DataFactory factory = DataFactoryMemory.getSingleton();
        URI uri = DataFactoryMemory.getSingleton().createURI(MESH_URI);
        G mesh = new GraphMemory(uri);

        factory.addGraph(mesh);

        new GraphLoader_SLIB().populate(new GDataConf(GFormat.SLIB, MESH_SLIB), mesh);
        return mesh;
    }

    static G loadSNOMEDCT_FromSLIB() throws SLIB_Exception {
        DataFactory factory = DataFactoryMemory.getSingleton();
        URI uri = DataFactoryMemory.getSingleton().createURI(SNOMEDCT_URI);
        G snomed = new GraphMemory(uri);

        factory.addGraph(snomed);

        new GraphLoader_SLIB().populate(new GDataConf(GFormat.SLIB, SNOMEDCT_SLIB), snomed);
        return snomed;
    }
}
