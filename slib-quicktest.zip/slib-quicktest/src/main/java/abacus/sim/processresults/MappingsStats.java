/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim.processresults;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.openrdf.model.URI;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class MappingsStats {

    Map<URI, Set<URI>> mappings;

    public MappingsStats(String mapFile) {
        mappings = new HashMap<URI, Set<URI>>();
        loadMapping(mapFile);
        computeDistribution(null);
        computeDistribution("http://graph/snomed-ct/");
        computeDistribution("http://biograph/mesh/");
    }
    
    private void computeDistribution(String namespace){
        
        System.out.println("Computing stat for namespace: "+namespace);
        
        Map<Integer,Set<URI>> mappingsR = new HashMap<Integer, Set<URI>>();
        for(Entry<URI, Set<URI>> e : mappings.entrySet()){
            
            if(namespace != null && !e.getKey().getNamespace().equals(namespace)){
                continue;
            }
            
            int size = e.getValue().size();
            if(!mappingsR.containsKey(size)){
                mappingsR.put(size, new HashSet<URI>());
            }
            mappingsR.get(size).add(e.getKey());
        }
        long countConcept = 0;
        for(Entry<Integer, Set<URI>> e : mappingsR.entrySet()){
            
            String uris = "";
            if(e.getValue().size() <= 10){
                uris = e.getValue().toString();
            }
            System.out.println(e.getKey()+"\t"+e.getValue().size()+"\t"+uris);
            countConcept += e.getValue().size();
        }
        System.out.println("Concepts numbers : "+countConcept);
        
    }

    private void loadMapping(String file) {
        
        long mappingsCount = 0;
        try {
            DataFactory factory = DataFactoryMemory.getSingleton();

            FileInputStream fstream = new FileInputStream(file);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                String[] data = line.split("\t");
                URI a = factory.createURI(data[0]);
                URI b = factory.createURI(data[1]);

                if (!mappings.containsKey(a)) {
                    mappings.put(a, new HashSet<URI>());
                }
                mappings.get(a).add(b);
                mappingsCount ++;
            }
            
            in.close();
        } catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
        System.out.println(mappingsCount+" mappings loaded");
    }
    
    
    
    
    public static void main(String[] a){
        MappingsStats stat = new MappingsStats("/tmp/snomed_mesh_mapping.csv");
    }
}

