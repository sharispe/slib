/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;

import java.util.Map;
import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.sglib.algo.utils.WalkConstraintTax;
import slib.sglib.algo.validator.dag.ValidatorDAG;
import slib.sglib.io.loader.GraphLoaderGeneric;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.E;
import slib.sglib.model.graph.elements.V;
import slib.sglib.model.graph.utils.Direction;
import slib.sglib.model.graph.utils.WalkConstraints;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.sml.sm.core.metrics.ic.utils.IC_Conf_Topo;
import slib.sml.sm.core.metrics.ic.utils.ICconf;
import slib.sml.sm.core.utils.SMConstants;
import slib.sml.sm.core.utils.SM_Engine;
import slib.sml.sm.core.utils.SMconf;
import slib.tools.module.GlobalConfPattern;
import slib.tools.module.XMLConfLoaderGeneric;
import slib.utils.impl.ResultStack;
import slib.utils.impl.UtilDebug;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class SnomedCT_Test {

    public static void main(String[] a) throws Exception {

        // Error on Snomed-ct todo check that every concept is part of the same taxonomic graph...

        // Incoherency http://biograph/snomed-ct/302509004	http://biograph/snomed-ct/74281007	1.3398977329942772

        Logger logger = LoggerFactory.getLogger("SnomedCT_Test");

        String file = "/data/test/slib.test.snomedct.xml";

        DataFactory factory = DataFactoryMemory.getSingleton();

        // Load graphs --------------------------------------------------------
        GraphLoaderGeneric.load(new XMLConfLoaderGeneric(file).getGraphConfs());
        GlobalConfPattern conf = GlobalConfPattern.getInstance();
        String uriMeshString = conf.getValue("URI_SNOMED-CT");

        URI gURI_snomedct = factory.createURI(uriMeshString);
        G snomedct = factory.getGraph(gURI_snomedct);
        
        
        ValidatorDAG validator = new ValidatorDAG();
        boolean isDag = validator.isDag(snomedct, RDFS.SUBCLASSOF, Direction.OUT);
        
        System.out.println("ISDAG : "+isDag);
        UtilDebug.exit(null);

        SM_Engine engineSnomedct = new SM_Engine(snomedct);

        URI conceptX = factory.createURI("http://biograph/snomed-ct/301227004");
        V vX = snomedct.getV(conceptX);



        Set<E> edges = snomedct.getE(RDFS.SUBCLASSOF, vX, Direction.BOTH);

        System.out.println("Number of Edges " + edges.size());






        for (E e : edges) {
            System.out.println("\t" + e);
        }

        Set<V> descendants = engineSnomedct.getDescendantsInc(vX);

        System.out.println("Descendants " + descendants.size());
        for (V v : descendants) {
            System.out.println("\t" + v);
        }


        Map<V, Set<V>> allDescendants = engineSnomedct.getAllDescendantsInc();

        Set<V> descendantsOpt = allDescendants.get(vX);
        System.out.println("Descendants Optimize " + descendantsOpt.size());

        ResultStack<V, Long> nbDescendants = engineSnomedct.getAllNbDescendantsInc();

        System.out.println(conceptX + "\t" + nbDescendants.get(vX));
        System.out.println(conceptX + "\t" + nbDescendants.get(vX).doubleValue());

        ICconf icConf = new IC_Conf_Topo(SMConstants.FLAG_ICI_SECO_2004);
        
        
        System.out.println("Reachable nodes according to WC constraint");
        WalkConstraints wc = new WalkConstraintTax(RDFS.SUBCLASSOF,Direction.IN);
        WalkConstraints wcOpposite = wc.getInverse(false);
        
        Set<E> eConstrained = snomedct.getE(vX, wcOpposite);
        for(E e : eConstrained){
            System.out.println("~~\t"+e);
        }
        
        

//        engineSnomedct.computeIC(icConf);

        UtilDebug.exit(SnomedCT_Test.class);



        URI conceptA = factory.createURI("http://biograph/snomed-ct/302509004");
        URI conceptB = factory.createURI("http://biograph/snomed-ct/74281007");

        URI mica = factory.createURI("http://biograph/snomed-ct/70104002");


        SMconf measureConf = new SMconf("Lib", SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998, "Lin", icConf);

        V vA = snomedct.getV(conceptA);
        V vB = snomedct.getV(conceptB);
        V vMICA = snomedct.getV(mica);



        System.out.println(vA);
        System.out.println(vB);
        System.out.println(vMICA);

        double sim = engineSnomedct.computePairwiseSim(measureConf, vA, vB);

        System.out.println(conceptA);
        System.out.println(conceptB);
        System.out.println(sim);

        System.out.println("Search descendants / ancestors");

        System.out.println("Ancestors focused concepts");
        Set<V> ancA = engineSnomedct.getAncestorsInc(vA);
        Set<V> ancB = engineSnomedct.getAncestorsInc(vB);

        System.out.println("Ancestors A " + ancA.size());
        for (V v : ancA) {
            System.out.println("\t" + v);
        }

        System.out.println("Ancestors B " + ancB.size());
        for (V v : ancB) {
            System.out.println("\t" + v);
        }

        Set<V> descMICA = engineSnomedct.getDescendantsInc(vMICA);

        System.out.println("Descendants MICA A/B " + descMICA.size());
        for (V v : descMICA) {
            System.out.println("\t" + v);
        }

        ResultStack<V, Long> nbDescendantsInc = engineSnomedct.getAllNbDescendantsInc();

        for (V v : nbDescendantsInc.keySet()) {

            if (nbDescendantsInc.get(v) != engineSnomedct.getDescendantsInc(v).size()) {
                System.out.println("*** " + v + "\tnbDesc: " + nbDescendantsInc.get(v) + "\t" + engineSnomedct.getDescendantsInc(v).size());
            }
        }
    }
}
