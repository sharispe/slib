/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim.results;

import abacus.sim.DataLoader_SnomedMesh;
import abacus.sim.benchmarkBuilder.Pair;
import au.com.bytecode.opencsv.CSVReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.impl.SetUtils;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class ResultLoader {

    private Set<Pair<String, String>> getMinimalSetOfPairs(List<ResultSet> queryResults) throws SLIB_Ex_Critic {

        Set<Pair<String, String>> pairs;

        if (queryResults.size() < 1) {
            throw new SLIB_Ex_Critic("Warning results must contains at leat a result set");
        }


        pairs = new HashSet(queryResults.get(0).querySet());

        for (ResultSet rSet : queryResults) {

            pairs = SetUtils.intersection(pairs, rSet.querySet());
        }

        logger.info("Minimal set of queries shared among the " + queryResults.size() + " result sets contains " + pairs.size() + " couples of concepts");

        return pairs;


    }
    Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * The method returns a set of String pairs corresponding to the queries
     * composing the benchmark specified in the given file. The file is expected
     * to contains a header with column 1 dedicated to concept 1 and column 2
     * dedicated to concept 2
     *
     * @param fpath the location of the benchmark file
     * @return the list of pairs corresponding to the entries composing the
     * benchmark.
     */
    public List<Pair<String, String>> loadQueries(String fpath, char separator) throws Exception {

        logger.info("Loading queries from " + fpath);

        List<Pair<String, String>> queries = new LinkedList<Pair<String, String>>();
        CSVReader reader = new CSVReader(new FileReader(fpath), separator);

        String[] nextLine;
        boolean header = true;

        while ((nextLine = reader.readNext()) != null) {

            if (header) {
                header = false;
                continue;
            }
            queries.add(new Pair<String, String>(nextLine[0], nextLine[1]));
        }
        logger.info("Benchmark loaded " + queries.size() + " pairs of concepts");
        return queries;
    }

    /**
     * Load the results contained in a particular file
     *
     * @param queries
     * @param fpath
     * @return
     */
    public ResultSet loadResults(String label, String fpath, char separator) throws Exception {


        logger.info("Loading results from " + fpath);
        ResultSet rSet = new ResultSet(label);

        CSVReader reader = new CSVReader(new FileReader(fpath), separator);

        String[] nextLine;
        boolean header = true;
        int totalScore = 0;

        while ((nextLine = reader.readNext()) != null) {

            if (header) {
                header = false;
                continue;
            }
            Pair<String, String> p = new Pair<String, String>(nextLine[0], nextLine[1]);

            if (!rSet.containsQuery(p)) {
                rSet.put(p, new HashSet<QueryResult>());
            }

            Double score = null;

            try {
                score = Double.parseDouble(nextLine[6]);
            } catch (java.lang.NumberFormatException e) {
                logger.info("Cannot convert " + nextLine[6] + " to double value, result set to " + score);
            }

            QueryResult r = new QueryResult(p, nextLine[2], nextLine[3], nextLine[4], nextLine[5], score);
            rSet.get(p).add(r);
            totalScore++;

        }
        logger.info("Results loaded " + rSet.size() + ", pairs of concepts are represented in the result stack, number of scores loaded " + totalScore);
        return rSet;
    }

    /**
     * Remove results for which a Null value is associated to the QueryResult
     * Queries for which the associated set of QueryResult is empty are removed
     * for the ResultSet.
     *
     * @param filter
     * @param setToFilter
     * @return
     */
    public ResultSet removeNullResults(ResultSet resultSet) {

        ResultSet r = new ResultSet(resultSet.label);

        for (Pair<String, String> query : resultSet.querySet()) {

            Set<QueryResult> results = resultSet.get(query);
            Set<QueryResult> newResults = new HashSet<QueryResult>();

            for (QueryResult e : results) {
                if (e.score != null) {
                    newResults.add(e);
                }
            }

            if (!newResults.isEmpty()) {
                r.put(query, newResults);
            }
        }
        return r;
    }

    /**
     * Return null if null score are associated to the resultSet
     *
     * @param results
     * @return
     */
    public Double getMax(Set<QueryResult> results) {

        Double score = null;

        for (QueryResult r : results) {
            if (r.score != null && (score == null || score < r.score)) {
                score = r.score;
            }
        }
        return score;
    }

    /**
     * Create a file containing the results contained in the results
     *
     * @param queryResultsReduced
     * @param fpath
     */
    private void flush(ResultSet queryResults, String fpath) throws Exception {

        logger.info("Flushin results to " + fpath);

        FileWriter writer = new FileWriter(new File(fpath));
        writer.write("TERM_A|TERM_B|SCORE\n");
        for (Pair<String, String> p : queryResults.querySet()) {

            Double score = getMax(queryResults.get(p));
            writer.write(p.getKey() + "|" + p.getValue() + "|" + score + "\n");

        }
        writer.close();

        logger.info("done.");
    }

    public List<File> getCSVFiles(String dir) {

        logger.info("Loading files from " + dir);

        File folder = new File(dir);
        File[] listOfFiles = folder.listFiles();

        List<File> listFiles = new LinkedList<File>();

        for (int i = 0; i < listOfFiles.length; i++) {

            String[] data = listOfFiles[i].getName().split("\\.");

            if (listOfFiles[i].isFile() && data.length > 0 && data[data.length - 1].equals("csv")) {
                listFiles.add(listOfFiles[i]);
            }
        }

        logger.info(listFiles.size() + " files loaded ");
        return listFiles;
    }

    private List<ResultSet> loadResults(List<File> files, char separator) throws Exception {

        logger.info("Loading results");
        List<ResultSet> resultSets = new LinkedList<ResultSet>();

        for (File f : files) {
            resultSets.add(loadResults(f.getName(), f.getPath(), separator));
        }


        logger.info(resultSets.size() + " result sets loaded");
        return resultSets;
    }

    private List<ResultSet> reduceQueryResults(List<ResultSet> queryResults, Set<Pair<String, String>> minimalSetOfQueries) throws SLIB_Ex_Critic {

        List<ResultSet> newSetResults = new LinkedList<ResultSet>();

        for (ResultSet r : queryResults) {

            if (!r.querySet().containsAll(minimalSetOfQueries)) {
                throw new SLIB_Ex_Critic("Error cannot retrieve the specified minimal set of query for result Set " + r.label);
            } else {
                ResultSet rnew = new ResultSet(r.label);
                for (Pair<String, String> p : minimalSetOfQueries) {
                    rnew.put(p, r.get(p));
                }
                newSetResults.add(rnew);
            }
        }

        logger.info("Reduction performed");

        return newSetResults;
    }

    public static void generatePedersen2007() throws Exception {

        ResultLoader loader = new ResultLoader();
        List<Pair<String, String>> querySet = loader.loadQueries(DataLoader_SnomedMesh.queryFile, '\t');

        List<File> files = loader.getCSVFiles("/tmp/pedersen2007/");

        for (File f : files) {
            System.out.println(f);
        }

        List<ResultSet> queryResults = loader.loadResults(files, '|');

        // we retrieve the minimal set of queries
        // for which at least a score is available in the result sets specified
        Set<Pair<String, String>> minimalSetOfQueries = loader.getMinimalSetOfPairs(queryResults);


        List<ResultSet> queryResultsReduced = loader.reduceQueryResults(queryResults, minimalSetOfQueries);

        File dir = new File("/tmp/pedersen2007/reduced/");
        dir.mkdir();

        for (ResultSet r : queryResultsReduced) {
            String fpath = dir.getPath() + "/reduced_max_" + r.label;
            loader.flush(r, fpath);
        }

    }

    public static void main(String[] a) throws Exception {
//        ResultSet queryResults = loader.loadResults("MESH_SNOMEDCT__REDUCED_SEARCH_SPACE_RESNIK_Sanchez_NONE", "/tmp/pedersen2007_MESH_SNOMEDCT__REDUCED_SEARCH_SPACE_RESNIK_Sanchez_NONE.csv", '|');
//
//        for (Pair p : querySet) {
//            if (queryResults.containsQuery(p)) {
//                System.out.println(p + "\t" + loader.getMax(queryResults.get(p)));
//            } else {
//                System.out.println(p + "\tNo results");
//            }
//        }
//
//        Set<Pair<String, String>> intersectionQueries = SetUtils.intersection(querySet, queryResults.querySet());
//
//        System.out.println("Intersection " + intersectionQueries.size());
//
//        ResultSet queryResultsReduced = loader.removeNullResults(queryResults);
//        System.out.println("Size reduction " + queryResultsReduced.size());
//        
    }
}
