/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim.mappings;

import abacus.sim.DataLoader_SnomedMesh;
import au.com.bytecode.opencsv.CSVReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.utils.ex.SLIB_Ex_Critic;

/**
 * Class used to load Snomed-CT and MeSH UMLS mappings
 * http://www.ncbi.nlm.nih.gov/books/NBK9685/
 * http://www.nlm.nih.gov/research/umls/knowledge_sources/metathesaurus/release/columns_data_elements.html
 *
 * Only entry with Suppress code equals to N are considered
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class UMLSmappingsLoader {

    Pattern p = Pattern.compile("\\|");
    public static int ID_UMLS_CONCEPT_ID = 0;
    public static int ID_ONTOLOGY = 11;
    public static int ID_ONTOLOGY_CONCEPT = 13;
    public static int ID_SUPPRESS_CODE = 16;
    public static String MESH_SAB      = "MSH";
    public static String SNOMEDCT_SAB  = "SNOMEDCT";
    public static String SUPPRESS_CODE = "N";
    
    Map<String, Set<String>> umls2Mesh     = new HashMap<String, Set<String>>();
    Map<String, Set<String>> umls2SnomedCT = new HashMap<String, Set<String>>();
    Map<String, Set<String>> mesh2umls     = new HashMap<String, Set<String>>();
    Map<String, Set<String>> snomedCT2umls = new HashMap<String, Set<String>>();
    
    Logger logger = LoggerFactory.getLogger(this.getClass());

    public UMLSmappingsLoader(String... files ) throws SLIB_Ex_Critic {
        
        for(String s : files){
            load(s);
        }
        
        
        
        logger.info("Building mapping MeSH 2 UMLS");

        mesh2umls = buildInverseMapping(umls2Mesh);

        logger.info("Mapping MeSH 2 UMLS");
        logger.info(mesh2umls.size() + " entries");
        
        logger.info("Building mapping SnomedCT 2 UMLS");

        snomedCT2umls = buildInverseMapping(umls2SnomedCT);

        logger.info("Mapping SnomedCT 2 UMLS");
        logger.info(snomedCT2umls.size() + " entries");
        
    }

    private void load(String fpath) throws SLIB_Ex_Critic {

        String[] nextLine = null;

        try {

            CSVReader reader = new CSVReader(new FileReader(fpath), '|');


            String ulmsID, ontology, ontologyConceptID, suppressCode;


            logger.info("Loading mappings from " + fpath);

            while ((nextLine = reader.readNext()) != null) {


                suppressCode = nextLine[ID_ONTOLOGY_CONCEPT];

                if (suppressCode.equals(SUPPRESS_CODE)) {
                    continue;
                }

                ulmsID = nextLine[ID_UMLS_CONCEPT_ID];
                ontology = nextLine[ID_ONTOLOGY];
                ontologyConceptID = nextLine[ID_ONTOLOGY_CONCEPT];

                if (ontology.equals(MESH_SAB)) {

                    // only consider descriptor UI
                    if (!ontologyConceptID.startsWith("D")) {
                        continue;
                    }

                    if (!umls2Mesh.containsKey(ulmsID)) {
                        umls2Mesh.put(ulmsID, new HashSet<String>());
                    }
                    umls2Mesh.get(ulmsID).add(ontologyConceptID);
                } else if (ontology.equals(SNOMEDCT_SAB)) {

                    if (!umls2SnomedCT.containsKey(ulmsID)) {
                        umls2SnomedCT.put(ulmsID, new HashSet<String>());
                    }
                    umls2SnomedCT.get(ulmsID).add(ontologyConceptID);
                }
            }
            logger.info("UMLS to MeSH Mappings " + umls2Mesh.size() + " entries");
            logger.info("UMLS to SnomedCT Mappings " + umls2SnomedCT.size() + " entries");



        } catch (Exception ex) {
            throw new SLIB_Ex_Critic(ex.getMessage() + "\t" + Arrays.toString(nextLine));
        }
    }

    private void flushMeSH2UMLS(String fpath) throws SLIB_Ex_Critic {
        

        logger.info("Flushing Mapping MeSH 2 UMLS to " + fpath);
        flushMappingToFile(fpath, "MESH_DECRIPTORUI|UMLS_CONCEPTS", mesh2umls);

    }

    private void flushUMLS2MesSH(String fpath) throws SLIB_Ex_Critic {


        logger.info("Flushing Mapping UMLS 2 MeSH to " + fpath);
        flushMappingToFile(fpath, "UMLS_CONCEPT|MESH_DECRIPTORUIS", umls2Mesh);

    }

    private void flushSnomedCT2UMLS(String fpath) throws SLIB_Ex_Critic {


        logger.info("Flushing Mapping SnomedCT 2 UMLS to " + fpath);
        flushMappingToFile(fpath, "SNOMED_CONCEPT_ID|UMLS_CONCEPT", snomedCT2umls);
    }

    private void flushUMLS2SnomedCT(String fpath) throws SLIB_Ex_Critic {


        logger.info("Flushing Mapping UMLS 2 SnomedCT to " + fpath);
        flushMappingToFile(fpath, "UMLS_CONCEPT|SNOMED_CONCEPT_IDS", umls2SnomedCT);

    }

    private void flushMappingToFile(String fpath, String header, Map<String, Set<String>> mappings) throws SLIB_Ex_Critic {

        try {

            BufferedWriter out = new BufferedWriter(new FileWriter(fpath));
            out.write(header + "\n");

            for (Entry<String, Set<String>> e : mappings.entrySet()) {

                String o = e.getKey() + "|";
                boolean f = true;
                for (String s : e.getValue()) {
                    if (!f) {
                        o += ";";
                    }
                    f = false;
                    o += s;
                }
                out.write(o + "\n");

            }

            out.close();
        } catch (Exception e) {
            throw new SLIB_Ex_Critic(e.getMessage());
        }
    }

    private Map<String, Set<String>> buildInverseMapping(Map<String, Set<String>> baseMapping) {

        Map<String, Set<String>> inverseMapping = new HashMap<String, Set<String>>();

        String keyConcept = null;
        for (Entry<String, Set<String>> e : baseMapping.entrySet()) {

            keyConcept = e.getKey();

            for (String targetConcept : e.getValue()) {
                if (!inverseMapping.containsKey(targetConcept)) {
                    inverseMapping.put(targetConcept, new HashSet<String>());
                }
                inverseMapping.get(targetConcept).add(keyConcept);
            }
        }
        return inverseMapping;
    }

    public Map<String, Set<String>> getUmls2Mesh() {
        return umls2Mesh;
    }

    public Map<String, Set<String>> getUmls2SnomedCT() {
        return umls2SnomedCT;
    }

    public Map<String, Set<String>> getMesh2umls() {
        return mesh2umls;
    }

    public Map<String, Set<String>> getSnomedCT2umls() {
        return snomedCT2umls;
    }
    
    
    
    
    

    public static void main(String[] a) throws SLIB_Ex_Critic {

        UMLSmappingsLoader loader = new UMLSmappingsLoader(DataLoader_SnomedMesh.UMLS_CONCEPTS_A, DataLoader_SnomedMesh.UMLS_CONCEPTS_B);

        loader.flushMeSH2UMLS(DataLoader_SnomedMesh.mappingMESH_2_UMLS);
        loader.flushUMLS2MesSH(DataLoader_SnomedMesh.mappingUMLS_2_MESH);

        loader.flushSnomedCT2UMLS(DataLoader_SnomedMesh.mappingSNOMEDCT_2_UMLS);
        loader.flushUMLS2SnomedCT(DataLoader_SnomedMesh.mappingUMLS_2_SNOMEDCT);
    }
}
