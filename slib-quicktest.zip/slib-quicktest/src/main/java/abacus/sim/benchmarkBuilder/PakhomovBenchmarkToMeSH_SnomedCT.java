/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim.benchmarkBuilder;

import abacus.sim.DataLoader_SnomedMesh;
import abacus.sim.mappings.UMLSmappingsLoader;
import au.com.bytecode.opencsv.CSVReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.utils.ex.SLIB_Ex_Critic;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class PakhomovBenchmarkToMeSH_SnomedCT {

    List<Pair<String, String>> benchmarkPairs;
    Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final int ulmsID_1 = 4;
    private static final int ulmsID_2 = 5;

    public PakhomovBenchmarkToMeSH_SnomedCT(String benchmarkFile) throws SLIB_Ex_Critic {

        benchmarkPairs = new LinkedList<Pair<String, String>>();
        loadBenchmark(benchmarkFile);
    }

    private void loadBenchmark(String fpath) throws SLIB_Ex_Critic {
        String[] nextLine = null;

        try {

            CSVReader reader = new CSVReader(new FileReader(fpath), ',');

            logger.info("Loading mappings from " + fpath);
            boolean header = true;

            while ((nextLine = reader.readNext()) != null) {


                if (header) {
                    header = false;
                    continue;
                }

                //logger.debug("Loading entry " + nextLine[ulmsID_1] + "\t" + nextLine[ulmsID_2]);
                benchmarkPairs.add(new Pair<String, String>(nextLine[ulmsID_1], nextLine[ulmsID_2]));
            }
            logger.info("Benchmark loaded " + benchmarkPairs.size() + " pairs of concepts");

        } catch (Exception ex) {
            throw new SLIB_Ex_Critic(ex.getMessage() + "\t" + Arrays.toString(nextLine));
        }
    }

    /**
     * Return Map corresponding to original pairs of concepts of the concepts for which a corresponding have been 
     * found for both key and value. 
     * The value associated to the map is the set of comparison generated from the mapping.
     * Remind that multiple comparison can be generated for a single pair as 1-to-N relationships can link a UMLS concept to 
     * the given ontology X.
     * 
     * @param umls2X the mapping linking UMLS concepts to set of concepts of the other ontology
     * @return see above
     */
    private Map<Pair<String, String>,Set<Pair<String, String>>> rebuildBenchmark(Map<String, Set<String>> umls2X,Map<String, Set<String>> umls2Y) {

        logger.info("Rebuilding benchmarks");
        Map<Pair<String, String>,Set<Pair<String, String>>> validPairs = new HashMap<Pair<String, String>,Set<Pair<String, String>>>();

        int skipped = 0;
        int processed = 0;
        int generated = 0;

        for (Pair<String, String> p : benchmarkPairs) {

            Set<String> cA2X   = umls2X.get(p.getKey());
            Set<String> cB2Y = umls2Y.get(p.getValue());
            //logger.info(p.getKey() + "\t" + p.getValue() + " -> " + cA2X + "\t" + cB2Y);

            if (cA2X == null || cB2Y == null) {
                skipped++;
            } else {
                validPairs.put(p,new HashSet<Pair<String, String>>());
                processed++;

                for (String s : cA2X) {
                    for (String k : cB2Y) {
                        //logger.info("\t" + s + "\t" + k);
                        generated++;
                         validPairs.get(p).add(new Pair<String, String>(s, k));
                    }
                }
            }
        }

        logger.info("Benchmark generated");
        logger.info("Pairs Skipped   " + skipped);
        logger.info("Pairs Processed " + processed);
        logger.info("Comparison generated due to 1-to-N " + generated);

        return validPairs;
    }
    
    private void flushComparisonToFile(Map<Pair<String, String>,Set<Pair<String, String>>> entries, String fpath) throws SLIB_Ex_Critic{
        
        try {

            BufferedWriter out = new BufferedWriter(new FileWriter(fpath));
            out.write("UMLS_C1|UMLS_C2|C1|C2\n");

            for (Map.Entry<Pair<String, String>,Set<Pair<String, String>>> e : entries.entrySet()) {

                
                for (Pair<String, String> s : e.getValue()) {
                    
                    String o = e.getKey().getKey() + "|"+e.getKey().getValue()+"|"+s.getKey()+"|"+s.getValue()+"\n";
                    out.write(o);
                }
            }
            out.close();
        } catch (Exception e) {
            throw new SLIB_Ex_Critic(e.getMessage());
        }
        
        
    }

    public static void main(String[] a) throws SLIB_Ex_Critic {

        Logger logger = LoggerFactory.getLogger(PakhomovBenchmarkToMeSH_SnomedCT.class);

        UMLSmappingsLoader mappingLoader = new UMLSmappingsLoader(DataLoader_SnomedMesh.UMLS_CONCEPTS_A, DataLoader_SnomedMesh.UMLS_CONCEPTS_B);

        PakhomovBenchmarkToMeSH_SnomedCT b = new PakhomovBenchmarkToMeSH_SnomedCT(DataLoader_SnomedMesh.PAKHOMOV_BENCHMARK);

        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsMesh     = b.rebuildBenchmark(mappingLoader.getUmls2Mesh()    ,mappingLoader.getUmls2Mesh());
        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsSnomedCT = b.rebuildBenchmark(mappingLoader.getUmls2SnomedCT(),mappingLoader.getUmls2SnomedCT());

        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsSnomedCT_MeSH = b.rebuildBenchmark(mappingLoader.getUmls2SnomedCT(),mappingLoader.getUmls2Mesh());
        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsMeSH_SnomedCT = b.rebuildBenchmark(mappingLoader.getUmls2Mesh(), mappingLoader.getUmls2SnomedCT());
        
        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsMeSH_SnomedCT__SnomedCT_MeSH = new HashMap<Pair<String, String>,Set<Pair<String, String>>>();
                
        // Build the union C1 from MeSH, C2 from SNOMED and C1 from SNOMED, C2 from MESH
        Set<Pair<String, String>> unionPairsSnomedCT_MeSH_Pairs = new HashSet<Pair<String, String>>(validPairsMeSH_SnomedCT.keySet());
        unionPairsSnomedCT_MeSH_Pairs.addAll(validPairsSnomedCT_MeSH.keySet());
        
        for(Pair<String, String> p : unionPairsSnomedCT_MeSH_Pairs){
            validPairsMeSH_SnomedCT__SnomedCT_MeSH.put(p, new HashSet<Pair<String, String>>());
            
            if(validPairsMeSH_SnomedCT.containsKey(p)){
                validPairsMeSH_SnomedCT__SnomedCT_MeSH.get(p).addAll(validPairsMeSH_SnomedCT.get(p));
            }
        
            if(validPairsSnomedCT_MeSH.containsKey(p)){
                validPairsMeSH_SnomedCT__SnomedCT_MeSH.get(p).addAll(validPairsSnomedCT_MeSH.get(p));
            }
            
        }

        
        logger.info(("MeSH     " + validPairsMesh.size()));
        logger.info(("SnomedCT " + validPairsSnomedCT.size()));
        logger.info(("SNOMEDCT-MESH    " + validPairsSnomedCT_MeSH.size()));
        logger.info(("MESH-SNOMEDCT    " + validPairsMeSH_SnomedCT.size()));
        logger.info(("Union SNOMEDCT-MESH / MESH-SNOMEDCT    " + validPairsMeSH_SnomedCT__SnomedCT_MeSH.size()));

        List<Pair<String, String>> validPairsIntersection = new LinkedList<Pair<String, String>>();
                
        // First Intersection MeSH / SNOMED
        for (Pair<String, String> pm : validPairsMesh.keySet()) {
            for (Pair<String, String> ps : validPairsSnomedCT.keySet()) {
                
                if(pm.equals(ps)){
                    validPairsIntersection.add(pm);
                    break;
                }
            }
        }
        logger.info("Intersection MeSH , SNOMEDCT-MESH  : "+validPairsIntersection.size());
        
        // Then we check that a correspondance is found in the union C1 from MeSH, C2 from SNOMED and C1 from SNOMED, C2 from MESH
        // No correspondance means that a error occured during the process
        Iterator<Pair<String,String>> i = validPairsIntersection.iterator();
        while(i.hasNext()){
            Pair<String, String> p = i.next();
            if(!validPairsMeSH_SnomedCT__SnomedCT_MeSH.containsKey(p)){
                throw new SLIB_Ex_Critic("Incoherent results");
            }
        }
        logger.info("Intersection MeSH , SNOMEDCT-MESH , Union SNOMEDCT-MESH / MESH-SNOMEDCT : "+validPairsIntersection.size());
        
        // Generate the comparison associated to each ontology
        
        b.flushComparisonToFile(validPairsMesh,     "/tmp/pakhomov-2010-MESH-FULL.csv");
        b.flushComparisonToFile(validPairsSnomedCT, "/tmp/pakhomov-2010-SNOMEDCT-FULL.csv");
        b.flushComparisonToFile(validPairsSnomedCT_MeSH, "/tmp/pakhomov-2010-SNOMEDCT-MESH-ORDERED-FULL.csv");
        b.flushComparisonToFile(validPairsMeSH_SnomedCT, "/tmp/pakhomov-2010-MESH-SNOMEDCT-ORDERED-FULL.csv");
        b.flushComparisonToFile(validPairsMeSH_SnomedCT__SnomedCT_MeSH, "/tmp/pakhomov-2010-SNOMEDCT-MESH-UNORDERED-BOTH-FULL.csv");
        
        
        // Generate the benchmark corresponding to the intersection of the pairs 
        // for which a correspondance have been found in both ontologies


        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsSnomedCT_Intersection =  new HashMap<Pair<String, String>,Set<Pair<String, String>>>();
        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsMeSH_Intersection =  new HashMap<Pair<String, String>,Set<Pair<String, String>>>();
        Map<Pair<String, String>,Set<Pair<String, String>>> validPairsMeSH_SnomedCT__SnomedCT_MeSH_Intersection = new HashMap<Pair<String, String>,Set<Pair<String, String>>>();
        
        for(Pair<String, String> p : validPairsIntersection){
            validPairsSnomedCT_Intersection.put(p, validPairsSnomedCT.get(p));
            validPairsMeSH_Intersection.put(p, validPairsMesh.get(p));
            validPairsMeSH_SnomedCT__SnomedCT_MeSH_Intersection.put(p, validPairsMeSH_SnomedCT__SnomedCT_MeSH.get(p));
            
        }
        
        b.flushComparisonToFile(validPairsMeSH_Intersection    , "/tmp/pakhomov-2010-MESH-INTERSECTION.csv");
        b.flushComparisonToFile(validPairsSnomedCT_Intersection, "/tmp/pakhomov-2010-SNOMEDCT-INTERSECTION.csv");
        b.flushComparisonToFile(validPairsSnomedCT_Intersection, "/tmp/pakhomov-2010-SNOMEDCT-MESH-UNORDERED-BOTH-INTERSECTION.csv");
    }
}
