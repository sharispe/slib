/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;

import java.util.HashMap;
import java.util.Map;
import org.openrdf.model.URI;
import slib.sglib.model.graph.G;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class QueryBinaryOnto {

    String conceptA_Desc;
    String conceptB_Desc;
    URI A_onto1;
    URI A_onto2;
    URI B_onto1;
    URI B_onto2;
    Map<String, String> prop = new HashMap<String, String>();
    G onto1;
    G onto2;

    public QueryBinaryOnto(String conceptADesc, String conceptBDesc, G onto1, G onto2, URI A_onto1, URI A_onto2, URI B_onto1, URI B_onto2) {

        this.conceptA_Desc = conceptADesc;
        this.conceptB_Desc = conceptBDesc;

        this.onto1 = onto1;
        this.onto2 = onto2;

        this.A_onto1 = A_onto1;
        this.B_onto1 = B_onto1;

        this.A_onto2 = A_onto2;
        this.B_onto2 = B_onto2;
    }

    public URI getA_onto1() {
        return A_onto1;
    }

    public URI getA_onto2() {
        return A_onto2;
    }

    public URI getB_onto1() {
        return B_onto1;
    }

    public URI getB_onto2() {
        return B_onto2;
    }

    public String getConceptA_Desc() {
        return conceptA_Desc;
    }

    public String getConceptB_Desc() {
        return conceptB_Desc;
    }

    public G getOnto1() {
        return onto1;
    }

    public G getOnto2() {
        return onto2;
    }

    public void addProp(String k, String v) {
        prop.put(k, v);
    }

    public String getProp(String k) {
        return prop.get(k);
    }
}
