/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim.utils;

import org.openrdf.model.URI;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class CoupleOfConcepts {
    
    private URI a;
    private URI b;
    
    private URI graph_a;
    private URI graph_b;
    
    public CoupleOfConcepts(URI a, URI b, URI graph_a, URI graph_b){
        this.a = a;
        this.b = b;
        this.graph_a = graph_a;
        this.graph_b = graph_b;
    }

    public URI getA() {
        return a;
    }

    public URI getB() {
        return b;
    }

    public URI getGraph_A() {
        return graph_a;
    }

    public URI getGraph_B() {
        return graph_b;
    }
    
    public String toString(){
        return "URIs  :"+a+"\t"+b+"\n"+
               "Graphs: "+graph_a+" \t"+graph_b;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 43 * hash + (this.a != null ? this.a.hashCode() : 0);
        hash = 43 * hash + (this.b != null ? this.b.hashCode() : 0);
        hash = 43 * hash + (this.graph_a != null ? this.graph_a.hashCode() : 0);
        hash = 43 * hash + (this.graph_b != null ? this.graph_b.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CoupleOfConcepts other = (CoupleOfConcepts) obj;
        if (this.a != other.a && (this.a == null || !this.a.equals(other.a))) {
            return false;
        }
        if (this.b != other.b && (this.b == null || !this.b.equals(other.b))) {
            return false;
        }
        if (this.graph_a != other.graph_a && (this.graph_a == null || !this.graph_a.equals(other.graph_a))) {
            return false;
        }
        if (this.graph_b != other.graph_b && (this.graph_b == null || !this.graph_b.equals(other.graph_b))) {
            return false;
        }
        return true;
    }
    
    
    
    
}
