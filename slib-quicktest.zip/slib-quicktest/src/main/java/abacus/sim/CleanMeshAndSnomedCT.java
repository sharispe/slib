/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;

import org.openrdf.model.URI;
import org.openrdf.model.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.sglib.algo.utils.RooterDAG;
import slib.sglib.algo.validator.dag.ValidatorDAG;
import slib.sglib.io.loader.GraphLoaderGeneric;
import slib.sglib.io.loader.slibformat.GraphLoader_SLIB;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.E;
import slib.sglib.model.graph.utils.Direction;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.tools.module.GlobalConfPattern;
import slib.tools.module.XMLConfLoaderGeneric;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;
import slib.utils.impl.SetUtils;
import slib.utils.impl.UtilDebug;

/**
 * Code used to remove cycles in both SNOMED-CT and MESH
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class CleanMeshAndSnomedCT {

    /**
     * Root the given graph and remove cycles
     *
     * @param factory the factory used to create the root URI if required (graph
     * URI + fictive_root)
     * @param graph the graph to process
     * @throws SLIB_Ex_Critic
     */
    public static void cleanGraph(DataFactory factory, G graph) throws SLIB_Ex_Critic {
        Logger logger = LoggerFactory.getLogger(CleanMeshAndSnomedCT.class.getSimpleName());

        logger.info("Preprocessing " + graph.getURI());
        ValidatorDAG validator = new ValidatorDAG();
        int countEdgeRemoved = 0;
        while (validator.containsTaxonomicDag(graph) == false) {
            countEdgeRemoved++;
            logger.info("Iteration " + countEdgeRemoved + " removing edge \t" + validator.getLastEdge());
            E cycle = validator.getLastEdge();

            graph.removeE(cycle);

        }

        if (countEdgeRemoved != 0) {
            logger.info("[important]Remove " + countEdgeRemoved + " edge(s) in order to obtain acyclic taxonomic graph");
        }

        URI root = factory.createURI(graph.getURI().stringValue() + "fictive_root");
        RooterDAG.rootUnderlyingTaxonomicDAG(graph, root);

    }

    public static void main(String[] a) throws SLIB_Exception {

        String file = "/data/test/slib.test.multisim.snomed-ct.mesh.xml";

        DataFactory factory = DataFactoryMemory.getSingleton();

        GraphLoaderGeneric.load(new XMLConfLoaderGeneric(file).getGraphConfs());

        GlobalConfPattern conf = GlobalConfPattern.getInstance();

        String uriMeshString = conf.getValue("URI_MESH");
        URI gURI_mesh = factory.createURI(uriMeshString);
        G mesh = factory.getGraph(gURI_mesh);

        cleanGraph(factory, mesh);

        GraphLoader_SLIB slibGraphManager = new GraphLoader_SLIB();
        slibGraphManager.flush(mesh, "/data/mesh/mesh_DAG.txt");

        UtilDebug.exit();

        String uriSnomedString = conf.getValue("URI_SNOMED-CT");
        URI gURI_snomed = factory.createURI(uriSnomedString);
        G snomed_ct = factory.getGraph(gURI_snomed);


        cleanGraph(factory, snomed_ct);

        // Save both cleaned graph using SLIB format 

        slibGraphManager.flush(snomed_ct, "/data/SnomedCT_Release_INT_20120731/snomed-ct-DAG-20120731.txt");

    }
}
