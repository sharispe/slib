/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;


import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.sglib.algo.validator.dag.ValidatorDAG;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.E;
import slib.sglib.model.graph.elements.V;
import slib.sglib.model.graph.elements.impl.VertexTyped;
import slib.sglib.model.graph.elements.type.VType;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.graph.utils.Direction;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.sml.sm.core.utils.SM_Engine;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;
import slib.utils.impl.ResultStack;
import slib.utils.impl.UtilDebug;

/**
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class TestGraph {

    public static void main(String[] a) throws SLIB_Ex_Critic, SLIB_Exception {

        Logger logger = LoggerFactory.getLogger("SnomedCT_Test");
        DataFactory factory = DataFactoryMemory.getSingleton();
        String uriMeshString = "http://biograph/snomed-ct/";
        URI gURI_snomedct = factory.createURI(uriMeshString);
        G snomedct = new GraphMemory(gURI_snomedct);

        factory.addGraph(snomedct);
        URI conceptA = factory.createURI("http://biograph/snomed-ct/A");
        URI conceptB = factory.createURI("http://biograph/snomed-ct/B");
        URI conceptC = factory.createURI("http://biograph/snomed-ct/C");
        URI conceptD = factory.createURI("http://biograph/snomed-ct/D");
        URI conceptE = factory.createURI("http://biograph/snomed-ct/E");
        URI conceptF = factory.createURI("http://biograph/snomed-ct/F");
        URI conceptG = factory.createURI("http://biograph/snomed-ct/G");
        URI conceptH = factory.createURI("http://biograph/snomed-ct/H");
        V cA = new VertexTyped(snomedct, conceptA, VType.CLASS);
        V cB = new VertexTyped(snomedct, conceptB, VType.CLASS);
        V cC = new VertexTyped(snomedct, conceptC, VType.CLASS);
        V cD = new VertexTyped(snomedct, conceptD, VType.CLASS);
        V cE = new VertexTyped(snomedct, conceptE, VType.CLASS);
        V cF = new VertexTyped(snomedct, conceptF, VType.CLASS);
        V cG = new VertexTyped(snomedct, conceptG, VType.CLASS);
        V cH = new VertexTyped(snomedct, conceptH, VType.CLASS);

        snomedct.addE(cB, cA, RDFS.SUBCLASSOF);

        snomedct.addE(cC, cB, RDFS.SUBCLASSOF);

        snomedct.addE(cD, cB, RDFS.SUBCLASSOF);
        snomedct.addE(cD, cH, RDFS.SUBCLASSOF);

        snomedct.addE(cF, cC, RDFS.SUBCLASSOF);

        snomedct.addE(cF, cD, RDFS.SUBCLASSOF);

        snomedct.addE(cE, cC, RDFS.SUBCLASSOF);

        snomedct.addE(cG, cF, RDFS.SUBCLASSOF);

        snomedct.addE(cH, cF, RDFS.SUBCLASSOF);
        SM_Engine engineSnomedct = new SM_Engine(snomedct);


        ValidatorDAG validator = new ValidatorDAG();
        
        boolean isDag = validator.isDag(snomedct, RDFS.SUBCLASSOF, Direction.OUT);
        System.out.println("ISDAG = "+isDag);
        
        E lastEdge = validator.getLastEdge();
        System.out.println("cycle: "+lastEdge);
        System.out.println("source "+lastEdge.getSource());
        System.out.println("target "+lastEdge.getTarget());
        
        UtilDebug.exit(null);

        System.out.println(conceptA);
        System.out.println(conceptB);
        System.out.println(
                "Search descendants / ancestors");

        System.out.println(
                "Ancestors focused concepts");
        Set<V> ancA = engineSnomedct.getAncestorsInc(cC);
        Set<V> ancB = engineSnomedct.getAncestorsInc(cD);

        System.out.println(
                "Ancestors C " + ancA.size());
        for (V v : ancA) {
            System.out.println("\t" + v);
        }

        System.out.println(
                "Ancestors D " + ancB.size());
        for (V v : ancB) {
            System.out.println("\t" + v);
        }
        Set<V> descMICA = engineSnomedct.getDescendantsInc(cB);

        System.out.println(
                "Descendants MICA B " + descMICA.size());
        for (V v : descMICA) {
            System.out.println("\t" + v);
        }
        ResultStack<V, Long> nbDescendantsInc = engineSnomedct.getAllNbDescendantsInc();


        UtilDebug.exit(null);


        for (V v : nbDescendantsInc.keySet()) {

            if (nbDescendantsInc.get(v) != engineSnomedct.getDescendantsInc(v).size()) {
                System.out.println("*** " + v + "\tnbDesc: " + nbDescendantsInc.get(v) + "\t" + engineSnomedct.getDescendantsInc(v).size());
            }
        }
    }
}
