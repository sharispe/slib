/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;

import edu.ucdenver.ccp.nlp.biolemmatizer.BioLemmatizer;
import edu.ucdenver.ccp.nlp.biolemmatizer.LemmataEntry;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.indexer.IndexHash;
import slib.indexer.IndexedElement;
import slib.sglib.model.graph.G;
import slib.utils.ex.SLIB_Ex_Critic;

/**
 * Class used to compute the terminological mapping between the two graphs
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class MappingComputer_MeshSnomed {

    public IndexHash indexMesh;
    public IndexHash indexSnomed;
    public G meshGraph;
    public G snomedGraph;
    Map<String, Set<Value>> hashMeshIndex;
    BioLemmatizer bioLemmatizer = new BioLemmatizer();
    Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());

    public MappingComputer_MeshSnomed(boolean lematized) throws Exception {



        logger.info("Loading MESH");
        meshGraph = DataLoader_SnomedMesh.loadMesh_FromOriginalSpec();
        indexMesh = DataLoader_SnomedMesh.loadMesh_Index(meshGraph);
        
        if (lematized) {
            reIndexMesh();
        }

        logger.info("Building HashMeshIndex");
        long collision = 0;
        hashMeshIndex = new HashMap<String, Set<Value>>();

        Set<String> collidedKeys = new HashSet<String>();

        for (Entry<Value, IndexedElement> e : indexMesh.getMapping().entrySet()) {

            for (String s : e.getValue().getDescriptions()) {

                if (hashMeshIndex.containsKey(s)) {
                    hashMeshIndex.get(s).add(e.getKey());
                    collision++;
                    collidedKeys.add(s);
                } else {
                    Set<Value> v = new HashSet<Value>();
                    v.add(e.getKey());
                    hashMeshIndex.put(s, v);
                }
            }
        }
        logger.info(collision + " collisions registred " + collidedKeys.size() + " keys implicated");
        for (String s : collidedKeys) {
            logger.info("\t" + s + "\t" + hashMeshIndex.get(s).size() + "\t" + hashMeshIndex.get(s));
        }

        logger.info("Loading SNOMED_CT");
        snomedGraph = DataLoader_SnomedMesh.loadSnomedCT_FromOriginalSpec();
        indexSnomed = DataLoader_SnomedMesh.loadSnomedCT_Index(snomedGraph);

        if (lematized) {
            reIndexSnomedCT();
        }
    }



    public List<String> lematize(String s) throws Exception {

        //logger.info(s);
        ArrayList<String> lemmatizedVersions = new ArrayList<String>();

        s = s.trim().toLowerCase();
        boolean first = true;

        for (String ss : s.split("\\s+")) {


            LemmataEntry lemmata = bioLemmatizer.lemmatizeByLexiconAndRules(ss, null);
            ArrayList<String> tmpVersions = new ArrayList<String>();
            Set<String> lemmataDone = new HashSet<String>();

            for (Map.Entry<String, String> e : lemmata.lemmasAndCategories.entrySet()) {

                if (first && !lemmataDone.contains(e.getValue())) {
                    lemmataDone.add(e.getValue());
                    tmpVersions.add(e.getValue());
                } else if (!lemmataDone.contains(e.getValue())) {
                    lemmataDone.add(e.getValue());
                    for (String lemVersion : lemmatizedVersions) {
                        tmpVersions.add(lemVersion + " " + e.getValue());
                    }
                }
            }
            first = false;
            lemmatizedVersions = tmpVersions;
        }

        lemmatizedVersions.add(s);
        return lemmatizedVersions;
    }

    private void reIndexMesh() throws Exception {
        logger.info("Computing all descriptions for Mesh (lemmatizing)");

        for (Entry<Value, IndexedElement> e : indexMesh.getMapping().entrySet()) {
            Set<String> out = new HashSet<String>();

            for (String s : e.getValue().getDescriptions()) {
                out.addAll(lematize(s));
            }
            e.getValue().addDescriptions(out);
        }
    }

    private void reIndexSnomedCT() throws Exception {

        logger.info("Computing all descriptions for Snomed_CT (lemmatizing)");

        for (Entry<Value, IndexedElement> e : indexSnomed.getMapping().entrySet()) {
            Set<String> out = new HashSet<String>();

            for (String s : e.getValue().getDescriptions()) {
                out.addAll(lematize(s));
            }
            e.getValue().addDescriptions(out);
        }
    }

    private void computeMapping(String mappingFile) throws SLIB_Ex_Critic {

        long total = indexSnomed.getMapping().entrySet().size();
        long c = 0;
        long mappings = 0;

        try {
            BufferedWriter out = new BufferedWriter(new FileWriter(mappingFile));

            for (Entry<Value, IndexedElement> e : indexSnomed.getMapping().entrySet()) {

                URI uri = (URI) e.getKey();

                c++;

                HashSet<Value> valueMapped = new HashSet<Value>();
                for (String s : e.getValue().getDescriptions()) {
                    if (hashMeshIndex.containsKey(s)) {
                        valueMapped.addAll(hashMeshIndex.get(s));
                    }
                }

                if (valueMapped.size() > 0) {
                    logger.info(c + "/" + total + " " + valueMapped.size() + " mapping(s) found for " + uri + " -> " + valueMapped);
                    mappings += valueMapped.size();

                    for (Value vmapped : valueMapped) {
                        URI vmappedURI = (URI) vmapped;
                        String map         = uri + "\t" + vmappedURI+"\t"+indexSnomed.getMapping().get(uri).getPreferredDescription()+"\t"+indexMesh.getMapping().get(vmappedURI).getPreferredDescription();
                        String map_reverse = vmappedURI + "\t" + uri+"\t"+indexMesh.getMapping().get(vmappedURI).getPreferredDescription()+"\t"+indexSnomed.getMapping().get(uri).getPreferredDescription();

                        logger.info(map);
                        logger.info(map_reverse);

                        out.write(map + "\n");
                        out.write(map_reverse + "\n");
                    }
                }
            }
            logger.info("Found " + mappings + " terminological mappings");

            out.close();

        } catch (Exception e) {//Catch exception if any
            throw new SLIB_Ex_Critic("Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {

        MappingComputer_MeshSnomed lemmatizer = new MappingComputer_MeshSnomed(true);
        lemmatizer.computeMapping(DataLoader_SnomedMesh.mappingFile);
    }
}
