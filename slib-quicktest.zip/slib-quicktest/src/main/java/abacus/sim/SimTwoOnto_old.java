/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package abacus.sim;

import fr.lgi2p.kid.quicktest.mapping.Mapping;
import fr.lgi2p.kid.quicktest.mapping.MappingsCollectionSymmetric;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.vocabulary.RDFS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import slib.sglib.algo.utils.WalkConstraintTax;
import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.loader.slibformat.GraphLoader_SLIB;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.V;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.graph.utils.Direction;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.sml.sm.core.measures.graph.pairwise.dag.node_based.Sim_pairwise_DAG_node_Jiang_Conrath_1997;
import slib.sml.sm.core.measures.graph.pairwise.dag.node_based.Sim_pairwise_DAG_node_Jiang_Conrath_1997_Norm;
import slib.sml.sm.core.measures.graph.pairwise.dag.node_based.Sim_pairwise_DAG_node_Lin_1998;
import slib.sml.sm.core.metrics.ic.utils.IC_Conf_Topo;
import slib.sml.sm.core.metrics.ic.utils.ICconf;
import slib.sml.sm.core.metrics.ic.utils.IcUtils;
import slib.sml.sm.core.utils.SMConstants;
import slib.sml.sm.core.utils.SM_Engine;
import slib.sml.sm.core.utils.SMconf;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;
import slib.utils.impl.ResultStack;
import slib.utils.impl.SetUtils;
import slib.utils.impl.Timer;
import slib.utils.impl.UtilDebug;

/**
 * First attempt to normalize the ICs
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class SimTwoOnto_old {

    Logger logger = LoggerFactory.getLogger(this.getClass());
    DataFactory factory;
    long ontoUnionSize;
    LinkedHashSet<QueryBinaryOnto> queries;
    MappingsCollectionSymmetric mappings;
    Map<URI, SM_Engine> engineCollection;
    HashMap<KEY_BEST_MAPPING, CoupleOfConcepts> bestMappingsNPMI = new HashMap<KEY_BEST_MAPPING, CoupleOfConcepts>();

    public SimTwoOnto_old(G ontoA, G ontoB, MappingsCollectionSymmetric mappings, LinkedHashSet<QueryBinaryOnto> queries) throws Exception {

        factory = DataFactoryMemory.getSingleton();
        this.mappings = mappings;
        this.queries = queries;

        engineCollection = new HashMap<URI, SM_Engine>();
        engineCollection.put(ontoA.getURI(), new SM_Engine(ontoA));
        engineCollection.put(ontoB.getURI(), new SM_Engine(ontoB));

        logger.info("Information about compared Graphs...");

        logger.info("Loading Graphs' concepts Union ");
        ontoUnionSize = SetUtils.union(ontoA.getV(), ontoB.getV()).size();
        logger.info("Union : " + ontoUnionSize);

        logger.info("Loading Graphs' concepts Intersection ");
        // correct intersection considering mapping.
        long intersection = 0;
        for (URI uri : mappings.getMappings().keySet()) {
            if (ontoA.containsVertex(uri)) {
                intersection++;
            }
        }
        ontoUnionSize -= intersection;
    }

    public void computeBestMappingsNPMI() throws SLIB_Ex_Critic, SLIB_Exception {

        for (QueryBinaryOnto query : queries) {

            logger.info(query.conceptA_Desc + "\t" + query.conceptB_Desc);

            URI uriAinOnto1 = query.getA_onto1();
            URI uriBinOnto1 = query.getB_onto1();
            URI uriAinOnto2 = query.getA_onto2();
            URI uriBinOnto2 = query.getB_onto2();

            if (uriAinOnto1 != null && uriBinOnto2 != null) {
                computeBestLCS_NPMI(uriAinOnto1, uriBinOnto2, query.getOnto1().getURI(), query.getOnto2().getURI());
            }

            if (uriBinOnto1 != null && uriAinOnto2 != null) {
                computeBestLCS_NPMI(uriAinOnto2, uriBinOnto1, query.getOnto2().getURI(), query.getOnto1().getURI());
            }

        }
    }

    private double computePairwiseSim(MEASURE_FLAG pairwiseMeasure, double icA, double icB, double IC_LCS_VA_VB) throws SLIB_Exception {

        double sim = 0;

        if (pairwiseMeasure == MEASURE_FLAG.LIN) {

            Sim_pairwise_DAG_node_Lin_1998 lin = new Sim_pairwise_DAG_node_Lin_1998();
            sim = lin.sim(icA, icB, IC_LCS_VA_VB);

        } else if (pairwiseMeasure == MEASURE_FLAG.JC) {

            Sim_pairwise_DAG_node_Jiang_Conrath_1997 jc = new Sim_pairwise_DAG_node_Jiang_Conrath_1997();
            sim = jc.sim(icA, icB, IC_LCS_VA_VB);

        } else if (pairwiseMeasure == MEASURE_FLAG.RESNIK) {

            sim = IC_LCS_VA_VB;

        }


        return sim;
    }

    private Set<V> getAncestors(URI conceptURI, G graph) {

        SM_Engine engine = engineCollection.get(graph.getURI());
        return engine.getAncestorsInc(graph.getV(conceptURI));
    }

    private Set<V> getDescendants(URI conceptURI, G graph) {

        SM_Engine engine = engineCollection.get(graph.getURI());
        return engine.getDescendantsInc(graph.getV(conceptURI));
    }

    public double computeNMPI(CoupleOfConcepts couple, double unionOntoSize) throws SLIB_Exception {

        logger.info("\tComputing NMPI");


        G gA = factory.getGraph(couple.getGraph_A());
        G gB = factory.getGraph(couple.getGraph_B());

        URI uriAncA = couple.getA();
        URI uriAncB = couple.getB();

        logger.info("\tAnc A: " + uriAncA + " [" + gA.getURI() + "]");
        logger.info("\tAnc B: " + uriAncB + " [" + gB.getURI() + "]");

        Set<V> descAncA = getDescendants(uriAncA, gA);
        Set<V> descAncB = getDescendants(uriAncB, gB);

        Set<Mapping> commonDescs = getMappingsAmongDescendants(descAncA, descAncB, couple);

        double descA_nb = descAncA.size();
        double descB_nb = descAncB.size();
        double descCommonNb = commonDescs.size();

        logger.info("\tCommon Descendants considering mapping : " + descCommonNb);
        logger.info("\tDesc Anc A " + descA_nb);
        logger.info("\tDesc Anc B " + descB_nb);
        logger.info("\tUnion Onto Size " + unionOntoSize);

        double nom = unionOntoSize * (descCommonNb / (descA_nb * descB_nb));
        double den = descCommonNb / unionOntoSize;

        if (unionOntoSize == 0) {
            throw new SLIB_Ex_Critic("Exception cannot be set to 0");
        }

        logger.info("\tNominator   : " + nom);
        logger.info("\tDenominator : " + den);

        logger.info("\tNominator   [log] : " + -Math.log(nom));
        logger.info("\tDenominator [log] : " + Math.log(den));

        double npmi = 0;

        if (descCommonNb != 0) {
            npmi = -Math.log(nom) / Math.log(den);
        } else {
            logger.info("NPMI set to 0 because no mapping found in desc(X) x desc(Y)");
        }
        logger.info("*** NPMI   " + npmi);
        return npmi;
    }

    private Set<Mapping> getMappingsAmongDescendants(Set<V> descX, Set<V> descY, CoupleOfConcepts couple) {

        logger.info("\tSearching Common Descendants for " + couple.getA() + " vs " + couple.getB());

        G gA = factory.getGraph(couple.getGraph_A());
        G gB = factory.getGraph(couple.getGraph_B());

        logger.info("\tConcept X     : " + couple.getA() + " [" + gA.getURI() + "]");
        logger.info("\tDescendants X : " + descX.size());

        logger.info("\tConcept Y     : " + couple.getB() + " [" + gB.getURI() + "]");
        logger.info("\tDescendants Y : " + descY.size());



        logger.info("\tSearch mapping between couples of Descendants");

        return getMappings(descX, descY, gB);
    }

    public static MappingsCollectionSymmetric loadMapping(String mappingFile, G graph_mesh, G graph_snomed) throws Exception {

        MappingsCollectionSymmetric mapCol = new MappingsCollectionSymmetric();


        FileInputStream fstream = new FileInputStream(mappingFile);
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;

        while ((line = br.readLine()) != null) {


            String[] data = line.trim().split("\t");

            URI uri_a = DataFactoryMemory.getSingleton().createURI(data[0]);
            URI uri_b = DataFactoryMemory.getSingleton().createURI(data[1]);

            G g_a = null;
            G g_b = null;

            if (graph_mesh.containsVertex(uri_a)) {
                g_a = graph_mesh;
            } else if (graph_snomed.containsVertex(uri_a)) {
                g_a = graph_snomed;
            }

            if (graph_mesh.containsVertex(uri_b)) {
                g_b = graph_mesh;
            } else if (graph_snomed.containsVertex(uri_b)) {
                g_b = graph_snomed;
            }

            if (g_a == null) {
                throw new SLIB_Ex_Critic("Cannot locate graph vertex for URI " + uri_a + "\n" + line);
            }
            if (g_b == null) {
                throw new SLIB_Ex_Critic("Cannot locate graph vertex for URI " + uri_b + "\n" + line);
            }

            if (g_a == g_b) {
                throw new SLIB_Ex_Critic("Intra mapping not allowed in graph " + g_a.getURI() + "\n" + line);
            }

            Mapping map = new Mapping(uri_a, uri_b, g_a.getURI(), g_b.getURI());
            mapCol.addMapping(map);


        }

        in.close();

        return mapCol;
    }

    private double computeSimOneOnto(MEASURE_FLAG pairwiseMeasure, ICconf icConf, URI uriA, URI uriB, G onto) throws SLIB_Ex_Critic {


        V vA = onto.getV(uriA);
        V vB = onto.getV(uriB);

        if (vA == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriA + " in graph " + onto.getURI());
        }
        if (vB == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriB + " in graph " + onto.getURI());
        }

        SM_Engine engine = engineCollection.get(onto.getURI());

        SMconf pairwiseConf;

        if (pairwiseMeasure == MEASURE_FLAG.LIN) {
            pairwiseConf = new SMconf("Lin_" + icConf.id, SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_LIN_1998, icConf);
        } else if (pairwiseMeasure == MEASURE_FLAG.JC) {
            pairwiseConf = new SMconf("JC_" + icConf.id, SMConstants.FLAG_DIST_PAIRWISE_DAG_NODE_JIANG_CONRATH_1997, icConf);
        } else if (pairwiseMeasure == MEASURE_FLAG.RESNIK) {
            pairwiseConf = new SMconf("Resnik_" + icConf.id, SMConstants.FLAG_SIM_PAIRWISE_DAG_NODE_RESNIK_1995, icConf);
        } else {
            throw new SLIB_Ex_Critic(" Measure " + pairwiseMeasure + " not supported in this context");
        }

        return engine.computePairwiseSim(pairwiseConf, vA, vB);

    }

    private CoupleOfConcepts computeBestLCS_NPMI(URI uriA_Onto1, URI uriB_onto2, URI uriOnto1, URI uriOnto2) throws SLIB_Ex_Critic, SLIB_Exception {

        CoupleOfConcepts coupleLCS = null;

        if (uriOnto1.equals(uriOnto2)) {
            throw new SLIB_Ex_Critic("Error compared concepts are expressed in the same ontology");
        }


        logger.info("Retrieving best mapping considering NPMI");

        G onto1 = factory.getGraph(uriOnto1);
        G onto2 = factory.getGraph(uriOnto2);

        V vA = onto1.getV(uriA_Onto1);
        V vB = onto2.getV(uriB_onto2);

        if (vA == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriA_Onto1 + " in graph " + onto1.getURI());
        }
        if (vB == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriB_onto2 + " in graph " + onto2.getURI());
        }

        KEY_BEST_MAPPING keyC1_C2 = new KEY_BEST_MAPPING(uriA_Onto1, uriB_onto2);
        KEY_BEST_MAPPING keyC2_C1 = new KEY_BEST_MAPPING(uriB_onto2, uriA_Onto1);

        if (bestMappingsNPMI.containsKey(keyC1_C2)) {
            coupleLCS = bestMappingsNPMI.get(keyC1_C2);

        } else {
            logger.info("Expressed in different ontologies");

            logger.info("Computing A & B ancestors");
            Set<V> ancestors_A = getAncestors(uriA_Onto1, onto1);
            Set<V> ancestors_B = getAncestors(uriB_onto2, onto2);


            logger.info("Search Best NPMI Comparison, to do : " + ((ancestors_A.size() * ancestors_B.size())));

            logger.info("Computing common Ancestors NPMIs");


            double bestNPMI = -Double.MAX_VALUE;

            long totalCount = ancestors_A.size() * ancestors_B.size();
            long done = 0;

            logger.info("Search space contains " + totalCount + " couples ");

            for (V anc_A : ancestors_A) {

                for (V anc_B : ancestors_B) {

                    done++;
                    logger.info("--------------------------------------");
                    logger.info("Processing " + done + "/" + totalCount);
                    logger.info("--------------------------------------");

                    CoupleOfConcepts couple = new CoupleOfConcepts((URI) anc_A.getValue(), (URI) anc_B.getValue(), onto1.getURI(), onto2.getURI());

                    double npmi = computeNMPI(couple, ontoUnionSize);

                    if (npmi > bestNPMI) {
                        bestNPMI = npmi;
                        coupleLCS = couple;
                    }
                }
            }
            logger.info("-----------------------------------------------");
            logger.info("LCS Couple selected ");
            logger.info("[NPMI] " + bestNPMI);
            logger.info("" + coupleLCS);

            bestMappingsNPMI.put(keyC1_C2, coupleLCS);
            bestMappingsNPMI.put(keyC2_C1, coupleLCS);
        }
        return coupleLCS;
    }

    private CoupleOfConcepts getBestMappingAmongAncestors(ICconf icConf, URI uriA_Onto1, URI uriB_Onto2, G onto1, G onto2) throws SLIB_Ex_Critic, SLIB_Exception {

        V vA = onto1.getV(uriA_Onto1);
        V vB = onto2.getV(uriB_Onto2);

        if (vA == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriA_Onto1 + " in graph " + onto1.getURI());
        }
        if (vB == null) {
            throw new SLIB_Ex_Critic("Cannot locate vertex " + uriB_Onto2 + " in graph " + onto2.getURI());
        }

        if (onto1.getURI().equals(onto2.getURI())) { // SAME Ontology
            throw new SLIB_Ex_Critic("Error compared concepts are expressed in the same ontology");
        }

        logger.info("Expressed in different ontologies");

        logger.info("Computing A & B ancestors");
        Set<V> ancestors_A = getAncestors(uriA_Onto1, onto1);
        Set<V> ancestors_B = getAncestors(uriB_Onto2, onto2);

        logger.info("Search Mapping among ancestors");
        Set<Mapping> mappingAncestors = getMappings(ancestors_A, ancestors_B, onto2);
        logger.info("Found " + mappingAncestors.size() + " mapping");
        Mapping bestMapping_LCS = null;

        if (!mappingAncestors.isEmpty()) {
            logger.info("Searching Best Mapping");
            double bestMapping_LCS_IC = -Double.MAX_VALUE;

            for (Mapping m : mappingAncestors) {

                G gmA = factory.getGraph(m.getGraph_A());
                G gmB = factory.getGraph(m.getGraph_B());

                V a = gmA.getV(m.getA());
                V b = gmB.getV(m.getB());

                double ic_a = engineCollection.get(gmA.getURI()).getIC(icConf, a);
                double ic_b = engineCollection.get(gmB.getURI()).getIC(icConf, b);

                double bestIC = (ic_a > ic_b) ? ic_a : ic_b;

                if (bestIC > bestMapping_LCS_IC) {
                    bestMapping_LCS_IC = bestIC;
                    bestMapping_LCS = m;
                }
            }
            logger.info("Best Mapping among ancestors search space");
            logger.info("Mapping  : " + bestMapping_LCS);
            logger.info("IC value : " + bestMapping_LCS_IC);
        }

        return bestMapping_LCS;
    }

    private Set<Mapping> getMappings(Set<V> setA, Set<V> setB, G graphVerticesSetB) {

        logger.info("Looking for mappings");
        // for each pairs of concepts in setA * setB

        // Retrieve all mappings involving the setA (unidirectional)
        Set<Mapping> mapFromSetA = new HashSet<Mapping>();
        for (V v : setA) {
            Set<Mapping> tmp = mappings.get((URI) v.getValue());
            if (tmp != null) {
                mapFromSetA.addAll(tmp);
            }
        }

        // Convert setB to URI to boost the lookup
        Set<URI> setB_uris = new HashSet<URI>();
        for (V v : setB) {
            setB_uris.add((URI) v.getValue());
        }
        Set<Mapping> mappingsReduction = new HashSet<Mapping>();
        URI ontoVerticesSetB = graphVerticesSetB.getURI();

        /* 
         * Only the mappings established with
         * a vertex which is both part of setB
         * and graphVerticesSetB
         */

        URI mappedConcept;
        G ontoOfMappedConcept;
        for (Mapping m : mapFromSetA) {

            mappedConcept = m.getB();
            ontoOfMappedConcept = factory.getGraph(m.getGraph_B());

            if (setB_uris.contains(mappedConcept) && ontoOfMappedConcept.getURI().equals(ontoVerticesSetB)) {
                mappingsReduction.add(m);
            }
        }
        return mappingsReduction;
    }

    private static LinkedHashSet<QueryBinaryOnto> loadQueries(String queryFile, G onto1, G onto2, String prefixOnto1, String prefixOnto2) throws SLIB_Ex_Critic {

        LinkedHashSet<QueryBinaryOnto> queries = new LinkedHashSet<QueryBinaryOnto>();
        try {
            FileInputStream fstream = new FileInputStream(queryFile);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;

            int CONCEPT_A_DESC = 0;
            int CONCEPT_B_DESC = 1;

            int URIS_A_ONTO_1 = 2;
            int URIS_B_ONTO_1 = 3;

            int URIS_A_ONTO_2 = 4;
            int URIS_B_ONTO_2 = 5;

            int physician_Score = 6;
            int coders_Score = 7;
            int both_Score = 8;

            boolean isHeader = true;

            while ((line = br.readLine()) != null) {

                if (isHeader) {
                    isHeader = false;
                    continue;
                }

                line = line.trim();
                if (line.isEmpty()) {
                    continue;
                }

                String[] data = line.trim().split("\t");

                String descA = data[CONCEPT_A_DESC];
                String descB = data[CONCEPT_B_DESC];

                String urisA_ONTO1string = data[URIS_A_ONTO_1].trim();
                String urisB_ONTO1string = data[URIS_B_ONTO_1].trim();
                String urisA_ONTO2string = data[URIS_A_ONTO_2].trim();
                String urisB_ONTO2string = data[URIS_B_ONTO_2].trim();

                URI urisA_ONTO1 = null;
                URI urisB_ONTO1 = null;
                URI urisA_ONTO2 = null;
                URI urisB_ONTO2 = null;

                DataFactory factory = DataFactoryMemory.getSingleton();
                //Create and uris (dirty)

                if (!urisA_ONTO1string.isEmpty()) {
                    urisA_ONTO1 = factory.createURI(prefixOnto1 + urisA_ONTO1string);
                }
                if (!urisB_ONTO1string.isEmpty()) {
                    urisB_ONTO1 = factory.createURI(prefixOnto1 + urisB_ONTO1string);
                }
                if (!urisA_ONTO2string.isEmpty()) {
                    urisA_ONTO2 = factory.createURI(prefixOnto2 + urisA_ONTO2string);
                }
                if (!urisB_ONTO2string.isEmpty()) {
                    urisB_ONTO2 = factory.createURI(prefixOnto2 + urisB_ONTO2string);
                }

                QueryBinaryOnto query = new QueryBinaryOnto(descA, descB, onto1, onto2,
                        urisA_ONTO1, urisA_ONTO2, urisB_ONTO1, urisB_ONTO2);

                query.addProp("PHYSICIANS_AVERAGED", data[physician_Score]);
                query.addProp("CODERS_AVERAGED", data[coders_Score]);
                query.addProp("BOTH_AVERAGED", data[both_Score]);
                queries.add(query);


            }

            in.close();
        } catch (Exception e) {
            throw new SLIB_Ex_Critic(e.getMessage());
        }
        return queries;
    }

    private double computeBestIC(ICconf icConf, CoupleOfConcepts coupleLCS) throws SLIB_Exception {
        logger.info("Retrieving best IC");

        URI ancA = coupleLCS.getA();
        G graphA = factory.getGraph(coupleLCS.getGraph_A());
        V ancA_v = graphA.getV(ancA);
        SM_Engine graphA_engine = engineCollection.get(graphA.getURI());

        URI ancB = coupleLCS.getB();
        G graphB = factory.getGraph(coupleLCS.getGraph_B());
        V ancB_v = graphB.getV(ancB);
        SM_Engine graphB_engine = engineCollection.get(graphB.getURI());


        double icAnc_A = graphA_engine.getIC(icConf, ancA_v);
        double icAnc_B = graphB_engine.getIC(icConf, ancB_v);

        logger.info(ancA + " in graph " + graphA.getURI() + " : " + icAnc_A);
        logger.info(ancB + " in graph " + graphB.getURI() + " : " + icAnc_B);

        double maxIC_LCS = icAnc_A > icAnc_B ? icAnc_A : icAnc_B;
        return maxIC_LCS;
    }

    private double[] getInfoICNorm(G onto, V v) throws SLIB_Ex_Critic {

        double[] data = new double[2];
        SM_Engine engine = engineCollection.get(onto.getURI());

        double leave = engine.getAllNbReachableLeaves().get(v);
        double ancestors = engine.getAncestorsInc(v).size();

        if (engine.getLeaves().contains(v)) {
            leave -= 1;
        }

        data[0] = leave;
        data[1] = ancestors;

        return data;

    }

    private NormICs normalizeIC(ICconf icConf, URI uriA, URI uriB, G ontoA, G ontoB, CoupleOfConcepts bestLCSs_NPMI) throws SLIB_Exception {

        // Retrieve best LCS IC and associated graph

        V vA = ontoA.getV(uriA);
        V vB = ontoB.getV(uriB);

        double icA = engineCollection.get(ontoA.getURI()).getIC(icConf, vA);
        double icB = engineCollection.get(ontoB.getURI()).getIC(icConf, vB);



        URI ancX = bestLCSs_NPMI.getA();
        G graphX = factory.getGraph(bestLCSs_NPMI.getGraph_A());
        V ancX_v = graphX.getV(ancX);
        SM_Engine graphX_engine = engineCollection.get(graphX.getURI());

        URI ancY = bestLCSs_NPMI.getB();
        G graphY = factory.getGraph(bestLCSs_NPMI.getGraph_B());
        V ancY_v = graphY.getV(ancY);
        SM_Engine graphY_engine = engineCollection.get(graphY.getURI());


        double icAnc_X = graphX_engine.getIC(icConf, ancX_v);
        double icAnc_Y = graphY_engine.getIC(icConf, ancY_v);

        logger.info("IC A " + icA);
        logger.info("IC B " + icB);
        logger.info("ANC X "+ancX + " in graph " + graphX.getURI() + " : " + icAnc_X);
        logger.info("ANC Y "+ancY + " in graph " + graphY.getURI() + " : " + icAnc_Y);

        double bestIC_LCS, rejectedIC_LCS;
        G graphBestIC_LCS;

        double icA_norm, icB_norm;

        if (icAnc_X > icAnc_Y) {
            bestIC_LCS = icAnc_X;
            rejectedIC_LCS = icAnc_Y;
            graphBestIC_LCS = graphX;
            logger.info("Best IC LCS selected from " + graphBestIC_LCS.getURI());
        } else {
            bestIC_LCS = icAnc_Y;
            rejectedIC_LCS = icAnc_X;
            graphBestIC_LCS = graphY;
            logger.info("Best IC LCS selected from " + graphBestIC_LCS.getURI());
        }


        // IC of the node from which the bestLCSIC 
        // was retrieve doesn't require to be modified
        if (ontoA.getURI().equals(graphBestIC_LCS.getURI())) {

            icA_norm = icA; // do not normalize

            if (rejectedIC_LCS == 0) {
                icB_norm = icB;
                bestIC_LCS = 0;
                icA_norm = 0;

            } else {
                if (icB == rejectedIC_LCS) { // to avoid error due to round
                    icB_norm = bestIC_LCS;
                } else {
                    icB_norm = icB * bestIC_LCS / rejectedIC_LCS;
                }
            }
            logger.info("Normalize " + uriB + " IC " + icB + " -> " + icB_norm);
        } else {
            icB_norm = icB; // do not normalize
            if (rejectedIC_LCS == 0) {
                icA_norm = 0;
                bestIC_LCS = 0;
                icB_norm = 0;
            } else {
                if (icA == rejectedIC_LCS) { // to avoid error due to round
                    icA_norm = bestIC_LCS;
                } else {
                    icA_norm = icA * bestIC_LCS / rejectedIC_LCS;
                }
            }
            logger.info("Normalize " + uriA + " IC " + icA + " -> " + icA_norm);
        }
        return new NormICs(icA_norm, icB_norm, bestIC_LCS);
    }

    private void flushBestMappingsNPMI(String bestMappingsNMPI_file) throws Exception {

        logger.info("Flushing best mapping NPMI");

        FileWriter fstream = new FileWriter(bestMappingsNMPI_file);
        BufferedWriter out = new BufferedWriter(fstream);

        out.write("URI_A\tURI_B\tBEST_MAPPING_A\tBEST_MAPPING_B\tGRAPH_BEST_MAPPING_A\tGRAPH_BEST_MAPPING_B\n");

        for (Entry<KEY_BEST_MAPPING, CoupleOfConcepts> e : bestMappingsNPMI.entrySet()) {
            KEY_BEST_MAPPING key = e.getKey();
            CoupleOfConcepts bestMapping = e.getValue();
            String outs = key.uA.stringValue() + "\t" + key.uB.stringValue() + "\t" + bestMapping.getA() + "\t" + bestMapping.getB() + "\t" + bestMapping.getGraph_A().stringValue() + "\t" + bestMapping.getGraph_B().stringValue() + "\n";
            String outs2 = key.uB.stringValue() + "\t" + key.uA.stringValue() + "\t" + bestMapping.getA() + "\t" + bestMapping.getB() + "\t" + bestMapping.getGraph_A().stringValue() + "\t" + bestMapping.getGraph_B().stringValue() + "\n";
            out.write(outs);
            out.write(outs2);

        }
        out.close();

    }

    private void loadBestMappingsNPMI(String bestMappingsNMPI_file) throws Exception {

        bestMappingsNPMI = new HashMap<KEY_BEST_MAPPING, CoupleOfConcepts>();

        FileInputStream fstream = new FileInputStream(bestMappingsNMPI_file);
        DataInputStream in = new DataInputStream(fstream);
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;

        int URI_A = 0;
        int URI_B = 1;

        int URI_BEST_MAPPING_A = 2;
        int URI_BEST_MAPPING_B = 3;

        int URI_GRAPH_BEST_MAPPING_A = 4;
        int URI_GRAPH_BEST_MAPPING_B = 5;

        boolean isHeader = true;

        while ((line = br.readLine()) != null) {
            if (isHeader) {
                isHeader = false;
                continue;
            }
            line = line.trim();
            String[] data = line.split("\t");

            URI uriA = factory.createURI(data[URI_A]);
            URI uriB = factory.createURI(data[URI_B]);

            URI uriBestMappingA = factory.createURI(data[URI_BEST_MAPPING_A]);
            URI uriBestMappingB = factory.createURI(data[URI_BEST_MAPPING_B]);

            URI uriGraphBestMappingA = factory.createURI(data[URI_GRAPH_BEST_MAPPING_A]);
            URI uriGraphBestMappingB = factory.createURI(data[URI_GRAPH_BEST_MAPPING_B]);

            KEY_BEST_MAPPING keyAB = new KEY_BEST_MAPPING(uriA, uriB);
            KEY_BEST_MAPPING keyBA = new KEY_BEST_MAPPING(uriB, uriA);

            CoupleOfConcepts c = new CoupleOfConcepts(uriBestMappingA, uriBestMappingB, uriGraphBestMappingA, uriGraphBestMappingB);

            bestMappingsNPMI.put(keyAB, c);
            bestMappingsNPMI.put(keyBA, c);

        }
        br.close();
    }

    private double computeSimMultiOnto(MEASURE_FLAG pairwiseMeasure, ICconf icConf, URI uriA_Onto1, URI uriB_Onto2, G onto1, G onto2, CoupleOfConcepts bestMappingAncestors) throws SLIB_Exception {

        NormICs icsNorm = normalizeIC(icConf, uriA_Onto1, uriB_Onto2, onto1, onto2, bestMappingAncestors);
        double sim = computePairwiseSim(pairwiseMeasure, icsNorm.icA, icsNorm.icB, icsNorm.icLCS);
        
        logger.info("Sim "+sim);

        return sim;
    }

    private void plotICsCorrepondance(ICconf icConf, G ontoA, G ontoB) throws SLIB_Ex_Critic {

        SM_Engine ontoAengine = engineCollection.get(ontoA.getURI());
        SM_Engine ontoBengine = engineCollection.get(ontoB.getURI());

        ResultStack<V, Double> icOntoA = ontoAengine.computeIC(icConf);
        ResultStack<V, Double> icOntoB = ontoBengine.computeIC(icConf);

        System.out.println(ontoA + "\t" + ontoB);

        for (Set<Mapping> mSet : mappings.getMappings().values()) {

            for (Mapping m : mSet) {

                V vA = ontoA.getV(m.getA());
                V vB = ontoB.getV(m.getB());

                if (vA == null || vB == null) {
                    continue;
                }

                double icA = icOntoA.get(vA);
                double icB = icOntoB.get(vB);

                System.out.println(m.getA() + "\t" + m.getB() + "\t" + icA + "\t" + icB);

            }

        }


    }

    private double normalizeLeastSquare(double ic, G graph) {
        double normIC = 0;

        if (graph.getURI().stringValue().equals("http://biograph/mesh/")) {
            normIC = 0.7344053 * ic + 2.177152;
        } else if (graph.getURI().stringValue().equals("http://biograph/snomed-ct/")) {
            normIC = 0.3585253 * ic + 2.282165;
        }

        return normIC;
    }

    private enum MEASURE_FLAG {

        RESNIK,
        LIN,
        JC
    }

    private class NormICs {

        public double icA;
        public double icB;
        public double icLCS;

        public NormICs(double icA, double icB, double icLCS) {
            this.icA = icA;
            this.icB = icB;
            this.icLCS = icLCS;
        }
    }

    public void execute(MEASURE_FLAG pairwiseMeasure, ICconf icConf, String outputFile_Results) throws SLIB_Exception, Exception {



        logger.info("Retrieving ICs considering " + icConf.className);

        for (SM_Engine engine : engineCollection.values()) {
            engine.computeIC(icConf);
        }

        String outputFile_Log = outputFile_Results + ".log";

        BufferedWriter outFileLog = new BufferedWriter(new FileWriter(outputFile_Log));
        BufferedWriter outFileResults = new BufferedWriter(new FileWriter(outputFile_Results));

        String header = "Term_1\tTerm_2\tPhysicians_Averaged\tCoders_Averaged\tBoth_Averaged\tSim_MESH\tSim_SNOMEDCT\tSIM_MULTI_ANC_MAPPING\tSIM_MULTI_NPMI\n";
        outFileResults.write(header);

        Timer globalTimer = new Timer();

        globalTimer.start();
        int skippedComparison = 0;

        for (QueryBinaryOnto query : queries) {

            logger.info("#############################################################################");
            logger.info(" " + query.getConceptA_Desc() + " / " + query.getConceptB_Desc());
            logger.info("#############################################################################");

            outFileLog.write("\n>" + query.getConceptA_Desc() + "\t" + query.getConceptB_Desc() + "\n");

            String summarize = query.getConceptA_Desc() + "\t" + query.getConceptB_Desc() + "\t" + query.getProp("PHYSICIANS_AVERAGED") + "\t" + query.getProp("CODERS_AVERAGED") + "\t" + query.getProp("BOTH_AVERAGED");

            URI uriA_Onto1 = query.getA_onto1();
            URI uriA_Onto2 = query.getA_onto2();

            URI uriB_Onto1 = query.getB_onto1();
            URI uriB_Onto2 = query.getB_onto2();

            Double simMonoOnto1 = null;
            Double simMonoOnto2 = null;
            Double simMultiAncMappings = null;
            Double simMultiNPMIMappings = null;

            G onto1 = query.getOnto1();
            G onto2 = query.getOnto2();

            if (uriA_Onto1 != null && uriB_Onto1 != null) {

                logger.info("-----------------------------------------------------------------------------------");
                logger.info("[MONO] ONTO: " + onto1.getURI());
                logger.info("-----------------------------------------------------------------------------------");

                simMonoOnto1 = computeSimOneOnto(pairwiseMeasure, icConf, uriA_Onto1, uriB_Onto1, onto1);

                logger.info(uriA_Onto1 + "\t" + uriB_Onto1 + "\t" + simMonoOnto1);
                logger.info("#############################################################################");
            }

            if (uriA_Onto2 != null && uriB_Onto2 != null) {


                logger.info("-----------------------------------------------------------------------------------");
                logger.info("[MONO] ONTO: " + onto2.getURI());
                logger.info("-----------------------------------------------------------------------------------");

                simMonoOnto2 = computeSimOneOnto(pairwiseMeasure, icConf, uriA_Onto2, uriB_Onto2, onto2);

                logger.info(uriA_Onto2 + "\t" + uriB_Onto2 + "\t" + simMonoOnto2 + "/ best " + simMonoOnto2);
                logger.info("#############################################################################");
            }

            if (uriA_Onto1 != null && uriB_Onto2 != null) {


                logger.info("-----------------------------------------------------------------------------------");
                logger.info("[MULTI] A in " + onto1.getURI() + " / B in " + onto2.getURI() + " ");
                logger.info("-----------------------------------------------------------------------------------");

                KEY_BEST_MAPPING keyC1_C2 = new KEY_BEST_MAPPING(uriA_Onto1, uriB_Onto2);
                CoupleOfConcepts bestMapping_NPMI = bestMappingsNPMI.get(keyC1_C2);

                if (bestMapping_NPMI == null) {
                    throw new SLIB_Ex_Critic("Please compute or load best mapping considering NPMI Cannot find best mapping for " + uriA_Onto1 + "\t" + uriB_Onto2);
                }

                double simMultiNPMI = computeSimMultiOnto(pairwiseMeasure, icConf, uriA_Onto1, uriB_Onto2, onto1, onto2, bestMapping_NPMI);


                if (simMultiNPMIMappings == null || simMultiNPMI > simMultiNPMIMappings) {
                    simMultiNPMIMappings = simMultiNPMI;
                }

                CoupleOfConcepts bestMapping_Anc = getBestMappingAmongAncestors(icConf, uriA_Onto1, uriB_Onto2, onto1, onto2);
                double simBestMappingAnc = 0;

                if (bestMapping_Anc != null) {

                    simBestMappingAnc = computeSimMultiOnto(pairwiseMeasure, icConf, uriA_Onto1, uriB_Onto2, onto1, onto2, bestMapping_Anc);
                }

                if (simMultiAncMappings == null || simBestMappingAnc > simMultiAncMappings) {
                    simMultiAncMappings = simBestMappingAnc;
                }

                outFileLog.write("\t\t\t[MAPPING_ANCESTORS]\t" + uriA_Onto1 + "\t" + uriB_Onto2 + "\t" + simBestMappingAnc + "\n");
                outFileLog.write("\t\t\t[NPMI]\t" + uriA_Onto1 + "\t" + uriB_Onto2 + "\t" + simMultiNPMI + "\n");
                logger.info("#############################################################################");
            }

            if (uriA_Onto2 != null && uriB_Onto1 != null) {

                logger.info("-----------------------------------------------------------------------------------");
                logger.info("[MULTI] A in " + onto2.getURI() + " / B in " + onto1.getURI() + " ");
                logger.info("-----------------------------------------------------------------------------------");

                KEY_BEST_MAPPING keyC1_C2 = new KEY_BEST_MAPPING(uriA_Onto2, uriB_Onto1);
                CoupleOfConcepts bestMapping_NPMI = bestMappingsNPMI.get(keyC1_C2);

                if (bestMapping_NPMI == null) {
                    throw new SLIB_Ex_Critic("Please compute or load best mapping considering NPMI Cannot find best mapping for " + uriA_Onto2 + "\t" + uriB_Onto1);
                }

                double simMultiNPMI = computeSimMultiOnto(pairwiseMeasure, icConf, uriA_Onto2, uriB_Onto1, onto2, onto1, bestMapping_NPMI);


                if (simMultiNPMIMappings == null || simMultiNPMI > simMultiNPMIMappings) {
                    simMultiNPMIMappings = simMultiNPMI;
                }

                CoupleOfConcepts bestMapping_Anc = getBestMappingAmongAncestors(icConf, uriA_Onto2, uriB_Onto1, onto2, onto1);
                double simBestMappingAnc = 0;

                if (bestMapping_Anc != null) {

                    simBestMappingAnc = computeSimMultiOnto(pairwiseMeasure, icConf, uriA_Onto2, uriB_Onto1, onto2, onto1, bestMapping_Anc);
                }

                if (simMultiAncMappings == null || simBestMappingAnc > simMultiAncMappings) {
                    simMultiAncMappings = simBestMappingAnc;
                }

                outFileLog.write("\t\t\t[MAPPING_ANCESTORS]\t" + uriA_Onto2 + "\t" + uriB_Onto1 + "\t" + simBestMappingAnc + "\n");
                outFileLog.write("\t\t\t[NPMI]\t" + uriA_Onto2 + "\t" + uriB_Onto1 + "\t" + simMultiNPMI + "\n");
                logger.info("#############################################################################");
            }


            if (simMonoOnto1 != null && simMonoOnto2 != null && simMultiAncMappings != null && simMultiNPMIMappings != null) {
                outFileResults.write(summarize + "\t" + simMonoOnto1 + "\t" + simMonoOnto2 + "\t" + simMultiAncMappings + "\t" + simMultiNPMIMappings + "\n");
            }
            logger.info(
                    "--------------------------------------------------------------------------------");
            logger.info(" " + query.getConceptA_Desc() + " / " + query.getConceptB_Desc());

            logger.info("#############################################################################");
            logger.info("#############################################################################");
        }

        outFileLog.close();

        outFileResults.close();

        logger.info(
                "Global Timer (without KB loading)");
        globalTimer.elapsedTime();

        logger.info(
                "Skipped comparison " + skippedComparison);


    }

    public void logInformation(MEASURE_FLAG pairwiseMeasure, ICconf icConf, String logfile) throws SLIB_Exception, Exception {


        for (SM_Engine engine : engineCollection.values()) {
            engine.computeIC(icConf);
        }




        FileWriter fstream = new FileWriter(logfile);
        BufferedWriter logInfo = new BufferedWriter(fstream);

        String sep = "--------------------------------------------";


        for (QueryBinaryOnto query : queries) {

            logger.info("#############################################################################");
            logger.info(" " + query.getConceptA_Desc() + " / " + query.getConceptB_Desc());
            logger.info("#############################################################################");


            URI uriA_Onto1 = query.getA_onto1();
            URI uriB_Onto1 = query.getB_onto1();

            logInfo.write("\n" + sep + "\n" + query.getConceptA_Desc() + "\t" + query.getConceptB_Desc() + "\n" + sep + "\n");


            Double simMonoOnto1 = null;

            G onto1 = query.getOnto1();

            if (uriA_Onto1 != null && uriB_Onto1 != null) {

                logger.info("-----------------------------------------------------------------------------------");
                logger.info("[MONO] ONTO: " + onto1.getURI());
                logger.info("-----------------------------------------------------------------------------------");

                logInfo.write(
                        "\t" + sep + "\n"
                        + "\tCONTEXT: c1 in " + query.onto1.getURI() + "\t c2 in" + query.onto1.getURI()
                        + "\n\t" + sep + "\n");


                simMonoOnto1 = computeSimOneOnto(pairwiseMeasure, icConf, uriA_Onto1, uriB_Onto1, onto1);

                logInfo.write("\t\t\t" + uriA_Onto1.getLocalName() + "\t" + uriB_Onto1.getLocalName() + "\n");
                logInfo.write("\t\t\t\t c1: " + query.conceptA_Desc + " [" + uriA_Onto1.getLocalName() + "]\n");



                SM_Engine engine = engineCollection.get(onto1.getURI());

                V c1 = onto1.getV(uriA_Onto1);
                Set<V> ancestorsC1 = engine.getAncestorsInc(c1);

                logInfo.write("\t\t\t\t\t ancestors : " + ancestorsC1.size() + "\n");
                for (V anc : ancestorsC1) {
                    logInfo.write("\t\t\t\t\t\t - " + ((URI) anc.getValue()).getLocalName() + "\n");
                }

                Set<V> leavesC1 = engine.getDescGetter().getTerminalVertices().get(c1);

                logInfo.write("\t\t\t\t\t leaves : " + leavesC1.size() + "\n");
                for (V leaf : leavesC1) {
                    logInfo.write("\t\t\t\t\t\t - " + ((URI) leaf.getValue()).getLocalName() + "\n");
                }



                logInfo.write("\t\t\t\t c2: " + query.conceptB_Desc + " [" + uriB_Onto1.getLocalName() + "]\n");
                V c2 = onto1.getV(uriB_Onto1);
                Set<V> ancestorsC2 = engine.getAncestorsInc(c2);
                logInfo.write("\t\t\t\t\t ancestors : " + ancestorsC2.size() + "\n");
                for (V anc : ancestorsC2) {
                    logInfo.write("\t\t\t\t\t\t - : " + ((URI) anc.getValue()).getLocalName() + "\n");
                }

                Set<V> leavesC2 = engine.getDescGetter().getTerminalVertices().get(c2);

                logInfo.write("\t\t\t\t\t leaves : " + leavesC2.size() + "\n");
                for (V leaf : leavesC2) {
                    logInfo.write("\t\t\t\t\t\t - : " + ((URI) leaf.getValue()).getLocalName() + "\n");
                }



                long nbLeaves = 0;

                for (V v : onto1.getV()) {
                    if (onto1.getE(v, new WalkConstraintTax(RDFS.SUBCLASSOF, Direction.IN)).isEmpty()) {
                        nbLeaves++;
                    }
                }
                logInfo.write("\t\t\t\t\tNumber of concepts: " + onto1.getV().size() + "\n");
                logInfo.write("\t\t\t\t\tNumber of leaves  : " + nbLeaves + "\n");

                double icC1 = engine.getIC(icConf, c1);
                double icC2 = engine.getIC(icConf, c2);
                logInfo.write("\t\t\t\t\tIC      : " + icConf.className + "\n");
                logInfo.write("\t\t\t\t\tIC c1   : " + icC1 + "\n");
                logInfo.write("\t\t\t\t\tIC c2   : " + icC2 + "\n");

                V mica = IcUtils.searchMICA(engine.getAncestorsInc(c1), engine.getAncestorsInc(c2), engine.getIC_results(icConf));
                logInfo.write("\t\t\t\t\tMICA    : " + ((URI) mica.getValue()).getLocalName() + "\n");
                logInfo.write("\t\t\t\t\tMICA IC : " + engine.getIC(icConf, mica) + "\n");

                logInfo.write("\t\t\t\t\tPairwise measure : " + pairwiseMeasure + "\n");
                logInfo.write("\t\t\t\t\tSim/Distance       : " + simMonoOnto1 + "\n");

                logger.info(uriA_Onto1 + "\t" + uriB_Onto1 + "\t" + simMonoOnto1);
                logger.info("#############################################################################");

            }

        }
        logInfo.close();
    }

    private class KEY_BEST_MAPPING {

        public URI uA;
        public URI uB;

        public KEY_BEST_MAPPING(URI uA, URI uB) {
            this.uA = uA;
            this.uB = uB;
        }

        @Override
        public int hashCode() {
            int hash = 3;
            hash = 67 * hash + (this.uA != null ? this.uA.hashCode() : 0);
            hash = 67 * hash + (this.uB != null ? this.uB.hashCode() : 0);
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final KEY_BEST_MAPPING other = (KEY_BEST_MAPPING) obj;
            if (this.uA != other.uA && (this.uA == null || !this.uA.equals(other.uA))) {
                return false;
            }
            if (this.uB != other.uB && (this.uB == null || !this.uB.equals(other.uB))) {
                return false;
            }
            return true;
        }
    }

    public static void main(String[] a) throws SLIB_Exception, Exception {

        Logger logger = LoggerFactory.getLogger(SimTwoOnto.class);

        String meshFile = "/data/mesh/mesh_DAG.txt";
        String snomedctFile = "/data/SnomedCT_Release_INT_20120731/snomed-ct-DAG-20120731.txt";
        String mappingFile = "/home/seb/docs/thesis/experiments/snomed-ct_mesh/snomed_mesh_mapping_v2.csv";
        String queryFile = "/home/seb/docs/thesis/experiments/snomed-ct_mesh/benchmarks/pedersen_2007/pedersen_2007_reduce.csv";
        String bestMappingsNMPI_file = "/home/seb/docs/thesis/experiments/snomed-ct_mesh/bestMappingsNPMI.csv";
        DataFactory factory = DataFactoryMemory.getSingleton();

        URI gURI_mesh = factory.createURI("http://biograph/mesh/");
        URI gURI_snomed = factory.createURI("http://biograph/snomed-ct/");
        G onto1 = new GraphMemory(gURI_mesh);
        G onto2 = new GraphMemory(gURI_snomed);

        factory.addGraph(onto1);
        factory.addGraph(onto2);

        GraphLoader_SLIB slibGraphLoader = new GraphLoader_SLIB();

        slibGraphLoader.populate(
                new GDataConf(GFormat.SLIB, meshFile), onto1);
        slibGraphLoader.populate(
                new GDataConf(GFormat.SLIB, snomedctFile), onto2);

        CleanMeshAndSnomedCT.cleanGraph(factory, onto1);
        CleanMeshAndSnomedCT.cleanGraph(factory, onto2);


        logger.info("Loading Mapping");

        MappingsCollectionSymmetric mappings = SimTwoOnto_old.loadMapping(mappingFile, onto1, onto2);
        // Loading queries --------------------------------------------------------
        LinkedHashSet<QueryBinaryOnto> queries = SimTwoOnto_old.loadQueries(queryFile, onto1, onto2, onto1.getURI().stringValue(), onto2.getURI().stringValue());
        SimTwoOnto_old abacus = new SimTwoOnto_old(onto1, onto2, mappings, queries);
//        abacus.computeBestMappingsNPMI();
//        abacus.flushBestMappingsNPMI(bestMappingsNMPI_file);

        //UtilDebug.exit();

        abacus.loadBestMappingsNPMI(bestMappingsNMPI_file);




        ICconf icSanchez = new IC_Conf_Topo("Sanchez", SMConstants.FLAG_ICI_SANCHEZ_2011_a);
        ICconf icSeco = new IC_Conf_Topo("Seco", SMConstants.FLAG_ICI_SECO_2004);

//        abacus.plotICsCorrepondance(icSanchez, onto1, onto2);        
//        UtilDebug.exit();

//        ICconf[] icConfs = {icSanchez, icSeco};
//        MEASURE_FLAG[] mflags = {MEASURE_FLAG.LIN, MEASURE_FLAG.RESNIK, MEASURE_FLAG.JC};

        ICconf[] icConfs = {icSanchez};
        MEASURE_FLAG[] mflags = {MEASURE_FLAG.LIN};

        for (ICconf icConf : icConfs) {

            for (MEASURE_FLAG pairwiseMeasureFlag : mflags) {

                String outfile = "/tmp/pedersen2007_" + pairwiseMeasureFlag + "_" + icConf.id + ".csv";
                //abacus.logInformation(pairwiseMeasureFlag, icConf, outfile + ".verbose.log");

                abacus.execute(pairwiseMeasureFlag, icConf, outfile);
            }
        }
    }
}
