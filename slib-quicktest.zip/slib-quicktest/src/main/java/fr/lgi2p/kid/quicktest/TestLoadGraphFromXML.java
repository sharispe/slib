package fr.lgi2p.kid.quicktest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Map.Entry;
import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import slib.indexer.IndexHash;
import slib.indexer.IndexedElement;
import slib.indexer.mesh.Indexer_MESH_XML;
import slib.indexer.snomed_ct.IndexerSNOMEDCT_RF2;
import slib.sglib.io.loader.GraphLoaderGeneric;
import slib.sglib.model.graph.G;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.sml.sm.core.measures.string.LevenshteinSimilarity;
import slib.tools.module.GlobalConfPattern;
import slib.tools.module.XMLConfLoaderGeneric;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;

/**
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class TestLoadGraphFromXML {

    public static void main(String[] a) throws SLIB_Ex_Critic, SLIB_Exception, FileNotFoundException {

        System.out.println("Loading of configuration from XML");
        String file = "/data/test/slib.test.snomed-ct.mesh.xml";

        LevenshteinSimilarity lev = new LevenshteinSimilarity(true);

        DataFactoryMemory repo = DataFactoryMemory.getSingleton();

        GraphLoaderGeneric.load(new XMLConfLoaderGeneric(file).getGraphConfs());

        String mesh_file = GlobalConfPattern.getInstance().getValue("MESH_XML_FILE");
        String mesh_uri = GlobalConfPattern.getInstance().getValue("URI_MESH");

        String snomed_file = GlobalConfPattern.getInstance().getValue("SNOMEDT_CT_DIR") + "/sct2_Description_Full-en_INT_20120731.txt";
        String snomed_uri = GlobalConfPattern.getInstance().getValue("URI_SNOMED-CT");

        String graph_uri = GlobalConfPattern.getInstance().getValue("URI_GRAPH");

        URI gURI = repo.createURI(graph_uri);
        G g = repo.getGraph(gURI);

        System.out.println("mesh file " + mesh_file);





        Indexer_MESH_XML indexerMesh = new Indexer_MESH_XML();
        IndexHash indexMesh = indexerMesh.buildIndex(repo, mesh_file, mesh_uri);

        IndexerSNOMEDCT_RF2 indexSNOMEDCT_RF2 = new IndexerSNOMEDCT_RF2();
        IndexHash indexSnomed = indexSNOMEDCT_RF2.buildIndex(repo, snomed_file, snomed_uri,true,true);

        int it = indexMesh.getMapping().entrySet().size();
        int i = 0;
        int topMatch = 0;

        File f = new File("/home/seb/netbeans.log");
        PrintStream printStream = new PrintStream(new FileOutputStream(f));
        System.setOut(printStream);

        for (Entry<Value, IndexedElement> entry : indexMesh.getMapping().entrySet()) {

            i++;
            Set<String> targets = entry.getValue().getDescriptions();

            //System.out.println(i+"/"+it+" ["+topMatch+"]\t"+target);

            double max = 0;
            Value uri = null;
            String bestMatch = "NONE";
            String bestTarget = "None";

            for (String target : targets) {

                for (Entry<Value, IndexedElement> e : indexSnomed.getMapping().entrySet()) {

                    for (String s : e.getValue().getDescriptions()) {

                        if (Math.abs(target.length() - s.length()) > target.length() / 3) {
                            continue;
                        }

                        double sim = lev.sim(target.toLowerCase(), s.toLowerCase());
                        if (sim > max) {
                            max = sim;
                            uri = e.getKey();
                            bestMatch = s;
                            bestTarget = target;
                        }
                    }
                }
            }
            String flag = "";
            if (max == 1) {
                topMatch++;
                flag = "------------------------------------------\n";
            }
//            System.out.print(flag);
//            System.out.println("\t'" + bestMatch + "'\t" + max);
//            System.out.println("\t"+entry.getKey()+" == "+uri+ "\n");

            URI m = (URI) entry.getKey();
            URI s = (URI) uri;
            System.out.println(max + "\t" + m.getLocalName() + "\t" + s.getLocalName() + "\t" + bestTarget + "\t" + bestMatch);


        }


//        String uri_graph = "http://biograph/";
//        URI u = repo.createURI(uri_graph);
//        G g   = repo.getGraph(u);
//        
//        SM_Engine engine = new SM_Engine(g);
//        
//        URI target = repo.createURI("http://biograph/mesh/D034201");
//        
//        V v = g.getV(target);
//        
//        System.out.println("Target: "+v);
//        Set<V> ancestors = engine.getAncestors(v);
//        
//        System.out.println("Ancestors: "+ancestors);



    }
}
