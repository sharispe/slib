/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lgi2p.kid.quicktest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Set;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;
import slib.sglib.model.graph.elements.V;
import slib.utils.ex.SLIB_Exception;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class LuceneWordNetTest {

    Analyzer analyzer;
    Directory index;
    Map<String, Set<V>> wordnetIndex;
    public static String INDEXED_FIELD = "TITLE";
    int hitsPerPage = 20;

    public LuceneWordNetTest() throws CorruptIndexException, LockObtainFailedException, IOException, SLIB_Exception {

        //Load wordNet

        WordnetTest wordnet = new WordnetTest();
        wordnetIndex = wordnet.index.getIndex();

        // 0. Specify the analyzer for tokenizing text.
        //    The same analyzer should be used for indexing and searching
        analyzer = new StandardAnalyzer(Version.LUCENE_35);

        System.out.println("Building Lucene Index");
        // 1. create the index
        index = new RAMDirectory();

        IndexWriterConfig config = new IndexWriterConfig(Version.LUCENE_35, analyzer);

        IndexWriter w = new IndexWriter(index, config);

        for (Map.Entry<String, Set<V>> e : wordnet.index.getIndex().entrySet()) {
            //System.out.println(e.getKey());
            String key = e.getKey().replace("_", " ");
            Document doc = new Document();
            doc.add(new Field(INDEXED_FIELD, key, Field.Store.YES, Field.Index.ANALYZED));

            w.addDocument(doc);
        }

        w.close();


    }

    public void query(String querystr) throws IOException, ParseException {
        // the "title" arg specifies the default field to use
        // when no field is explicitly specified in the query.
        Query q = new QueryParser(Version.LUCENE_35, INDEXED_FIELD, analyzer).parse(querystr);

        // 3. search

        IndexReader reader = IndexReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopScoreDocCollector collector = TopScoreDocCollector.create(hitsPerPage, true);
        searcher.search(q, collector);
        ScoreDoc[] hits = collector.topDocs().scoreDocs;

        // 4. display results
        System.out.println("Found " + hits.length + " hits.");

        for (int i = 0; i < hits.length; ++i) {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            System.out.println((i + 1) + ". " + d.get(INDEXED_FIELD));
            for (V v : wordnetIndex.get(d.get(INDEXED_FIELD).replace(" ", "_"))) {
                System.out.println("\t\t" + v);
            }
        }

        // searcher can only be closed when there
        // is no need to access the documents any more.
        searcher.close();
    }

    public static void main(String[] args) throws Exception {

        System.out.println("Indexing...");
        LuceneWordNetTest test = new LuceneWordNetTest();

        System.out.println("Enter an empty query to stop exec");
        boolean stop = false;

        while (!stop) {

            System.out.println("--------------------------------------------");
            System.out.print("Query: ");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String q = null;
            try {
                q = br.readLine();
                if (q.isEmpty()) {
                    stop = true;
                    continue;
                }

            } catch (Exception e) {
                System.out.println("Error!" + e.getMessage());
                System.exit(1);
            }
            System.out.println("> " + q);
            test.query(q);
        }

        System.out.println("Exiting");

    }
}
