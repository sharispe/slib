package fr.lgi2p.kid.quicktest;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import org.openrdf.model.URI;
import slib.sglib.algo.extraction.rvf.RVF_TAX;
import slib.sglib.algo.reduction.dag.GraphReduction_DAG_Ranwez_2011;
import slib.sglib.algo.utils.RooterDAG;
import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.conf.GraphConf;
import slib.sglib.io.loader.GraphLoaderGeneric;
import slib.sglib.io.plotter.GraphPlotter_Graphviz;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.V;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.graph.utils.Direction;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.utils.ex.SLIB_Exception;
import slib.utils.impl.SetUtils;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class TestReduction {

    public static void ontoFocus() throws SLIB_Exception {
        DataFactoryMemory factory = DataFactoryMemory.getSingleton();

        G g = null;
        GraphConf conf = new GraphConf();
        conf.setUri(DataFactoryMemory.getSingleton().createURI("http://graph/"));
        conf.addGDataConf(new GDataConf(GFormat.OBO, "/home/seb/documents/orthomam_GO/inputs/gene_ontology_06_03_02.obo"));
        factory.loadNamespacePrefix("GO", "http://graph/go/");
        g = GraphLoaderGeneric.load(conf);

        URI root_uri = factory.createURI("http://graph/go/root");
        RooterDAG.rootUnderlyingTaxonomicDAG(g, root_uri);
        GraphReduction_DAG_Ranwez_2011 reductor = new GraphReduction_DAG_Ranwez_2011(factory, g, root_uri);

        URI uriQuery = factory.createURI("http://graph/go/2001233");
        G red = new GraphMemory(factory.createURI("http://graph_red/"));
        reductor.exec(SetUtils.buildSet(uriQuery), red);

    }

    public static void ontoFocusViolent() throws SLIB_Exception, IOException, InterruptedException {


        DataFactoryMemory factory = DataFactoryMemory.getSingleton();

        G g = null;
        GraphConf conf = new GraphConf();
        conf.setUri(DataFactoryMemory.getSingleton().createURI("http://graph/"));
        conf.addGDataConf(new GDataConf(GFormat.OBO, "/home/seb/documents/orthomam_GO/inputs/gene_ontology_06_03_02.obo"));
        factory.loadNamespacePrefix("GO", "http://graph/go/");
        g = GraphLoaderGeneric.load(conf);

        URI root_uri = factory.createURI("http://graph/go/root");
        RooterDAG.rootUnderlyingTaxonomicDAG(g, root_uri);
        GraphReduction_DAG_Ranwez_2011 reductor = new GraphReduction_DAG_Ranwez_2011(factory, g, root_uri);

        URI uriQuery = factory.createURI("http://graph/go/2001233");
        RVF_TAX rvf = new RVF_TAX(g, Direction.OUT);
        Set<V> setV = rvf.getRVClass(g.getV(uriQuery));

        Set<URI> setVuri = new HashSet<URI>();
        for (V v : setV) {
            setVuri.add((URI) v.getValue());
            System.out.println(v);
        }

        G red = new GraphMemory(factory.createURI("http://graph_red/"));
        reductor.exec(setVuri, red);


        String reduction = GraphPlotter_Graphviz.plot(red, setV, true);
        System.out.println(reduction);



        File tmp = File.createTempFile("tmp_sml", null, new File("/tmp"));

        FileWriter fstream = new FileWriter(tmp);
        BufferedWriter out = new BufferedWriter(fstream);
        out.write(reduction);
        //Close the output stream
        out.close();

        Runtime rt = Runtime.getRuntime();
        Process proc = rt.exec("cp " + tmp.getPath() + " " + tmp.getPath() + "_2");

        int exitVal = proc.waitFor();
        System.out.println("ExitValue: " + exitVal);

    }

    public static void main(String[] a) throws Exception {

        TestReduction.ontoFocusViolent();
    }
}