/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lgi2p.kid.quicktest;

import java.util.Set;
import org.openrdf.model.URI;
import slib.indexer.wordnet.IndexerWordNetBasic;
import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.loader.wordnet.GraphLoader_Wordnet;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.V;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class WordnetTest {

    IndexerWordNetBasic index;

    public WordnetTest() throws SLIB_Exception {

        DataFactory factory = DataFactoryMemory.getSingleton();
        URI guri = factory.createURI("http://graph/wordnet/");
        G g = new GraphMemory(guri);

        GraphLoader_Wordnet loader = new GraphLoader_Wordnet();

        String dataloc = "/home/seb/desktop/WordNet-3.0/dict/";
        String data_noun = dataloc + "data.noun";
        String data_verb = dataloc + "data.verb";
        String data_adj = dataloc + "data.adj";
        String data_adv = dataloc + "data.adv";

        GDataConf dataNoun = new GDataConf(GFormat.WORDNET_DATA, data_noun);
        GDataConf dataVerb = new GDataConf(GFormat.WORDNET_DATA, data_verb);
        GDataConf dataAdj  = new GDataConf(GFormat.WORDNET_DATA, data_adj);
        GDataConf dataAdv  = new GDataConf(GFormat.WORDNET_DATA, data_adv);

        loader.populate(dataNoun, g);
        loader.populate(dataVerb, g);
        loader.populate(dataAdj, g);
        loader.populate(dataAdv, g);

        dataloc = "/home/seb/desktop/WordNet-3.0/dict/";
        data_noun = dataloc + "index.noun";

        index = new IndexerWordNetBasic(factory, g, data_noun);

    }

    public void performQuery() {
        query("abatement");
        query("entity");
        query("propulsion");
    }

    private void query(String query) {
        System.out.println(query);

        Set<V> synsets = index.get(query);

        for (V v : synsets) {
            System.out.println("\t" + v);
        }

    }

    public static void main(String[] args) throws SLIB_Ex_Critic, SLIB_Exception {

        WordnetTest test = new WordnetTest();
        test.performQuery();

    }
}
