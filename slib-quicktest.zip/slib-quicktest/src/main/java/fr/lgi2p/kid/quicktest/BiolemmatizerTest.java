/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package fr.lgi2p.kid.quicktest;

import edu.ucdenver.ccp.nlp.biolemmatizer.BioLemmatizer;
import edu.ucdenver.ccp.nlp.biolemmatizer.LemmataEntry;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Map;
import slib.sml.sm.core.measures.string.LevenshteinSimilarity;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class BiolemmatizerTest {

    BioLemmatizer bioLemmatizer = new BioLemmatizer();

    public String lematize(String s) throws Exception {

        //System.out.println(s);
        String newS = "";

        for (String ss : s.split("\\s+")) {

            //System.out.println("\t" + ss);
            LemmataEntry lemmata = bioLemmatizer.lemmatizeByLexiconAndRules(ss, null);

            String lem = null;
            String lem_k = null;

            for (Map.Entry<String, String> e : lemmata.lemmasAndCategories.entrySet()) {
                //System.out.println("\t\t" + e.getKey() + " " + e.getValue());
                if (lem == null) {

                    lem = e.getValue();
                    lem_k = e.getKey();

                } else if (!lem.equals(e.getValue())) {
                    //System.out.println("\t*** Error " + lem_k + "\t" + lem + "\t" + e.getKey() + "\t" + e.getValue());
                }
            }
            if (!newS.isEmpty()) {
                newS += " ";
            }
            newS += lem;
        }
        //System.out.println("\t" + newS);

        return newS;
    }

    public static void main(String[] a) throws Exception {

        String[] toLemma = {"mice",
            "Azasteroids",
            "Feet Joints",
            "Aquaporin-1",
            "Aquaporin 1",
            "Vestibulocochlear Nerve Injuries",
            "Mice Injuries",
            "Streptodornases + streptokinases",
            "Gerstmann's syndrome"
        };

        BiolemmatizerTest t = new BiolemmatizerTest();

        String file = "/home/seb/documents/thesis/experiments/snomed-ct_mesh/mapping_snomed-ct_mesh.csv";
        int count = 0;
        int perfectMatch = 0;

        try {
            FileInputStream fstream = new FileInputStream(file);
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;

            int SIM = 0;
            int MESH_DESC = 3;
            int SNOMEDCT_DESC = 4;

            boolean normalize = true;
            LevenshteinSimilarity lev = new LevenshteinSimilarity(normalize);

            System.out.println("Lemmatize");
            
            while ((line = br.readLine()) != null) {
                

                String[] data = line.trim().split("\t");

                double sim = Double.parseDouble(data[SIM]);

                if (sim == 1 ){ //|| sim <= 0.5) {
                    continue;
                }

                String m = data[MESH_DESC];
                String s = data[SNOMEDCT_DESC];

//                System.out.println("---------------------");
//                System.out.println(m + "\n" + s);
//                System.out.println("---------------------");


                // Remove ,() and modify string to lower case
                String m_mod = m.replace(",", " ").replace("(", "").replace(")", "").toLowerCase();
                String s_mod = s.replace(",", " ").replace("(", "").replace(")", "").toLowerCase();

                String m_lem = t.lematize(m_mod);
                String s_lem = t.lematize(s_mod);

                double simscore = lev.sim(m_lem, s_lem);

                System.out.println(simscore+"\t"+m_lem+"\t"+s_lem+"\t"+"\t"+m+"\t"+s);

                if (simscore == 1) {
                    perfectMatch++;
                }

                count++;
            }

            in.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }

        System.out.println(perfectMatch + " / " + count);


    }
}
