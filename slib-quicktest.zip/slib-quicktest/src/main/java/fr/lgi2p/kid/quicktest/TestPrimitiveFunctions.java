/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package fr.lgi2p.kid.quicktest;

import fr.lgi2p.kid.quicktest.mapping.Mapping;
import fr.lgi2p.kid.quicktest.mapping.MappingsCollectionSymmetric;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Map;
import java.util.Set;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import slib.indexer.IndexHash;
import slib.indexer.mesh.Indexer_MESH_XML;
import slib.indexer.snomed_ct.IndexerSNOMEDCT_RF2;
import slib.sglib.algo.extraction.rvf.RVF_TAX;
import slib.sglib.io.loader.GraphLoaderGeneric;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.elements.E;
import slib.sglib.model.graph.elements.V;
import slib.sglib.model.graph.utils.Direction;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.sml.sm.core.measures.string.LevenshteinSimilarity;
import slib.tools.module.GlobalConfPattern;
import slib.tools.module.XMLConfLoaderGeneric;
import slib.utils.ex.SLIB_Ex_Critic;
import slib.utils.ex.SLIB_Exception;
import slib.utils.impl.SetUtils;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class TestPrimitiveFunctions {

    public static void main(String[] a) throws SLIB_Ex_Critic, SLIB_Exception, FileNotFoundException {

        System.out.println("Loading of configuration from XML");
        String file = "/data/test/slib.test.snomed-ct.mesh.xml";

        DataFactoryMemory factory = DataFactoryMemory.getSingleton();

        GraphLoaderGeneric.load(new XMLConfLoaderGeneric(file).getGraphConfs());

        String mesh_file = GlobalConfPattern.getInstance().getValue("MESH_XML_FILE");
        String mesh_uri = GlobalConfPattern.getInstance().getValue("URI_MESH");

        String snomed_file = GlobalConfPattern.getInstance().getValue("SNOMEDT_CT_DIR") + "/sct2_Description_Full-en_INT_20120731.txt";
        String snomed_uri = GlobalConfPattern.getInstance().getValue("URI_SNOMED-CT");

        String graph_uri = GlobalConfPattern.getInstance().getValue("URI_GRAPH");

        URI gURI = factory.createURI(graph_uri);
        G   g    = factory.getGraph(gURI);

        System.out.println("mesh file " + mesh_file);

        // Retrieve a concept by URI
        URI c_uri_mesh = factory.createURI( mesh_uri + "D008838" );
        URI d_uri_mesh = factory.createURI( mesh_uri + "D003199" );

        URI m1_mesh = factory.createURI( mesh_uri + "D007254" );
        URI m2_mesh = factory.createURI( mesh_uri + "D003205" );


        V m1 = g.getV( m1_mesh );
        V m2 = g.getV(m2_mesh);


        System.out.println(c_uri_mesh);

        V c = g.getV(c_uri_mesh); // retrieve the graph vertex associated to the concept
        V d = g.getV(d_uri_mesh);

        System.out.println("--> " + c);
        System.out.println("--> " + d);

        // Retrieve the edges associated to a concept
        Set<E> edgesNeighbors = g.getE(c, Direction.BOTH);

        for (E e : edgesNeighbors) {
            System.out.println("\t" + e);
        }

        RVF_TAX ancestorFinder = new RVF_TAX(g, Direction.OUT);
        Set<V> ancestors_c = ancestorFinder.getRV(c);
        Set<V> ancestors_d = ancestorFinder.getRV(d);

        System.out.println("Ancestors C ");
        for (V v : ancestors_c) {
            System.out.println("\t" + v);
        }

        System.out.println("Ancestors D ");
        for (V v : ancestors_d) {
            System.out.println("\t" + v);
        }

        System.out.println("Union");

        Set<V> union = SetUtils.union(ancestors_c, ancestors_d);

        for (V v : union) {
            System.out.println("\t" + v);
        }

        System.out.println("Intersection");

        Set<V> intersection = SetUtils.intersection(ancestors_c, ancestors_d);

        for (V v : intersection) {
            System.out.println("\t" + v);
        }
    }
}
