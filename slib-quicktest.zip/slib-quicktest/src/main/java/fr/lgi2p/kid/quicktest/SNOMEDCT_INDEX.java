/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lgi2p.kid.quicktest;

import slib.indexer.snomed_ct.IndexerSNOMEDCT_RF2;
import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.loader.bio.snomedct.GraphLoaderSnomedCT_RF2;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.repo.DataFactory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.utils.ex.SLIB_Exception;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class SNOMEDCT_INDEX {

    public static void main(String[] a) throws SLIB_Exception {

        DataFactory factory = DataFactoryMemory.getSingleton();

        String concept_file      = "/data/SnomedCT_Release_INT_20120731/RF2Release/Full/Terminology/sct2_Concept_Full_INT_20120731.txt";
        String relationship_file = "/data/SnomedCT_Release_INT_20120731/RF2Release/Full/Terminology/sct2_Relationship_Full_INT_20120731.txt";

        GDataConf conf = new GDataConf(GFormat.SNOMED_CT_RF2);
        conf.addParameter(GraphLoaderSnomedCT_RF2.ARG_CONCEPT_FILE, concept_file);
        conf.addParameter(GraphLoaderSnomedCT_RF2.ARG_RELATIONSHIP_FILE, concept_file);
        
        G g = new GraphMemory(factory.createURI("http://graph/snomed-ct/"));
        GraphLoaderSnomedCT_RF2 loader = new GraphLoaderSnomedCT_RF2();
        loader.populate(conf, g);

        String description_file = "/data/SnomedCT_Release_INT_20120731/RF2Release/Full/Terminology/sct2_Description_Full-en_INT_20120731.txt";

        IndexerSNOMEDCT_RF2 indexer = new IndexerSNOMEDCT_RF2();
        indexer.buildIndex(factory,description_file, "http://graph/snomed-ct/",true,true);
    }
}
