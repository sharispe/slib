package fr.lgi2p.kid.quicktest;

import slib.sglib.io.conf.GDataConf;
import slib.sglib.io.loader.bio.mesh.GraphLoader_MESH_XML;
import slib.sglib.io.util.GFormat;
import slib.sglib.model.graph.G;
import slib.sglib.model.graph.impl.memory.GraphMemory;
import slib.sglib.model.repo.impl.DataFactoryMemory;
import slib.utils.ex.SLIB_Exception;

/**
 * Hello world!
 *
 */
public class MeshXML {

    public static void main(String[] array) throws SLIB_Exception {

        String path = "/data/mesh/desc2013.xml";

        G g = new GraphMemory(DataFactoryMemory.getSingleton().createURI("http://graph/mesh/"));

        GDataConf conf = new GDataConf(GFormat.MESH_XML, path);
        GraphLoader_MESH_XML loader = new GraphLoader_MESH_XML();

        loader.populate(conf, g);

    }
}
