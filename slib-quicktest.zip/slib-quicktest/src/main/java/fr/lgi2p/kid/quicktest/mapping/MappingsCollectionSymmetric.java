/*
 * 
 * Copyright or © or Copr. Ecole des Mines d'Alès (2012) 
 * LGI2P research center
 * This software is governed by the CeCILL  license under French law and
 * abiding by the rules of distribution of free software.  You can  use, 
 * modify and/ or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info". 
 * 
 * As a counterpart to the access to the source code and  rights to copy,
 * modify and redistribute granted by the license, users are provided only
 * with a limited warranty  and the software's author,  the holder of the
 * economic rights,  and the successive licensors  have only  limited
 * liability. 
 * 
 * In this respect, the user's attention is drawn to the risks associated
 * with loading,  using,  modifying and/or developing or reproducing the
 * software by the user in light of its specific status of free software,
 * that may mean  that it is complicated to manipulate,  and  that  also
 * therefore means  that it is reserved for developers  and  experienced
 * professionals having in-depth computer knowledge. Users are therefore
 * encouraged to load and test the software's suitability as regards their
 * requirements in conditions enabling the security of their systems and/or 
 * data to be ensured and,  more generally, to use and operate it in the 
 * same conditions as regards security. 
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */
package fr.lgi2p.kid.quicktest.mapping;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.openrdf.model.URI;
import slib.sglib.model.graph.G;

/**
 * Basic representation of a collection of symmetric mapping collection By
 * symmetric we consider that every mapping A to B is also stored as a mapping B
 * to A
 *
 * @see Mapping
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class MappingsCollectionSymmetric {

    Map<URI, Set<Mapping>> maps;

    public MappingsCollectionSymmetric() {
        maps = new HashMap<URI, Set<Mapping>>();
    }

    /**
     * Add a mapping to the collection The symmetric mapping is automatically
     * added to the collection i.e. if a mapping A to B is added B to A is also
     * created
     *
     * @param m the mapping object to ass to the collection
     */
    public void addMapping(Mapping m) {
        if (!maps.containsKey(m.getA())) {
            Set<Mapping> map = new HashSet<Mapping>();
            maps.put(m.getA(), map);
        }
        if (!maps.containsKey(m.getB())) {
            Set<Mapping> map = new HashSet<Mapping>();
            maps.put(m.getB(), map);
        }
        maps.get(m.getA()).add(m);
        // Add the inverse
        maps.get(m.getB()).add(new Mapping(m.getB(), m.getA(), m.getGraph_B(), m.getGraph_A()));
    }

    /**
     * Search if a mapping involving the two given URI and the two given graphs
     * exists
     *
     * @param uA the first URI
     * @param uB the second URI
     * @param gA the graph of the first URI
     * @param gB the graph of the second URI
     * @return true if the mapping exists
     */
    public boolean existsMapping(URI uA, URI uB, URI gA, URI gB) {

        // Because the collection is symmetric we only search for A to B
        if (maps.containsKey(uA)) {
            for (Mapping m : maps.get(uA)) {
                if (m.getB().equals(uB)
                        && m.getGraph_B().equals(gB)
                        && m.getGraph_A().equals(gA)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Return all the mapping involving the given URI
     *
     * @param uri
     * @return
     */
    public Set<Mapping> get(URI uri) {
        return maps.get(uri);
    }

    /**
     * Return all the mapping involving the given URI
     *
     * @param uri
     * @return
     */
    public Map<URI, Set<Mapping>> getMappings() {
        return maps;
    }
}
