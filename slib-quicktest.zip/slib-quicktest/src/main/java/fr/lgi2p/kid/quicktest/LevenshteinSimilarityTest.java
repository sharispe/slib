/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lgi2p.kid.quicktest;

import slib.sml.sm.core.measures.string.LevenshteinSimilarity;

/**
 *
 * @author Harispe Sébastien <harispe.sebastien@gmail.com>
 */
public class LevenshteinSimilarityTest {

    public static void sim(String a, String b, boolean normalize) {

        LevenshteinSimilarity lev = new LevenshteinSimilarity(normalize);
        System.out.println("'" + a + "'\t'" + b + "' norm:" + normalize + "\t" + lev.sim(a, b));
    }

    public static void main(String[] args) {

        boolean norm = true;
        LevenshteinSimilarityTest.sim("kitten", "", norm);
        LevenshteinSimilarityTest.sim("kitten", "sitten", norm);
        LevenshteinSimilarityTest.sim("kitten", "super-kitten", norm);

        norm = false;
        LevenshteinSimilarityTest.sim("kitten", "", norm);
        LevenshteinSimilarityTest.sim("kitten", "sitten", norm);
        LevenshteinSimilarityTest.sim("kitten", "super-kitten", norm);
    }
}
